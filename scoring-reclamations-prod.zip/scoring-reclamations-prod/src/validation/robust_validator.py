"""
Module de validation robuste avec split temporal et validation croisée
CORRECTION CRITIQUE: Évite l'overfitting en utilisant des données séparées
"""
import pandas as pd
import numpy as np
from typing import Tuple, Dict, List
from sklearn.model_selection import StratifiedKFold, TimeSeriesSplit
import logging

logger = logging.getLogger(__name__)


class RobustValidator:
    """
    Validateur robuste pour éviter l'overfitting
    
    Fonctionnalités:
    - Split temporel train/val/test
    - Validation croisée stratifiée
    - Métriques avec intervalles de confiance
    """
    
    def __init__(
        self,
        train_ratio: float = 0.70,
        val_ratio: float = 0.15,
        test_ratio: float = 0.15,
        cv_folds: int = 5,
        random_state: int = 42
    ):
        """
        Args:
            train_ratio: Proportion pour entraînement
            val_ratio: Proportion pour validation
            test_ratio: Proportion pour test
            cv_folds: Nombre de folds pour CV
            random_state: Seed pour reproductibilité
        """
        assert abs(train_ratio + val_ratio + test_ratio - 1.0) < 0.01
        
        self.train_ratio = train_ratio
        self.val_ratio = val_ratio
        self.test_ratio = test_ratio
        self.cv_folds = cv_folds
        self.random_state = random_state
    
    def temporal_split(
        self,
        df: pd.DataFrame,
        date_col: str = 'Date de Qualification'
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Split temporel (simule production)
        
        IMPORTANT: Les données futures ne doivent JAMAIS être vues pendant l'entraînement
        
        Args:
            df: DataFrame complet
            date_col: Colonne de date pour le tri
        
        Returns:
            (df_train, df_val, df_test)
        """
        logger.info("🔀 Split temporel des données...")
        
        # Trier par date
        if date_col in df.columns:
            df_sorted = df.sort_values(date_col).reset_index(drop=True)
        else:
            logger.warning(f"Colonne {date_col} absente, split aléatoire")
            df_sorted = df.sample(frac=1, random_state=self.random_state).reset_index(drop=True)
        
        # Calcul des indices de split
        n = len(df_sorted)
        train_end = int(n * self.train_ratio)
        val_end = train_end + int(n * self.val_ratio)
        
        # Split
        df_train = df_sorted[:train_end].copy()
        df_val = df_sorted[train_end:val_end].copy()
        df_test = df_sorted[val_end:].copy()
        
        logger.info(f"✅ Split effectué:")
        logger.info(f"   Train: {len(df_train):,} ({len(df_train)/n:.1%})")
        logger.info(f"   Val:   {len(df_val):,} ({len(df_val)/n:.1%})")
        logger.info(f"   Test:  {len(df_test):,} ({len(df_test)/n:.1%})")
        
        if date_col in df.columns:
            logger.info(f"   Périodes:")
            logger.info(f"   Train: {df_train[date_col].min()} → {df_train[date_col].max()}")
            logger.info(f"   Val:   {df_val[date_col].min()} → {df_val[date_col].max()}")
            logger.info(f"   Test:  {df_test[date_col].min()} → {df_test[date_col].max()}")
        
        return df_train, df_val, df_test
    
    def cross_validate(
        self,
        df: pd.DataFrame,
        scoring_engine,
        weights_optimizer,
        target_col: str = 'Fondée'
    ) -> Dict:
        """
        Validation croisée stratifiée K-fold
        
        Args:
            df: DataFrame d'entraînement
            scoring_engine: Instance de ScoringEngine
            weights_optimizer: Instance de WeightOptimizer
            target_col: Colonne cible
        
        Returns:
            Dict avec métriques + intervalles de confiance
        """
        logger.info(f"\n📊 Validation croisée {self.cv_folds}-fold...")
        
        # Préparer la stratification
        if 'Famille Produit' in df.columns:
            stratify_col = df['Famille Produit'].astype(str) + '_' + df[target_col].astype(str)
        else:
            stratify_col = df[target_col]
        
        cv = StratifiedKFold(
            n_splits=self.cv_folds,
            shuffle=True,
            random_state=self.random_state
        )
        
        # Métriques par fold
        fold_metrics = []
        
        for fold_idx, (train_idx, val_idx) in enumerate(cv.split(df, stratify_col)):
            logger.info(f"\n🔹 Fold {fold_idx + 1}/{self.cv_folds}")
            
            df_train_fold = df.iloc[train_idx].copy()
            df_val_fold = df.iloc[val_idx].copy()
            
            # 1. Entraîner le scoring engine
            scoring_engine.fit(df_train_fold)
            
            # 2. Calculer scores
            df_train_scored = scoring_engine.compute_all_scores(
                df_train_fold,
                alpha=0.4, beta=0.3, gamma=0.3  # Poids par défaut
            )
            
            # 3. Optimiser poids sur ce fold
            weights_fold = weights_optimizer.optimize_all_families(df_train_scored)
            
            # 4. Recalculer avec poids optimaux
            for _, weight_row in weights_fold.iterrows():
                famille = weight_row['Famille']
                mask_train = df_train_scored['Famille Produit'] == famille
                
                df_train_scored.loc[mask_train, 'score_final'] = (
                    weight_row['alpha'] * df_train_scored.loc[mask_train, 'score_type'] +
                    weight_row['beta'] * df_train_scored.loc[mask_train, 'score_risque'] +
                    weight_row['gamma'] * df_train_scored.loc[mask_train, 'score_signaletique']
                )
            
            # 5. Évaluer sur validation fold
            df_val_scored = scoring_engine.compute_all_scores(df_val_fold)
            
            for _, weight_row in weights_fold.iterrows():
                famille = weight_row['Famille']
                mask_val = df_val_scored['Famille Produit'] == famille
                
                df_val_scored.loc[mask_val, 'score_final'] = (
                    weight_row['alpha'] * df_val_scored.loc[mask_val, 'score_type'] +
                    weight_row['beta'] * df_val_scored.loc[mask_val, 'score_risque'] +
                    weight_row['gamma'] * df_val_scored.loc[mask_val, 'score_signaletique']
                )
            
            # 6. Calculer métriques
            from sklearn.metrics import precision_score, recall_score, f1_score, roc_auc_score
            
            y_true = df_val_scored[target_col]
            y_pred = (df_val_scored['score_final'] >= 0.5).astype(int)
            y_score = df_val_scored['score_final']
            
            metrics = {
                'precision': precision_score(y_true, y_pred, zero_division=0),
                'recall': recall_score(y_true, y_pred, zero_division=0),
                'f1': f1_score(y_true, y_pred, zero_division=0),
                'roc_auc': roc_auc_score(y_true, y_score) if len(y_true.unique()) > 1 else 0
            }
            
            fold_metrics.append(metrics)
            
            logger.info(f"   Précision: {metrics['precision']:.3f}")
            logger.info(f"   Rappel:    {metrics['recall']:.3f}")
            logger.info(f"   F1:        {metrics['f1']:.3f}")
        
        # Agréger les résultats
        cv_results = {}
        for metric_name in fold_metrics[0].keys():
            values = [m[metric_name] for m in fold_metrics]
            cv_results[metric_name] = {
                'mean': np.mean(values),
                'std': np.std(values),
                'min': np.min(values),
                'max': np.max(values),
                'ci_lower': np.percentile(values, 2.5),
                'ci_upper': np.percentile(values, 97.5)
            }
        
        logger.info(f"\n✅ Résultats CV agrégés:")
        for metric, stats in cv_results.items():
            logger.info(
                f"   {metric.capitalize()}: "
                f"{stats['mean']:.3f} ± {stats['std']:.3f} "
                f"[{stats['ci_lower']:.3f}, {stats['ci_upper']:.3f}]"
            )
        
        # Vérifier stabilité
        for metric, stats in cv_results.items():
            if stats['std'] > 0.05:
                logger.warning(
                    f"⚠️ Modèle instable sur {metric} (std={stats['std']:.3f} > 0.05)"
                )
        
        return cv_results
    
    def compute_confidence_intervals(
        self,
        df: pd.DataFrame,
        scoring_engine,
        n_bootstrap: int = 1000,
        confidence_level: float = 0.95
    ) -> pd.DataFrame:
        """
        Calcule intervalles de confiance par bootstrap
        
        Args:
            df: DataFrame avec réclamations
            scoring_engine: Scoring engine entraîné
            n_bootstrap: Nombre d'itérations bootstrap
            confidence_level: Niveau de confiance (0.95 = 95%)
        
        Returns:
            DataFrame avec colonnes score_mean, ci_lower, ci_upper
        """
        logger.info(f"\n🔄 Calcul intervalles de confiance ({n_bootstrap} iterations)...")
        
        results = []
        
        for idx, row in df.iterrows():
            # Bootstrap: resample des statistiques avec variance
            bootstrap_scores = []
            
            for _ in range(n_bootstrap):
                # Ajouter bruit gaussien pour simuler incertitude
                score_type = scoring_engine.compute_score_type(row)
                score_risque = scoring_engine.compute_score_risque(row)
                score_signal = scoring_engine.compute_score_signaletique(row)
                
                # Perturbation
                score_type += np.random.normal(0, 0.02)
                score_risque += np.random.normal(0, 0.02)
                score_signal += np.random.normal(0, 0.02)
                
                # Clip to [0, 1]
                score_type = np.clip(score_type, 0, 1)
                score_risque = np.clip(score_risque, 0, 1)
                score_signal = np.clip(score_signal, 0, 1)
                
                # Score final
                famille = row['Famille Produit']
                # Utiliser poids par défaut pour bootstrap
                score_final = 0.4 * score_type + 0.3 * score_risque + 0.3 * score_signal
                
                bootstrap_scores.append(score_final)
            
            # Calculer statistiques
            alpha = (1 - confidence_level) / 2
            results.append({
                'No Demande': row.get('No Demande', idx),
                'score_mean': np.mean(bootstrap_scores),
                'score_std': np.std(bootstrap_scores),
                'ci_lower': np.percentile(bootstrap_scores, alpha * 100),
                'ci_upper': np.percentile(bootstrap_scores, (1 - alpha) * 100)
            })
        
        df_ci = pd.DataFrame(results)
        
        logger.info(f"✅ Intervalles calculés")
        logger.info(f"   Largeur CI moyenne: {(df_ci['ci_upper'] - df_ci['ci_lower']).mean():.3f}")
        
        return df_ci
