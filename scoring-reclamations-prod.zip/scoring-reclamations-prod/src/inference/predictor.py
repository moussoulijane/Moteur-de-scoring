"""
Module de prédiction pour nouvelles réclamations
Charge les artefacts d'entraînement et score en temps réel
"""
import pandas as pd
import numpy as np
import pickle
from pathlib import Path
from typing import Dict, Tuple, Optional
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class ReclamationScorer:
    """
    Moteur d'inférence qui applique le modèle de scoring
    à de nouvelles réclamations
    """
    
    def __init__(self, artifacts_path: str = "artifacts/metrics.pkl"):
        """
        Charge les artefacts d'entraînement
        
        Args:
            artifacts_path: Chemin vers metrics.pkl
        """
        logger.info(f"📥 Chargement des artefacts depuis {artifacts_path}...")
        
        if not Path(artifacts_path).exists():
            raise FileNotFoundError(f"Artefacts introuvables : {artifacts_path}")
        
        with open(artifacts_path, 'rb') as f:
            self.metrics = pickle.load(f)
        
        self.bayesian = self.metrics['bayesian_priors']
        self.financial = self.metrics['financial_stats']
        self.client_stats = self.metrics['client_stats']
        self.weights = self.metrics['optimal_weights']
        self.thresholds = self.metrics['decision_thresholds']
        self.metadata = self.metrics.get('metadata', {})
        
        logger.info("✅ Modèle chargé avec succès")
        logger.info(f"   Version: {self.metadata.get('version', 'N/A')}")
        logger.info(f"   Date entraînement: {self.metadata.get('training_date', 'N/A')}")
        logger.info(f"   {len(self.weights)} familles configurées")
        logger.info(f"   {len(self.bayesian['motif_probs'])} motifs connus")
    
    def compute_score_type(self, row: pd.Series) -> float:
        """
        Calcule le Score_Type (Pilier Expertise Métier)
        
        Args:
            row: Ligne de réclamation
        
        Returns:
            Score [0, 1]
        """
        motif = f"{row['Famille Produit']}|{row['Catégorie']}|{row['Sous-catégorie']}"
        
        # Si motif inconnu, utiliser le prior global
        if motif in self.bayesian['motif_probs']:
            return self.bayesian['motif_probs'][motif]
        else:
            logger.debug(f"⚠️ Motif inconnu : {motif} (utilisation du prior global)")
            return self.bayesian['global_rate']
    
    def compute_score_risque(self, row: pd.Series) -> float:
        """
        Calcule le Score_Risque (Pilier Cohérence Financière)
        
        Args:
            row: Ligne de réclamation
        
        Returns:
            Score [0, 1]
        """
        famille = row['Famille Produit']
        
        if famille not in self.financial:
            logger.debug(f"⚠️ Famille inconnue : {famille}")
            return 0.5  # Neutre si famille inconnue
        
        stats = self.financial[famille]
        montant = row.get('Montant demandé', 0)
        pnb = row.get('PNB analytique (vision commerciale) cumulé', 0)
        
        # Indice de normalité
        if pd.isna(montant) or stats['montant_iqr'] == 0:
            normalite = 0.5
        else:
            distance = abs(montant - stats['montant_median'])
            normalite = 1 / (1 + distance / (stats['montant_iqr'] + 1))
        
        # Puissance PNB
        if pd.isna(pnb) or pnb <= 0 or pd.isna(montant) or montant <= 0:
            puissance_pnb = 0
        else:
            ratio = pnb / montant
            puissance_pnb = np.tanh(ratio / 10)  # Saturation à ~10x
        
        return 0.6 * normalite + 0.4 * puissance_pnb
    
    def compute_score_signaletique(self, row: pd.Series) -> float:
        """
        Calcule le Score_Signalétique (Pilier Profil Client)
        
        Args:
            row: Ligne de réclamation
        
        Returns:
            Score [0, 1]
        """
        client_id = row.get('idtfcl')
        
        # Historique client
        if client_id and client_id in self.client_stats['client_success_rates']:
            historique = self.client_stats['client_success_rates'][client_id]
        else:
            historique = self.client_stats['global_client_rate']
        
        # Ancienneté (normalisée sur 10 ans)
        anciennete = row.get('anciennete_annees', 0)
        anciennete_norm = min(anciennete / 10, 1.0) if not pd.isna(anciennete) else 0
        
        # Banque Privée (bonus VIP)
        is_bp = 1 if row.get('Banque Privé') == 'OUI' else 0
        
        return 0.5 * historique + 0.3 * anciennete_norm + 0.2 * is_bp
    
    def compute_final_score(self, row: pd.Series) -> Tuple[float, Dict]:
        """
        Calcule le score final pondéré
        
        Args:
            row: Ligne de réclamation
        
        Returns:
            (score_final, details)
        """
        famille = row['Famille Produit']
        
        # Scores des 3 piliers
        score_type = self.compute_score_type(row)
        score_risque = self.compute_score_risque(row)
        score_signal = self.compute_score_signaletique(row)
        
        # Poids optimaux pour cette famille
        if famille in self.weights:
            w = self.weights[famille]
            alpha, beta, gamma = w['alpha'], w['beta'], w['gamma']
        else:
            # Poids par défaut si famille inconnue
            logger.warning(f"⚠️ Famille '{famille}' non configurée - utilisation poids par défaut")
            alpha, beta, gamma = 0.4, 0.3, 0.3
        
        # Score final
        score_final = alpha * score_type + beta * score_risque + gamma * score_signal
        
        details = {
            'score_type': round(score_type, 4),
            'score_risque': round(score_risque, 4),
            'score_signaletique': round(score_signal, 4),
            'alpha': alpha,
            'beta': beta,
            'gamma': gamma
        }
        
        return score_final, details
    
    def predict_decision(self, row: pd.Series) -> Dict:
        """
        Prédit la décision pour une réclamation
        
        Args:
            row: Ligne de réclamation
        
        Returns:
            Dictionnaire avec score, décision et détails
        """
        famille = row['Famille Produit']
        score_final, details = self.compute_final_score(row)
        
        # Seuils de décision
        if famille in self.thresholds:
            th = self.thresholds[famille]
            seuil_bas = th['seuil_rejet_auto']
            seuil_haut = th['seuil_validation_auto']
        else:
            # Seuils par défaut conservateurs
            logger.warning(f"⚠️ Seuils non définis pour '{famille}' - utilisation seuils par défaut")
            seuil_bas = 0.3
            seuil_haut = 0.7
        
        # Décision
        if score_final <= seuil_bas:
            decision = "REJET_AUTO"
            confiance = "HAUTE"
        elif score_final >= seuil_haut:
            decision = "VALIDATION_AUTO"
            confiance = "HAUTE"
        else:
            decision = "AUDIT_HUMAIN"
            confiance = "MOYENNE"
        
        return {
            'score_final': round(score_final, 4),
            'decision': decision,
            'confiance': confiance,
            'seuil_bas': seuil_bas,
            'seuil_haut': seuil_haut,
            **details
        }
    
    def score_batch(self, df_new: pd.DataFrame, verbose: bool = True) -> pd.DataFrame:
        """
        Score un lot de réclamations
        
        Args:
            df_new: DataFrame de nouvelles réclamations
            verbose: Afficher les logs
        
        Returns:
            DataFrame avec résultats du scoring
        """
        if verbose:
            logger.info(f"\n🔄 Scoring de {len(df_new)} réclamations...")
        
        results = []
        unknown_families = set()
        unknown_motifs = set()
        
        for idx, row in df_new.iterrows():
            try:
                prediction = self.predict_decision(row)
                prediction['No Demande'] = row.get('No Demande', idx)
                prediction['Famille Produit'] = row.get('Famille Produit')
                results.append(prediction)
                
                # Tracker les éléments inconnus
                famille = row['Famille Produit']
                if famille not in self.weights:
                    unknown_families.add(famille)
                
                motif = f"{row['Famille Produit']}|{row['Catégorie']}|{row['Sous-catégorie']}"
                if motif not in self.bayesian['motif_probs']:
                    unknown_motifs.add(motif)
                    
            except Exception as e:
                logger.error(f"❌ Erreur lors du scoring de la réclamation {row.get('No Demande', idx)}: {e}")
                # Résultat par défaut en cas d'erreur
                results.append({
                    'No Demande': row.get('No Demande', idx),
                    'Famille Produit': row.get('Famille Produit'),
                    'score_final': 0.5,
                    'decision': 'AUDIT_HUMAIN',
                    'confiance': 'BASSE',
                    'error': str(e)
                })
        
        df_results = pd.DataFrame(results)
        
        if verbose:
            logger.info("\n📊 Résultats du scoring:")
            logger.info(f"\n{df_results['decision'].value_counts()}")
            logger.info(f"\n📈 Score moyen: {df_results['score_final'].mean():.3f}")
            logger.info(f"   Score min: {df_results['score_final'].min():.3f}")
            logger.info(f"   Score max: {df_results['score_final'].max():.3f}")
            
            if unknown_families:
                logger.warning(f"\n⚠️ {len(unknown_families)} familles inconnues détectées:")
                for fam in list(unknown_families)[:5]:
                    logger.warning(f"   - {fam}")
            
            if unknown_motifs:
                logger.warning(f"\n⚠️ {len(unknown_motifs)} motifs inconnus détectés")
        
        return df_results
    
    def score_single(self, reclamation_dict: Dict) -> Dict:
        """
        Score une seule réclamation à partir d'un dictionnaire
        
        Args:
            reclamation_dict: Dictionnaire avec les champs de la réclamation
        
        Returns:
            Dictionnaire de prédiction
        """
        row = pd.Series(reclamation_dict)
        return self.predict_decision(row)
    
    def get_model_info(self) -> Dict:
        """
        Retourne des informations sur le modèle chargé
        
        Returns:
            Dictionnaire d'informations
        """
        return {
            'version': self.metadata.get('version', 'N/A'),
            'training_date': self.metadata.get('training_date', 'N/A'),
            'training_size': self.metadata.get('training_size', 0),
            'n_families': len(self.weights),
            'n_motifs': len(self.bayesian['motif_probs']),
            'families': list(self.weights.keys()),
            'global_success_rate': self.bayesian['global_rate']
        }
