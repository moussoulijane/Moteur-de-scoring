"""
Moteur de Scoring Prédictif - Calcul des 3 Piliers
"""
import pandas as pd
import numpy as np
from typing import Dict, Tuple, Optional
import yaml
from pathlib import Path
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class ScoringEngine:
    """
    Calcule les 3 scores fondamentaux pour chaque réclamation :
    - Score_Type : Probabilité Bayésienne sur le motif
    - Score_Risque : Cohérence financière (montant + PNB)
    - Score_Signalétique : Profil client (historique + ancienneté + segment)
    """
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Args:
            config_path: Chemin vers la configuration
        """
        self.config = self._load_config(config_path)
        self.bayesian_priors = None
        self.financial_stats = None
        self.client_stats = None
        
    def _load_config(self, config_path: str) -> dict:
        """Charge la configuration"""
        if Path(config_path).exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return {}
    
    def fit(self, df_train: pd.DataFrame):
        """
        Calcule les statistiques nécessaires sur le dataset d'entraînement
        
        Args:
            df_train: DataFrame d'entraînement avec colonne 'Fondée'
        """
        logger.info("🔧 Entraînement du moteur de scoring...")
        
        self._compute_bayesian_priors(df_train)
        self._compute_financial_stats(df_train)
        self._compute_client_stats(df_train)
        
        logger.info("✅ Moteur entraîné avec succès")
    
    def _compute_bayesian_priors(self, df: pd.DataFrame):
        """
        Calcule les probabilités bayésiennes par motif
        P(Fondée | Motif) avec lissage de Laplace
        """
        C = self.config.get('model', {}).get('bayesian_smoothing', 15)
        logger.info(f"📊 Calcul des priors bayésiens (C={C})...")
        
        # Taux global de succès
        global_rate = df['Fondée'].mean()
        
        # Créer le motif complet
        df['motif_complet'] = (
            df['Famille Produit'].astype(str) + '|' +
            df['Catégorie'].astype(str) + '|' +
            df['Sous-catégorie'].astype(str)
        )
        
        # Statistiques par motif
        motif_stats = df.groupby('motif_complet').agg({
            'Fondée': ['sum', 'count']
        }).reset_index()
        
        motif_stats.columns = ['motif', 'successes', 'total']
        
        # Lissage bayésien
        motif_stats['bayes_prob'] = (
            (motif_stats['successes'] + C * global_rate) / 
            (motif_stats['total'] + C)
        )
        
        self.bayesian_priors = {
            'global_rate': float(global_rate),
            'C': C,
            'motif_probs': motif_stats.set_index('motif')['bayes_prob'].to_dict(),
            'motif_counts': motif_stats.set_index('motif')['total'].to_dict()
        }
        
        logger.info(f"✅ {len(self.bayesian_priors['motif_probs'])} motifs analysés")
        logger.info(f"   Taux global: {global_rate:.2%}")
    
    def _compute_financial_stats(self, df: pd.DataFrame):
        """
        Calcule les statistiques financières par famille
        (médianes, quartiles, IQR pour normalisation)
        """
        logger.info("💰 Calcul des statistiques financières par famille...")
        
        self.financial_stats = {}
        
        for famille in df['Famille Produit'].dropna().unique():
            df_fam = df[df['Famille Produit'] == famille]
            
            montants = df_fam['Montant demandé'].dropna()
            pnb = df_fam.get('PNB analytique (vision commerciale) cumulé', pd.Series()).dropna()
            
            self.financial_stats[famille] = {
                'montant_median': float(montants.median()) if len(montants) > 0 else 0,
                'montant_q25': float(montants.quantile(0.25)) if len(montants) > 0 else 0,
                'montant_q75': float(montants.quantile(0.75)) if len(montants) > 0 else 0,
                'montant_iqr': float(montants.quantile(0.75) - montants.quantile(0.25)) if len(montants) > 0 else 1,
                'montant_max': float(montants.max()) if len(montants) > 0 else 0,
                'pnb_median': float(pnb.median()) if len(pnb) > 0 else 0,
                'pnb_q75': float(pnb.quantile(0.75)) if len(pnb) > 0 else 0
            }
        
        logger.info(f"✅ Statistiques calculées pour {len(self.financial_stats)} familles")
    
    def _compute_client_stats(self, df: pd.DataFrame):
        """
        Calcule les taux de succès historiques par client
        """
        logger.info("👤 Calcul des statistiques clients...")
        
        if 'idtfcl' not in df.columns:
            logger.warning("⚠️ Colonne 'idtfcl' absente - pas de stats clients")
            self.client_stats = {
                'client_success_rates': {},
                'global_client_rate': 0.5
            }
            return
        
        client_history = df.groupby('idtfcl').agg({
            'Fondée': ['sum', 'count', 'mean']
        }).reset_index()
        
        client_history.columns = ['idtfcl', 'successes', 'total', 'success_rate']
        
        # Ne garder que les clients avec historique significatif (>= 2)
        client_history = client_history[client_history['total'] >= 2]
        
        self.client_stats = {
            'client_success_rates': client_history.set_index('idtfcl')['success_rate'].to_dict(),
            'global_client_rate': float(df.groupby('idtfcl')['Fondée'].mean().mean())
        }
        
        logger.info(f"✅ {len(self.client_stats['client_success_rates'])} clients avec historique")
    
    def compute_score_type(self, row: pd.Series) -> float:
        """
        Calcule le Score_Type (Pilier 1 : Expertise Métier)
        
        Args:
            row: Ligne du DataFrame
        
        Returns:
            Score entre 0 et 1
        """
        motif = f"{row['Famille Produit']}|{row['Catégorie']}|{row['Sous-catégorie']}"
        
        # Si motif inconnu, utiliser le prior global
        if motif in self.bayesian_priors['motif_probs']:
            return self.bayesian_priors['motif_probs'][motif]
        else:
            return self.bayesian_priors['global_rate']
    
    def compute_score_risque(self, row: pd.Series) -> float:
        """
        Calcule le Score_Risque (Pilier 2 : Cohérence Financière)
        
        Composé de :
        - Indice de normalité : distance au montant médian
        - Puissance PNB : ratio PNB/Montant avec saturation
        
        Args:
            row: Ligne du DataFrame
        
        Returns:
            Score entre 0 et 1
        """
        famille = row['Famille Produit']
        
        if famille not in self.financial_stats:
            return 0.5  # Neutre si famille inconnue
        
        stats = self.financial_stats[famille]
        montant = row.get('Montant demandé', 0)
        pnb = row.get('PNB analytique (vision commerciale) cumulé', 0)
        
        # Poids configurables
        w_normalite = self.config.get('scoring', {}).get('normalite_weight', 0.6)
        w_pnb = self.config.get('scoring', {}).get('pnb_weight', 0.4)
        saturation_factor = self.config.get('scoring', {}).get('pnb_saturation_factor', 10)
        
        # 1. Indice de normalité
        if pd.isna(montant) or stats['montant_iqr'] == 0:
            normalite = 0.5
        else:
            distance = abs(montant - stats['montant_median'])
            normalite = 1 / (1 + distance / (stats['montant_iqr'] + 1))
        
        # 2. Puissance PNB (protection clients VIP)
        if pd.isna(pnb) or pnb <= 0 or pd.isna(montant) or montant <= 0:
            puissance_pnb = 0
        else:
            ratio = pnb / montant
            puissance_pnb = np.tanh(ratio / saturation_factor)
        
        return w_normalite * normalite + w_pnb * puissance_pnb
    
    def compute_score_signaletique(self, row: pd.Series) -> float:
        """
        Calcule le Score_Signalétique (Pilier 3 : Profil Client)
        
        Composé de :
        - Historique de succès du client
        - Ancienneté de la relation (0-10 ans)
        - Appartenance Banque Privée
        
        Args:
            row: Ligne du DataFrame
        
        Returns:
            Score entre 0 et 1
        """
        # Poids configurables
        w_hist = self.config.get('scoring', {}).get('historique_weight', 0.5)
        w_anc = self.config.get('scoring', {}).get('anciennete_weight', 0.3)
        w_bp = self.config.get('scoring', {}).get('banque_privee_weight', 0.2)
        max_years = self.config.get('scoring', {}).get('anciennete_max_years', 10)
        
        # 1. Historique client
        client_id = row.get('idtfcl')
        if client_id in self.client_stats['client_success_rates']:
            historique = self.client_stats['client_success_rates'][client_id]
        else:
            historique = self.client_stats['global_client_rate']
        
        # 2. Ancienneté (normalisée sur max_years)
        anciennete = row.get('anciennete_annees', 0)
        anciennete_norm = min(anciennete / max_years, 1.0) if not pd.isna(anciennete) else 0
        
        # 3. Banque Privée (bonus VIP)
        is_bp = 1 if row.get('Banque Privé') == 'OUI' else 0
        
        return w_hist * historique + w_anc * anciennete_norm + w_bp * is_bp
    
    def compute_all_scores(
        self, 
        df: pd.DataFrame,
        alpha: float = 0.4,
        beta: float = 0.3,
        gamma: float = 0.3
    ) -> pd.DataFrame:
        """
        Calcule les 3 scores et le score final pour tout le DataFrame
        
        Args:
            df: DataFrame de réclamations
            alpha: Poids du Score_Type
            beta: Poids du Score_Risque
            gamma: Poids du Score_Signalétique
        
        Returns:
            DataFrame avec colonnes score_type, score_risque, score_signaletique, score_final
        """
        logger.info(f"🔢 Calcul des scores (α={alpha}, β={beta}, γ={gamma})...")
        
        df = df.copy()
        
        # Calcul des 3 piliers
        df['score_type'] = df.apply(self.compute_score_type, axis=1)
        df['score_risque'] = df.apply(self.compute_score_risque, axis=1)
        df['score_signaletique'] = df.apply(self.compute_score_signaletique, axis=1)
        
        # Score final pondéré
        df['score_final'] = (
            alpha * df['score_type'] + 
            beta * df['score_risque'] + 
            gamma * df['score_signaletique']
        )
        
        logger.info(f"✅ Scores calculés pour {len(df)} réclamations")
        logger.info(f"   Score moyen: {df['score_final'].mean():.3f}")
        
        return df
