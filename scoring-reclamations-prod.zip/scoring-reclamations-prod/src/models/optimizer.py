"""
Optimiseur de poids par Grid Search
Trouve les meilleurs (α, β, γ) pour chaque famille
"""
import pandas as pd
import numpy as np
from typing import Dict, Tuple, List
from sklearn.metrics import f1_score, precision_score, recall_score
import yaml
from pathlib import Path
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class WeightOptimizer:
    """
    Optimise les poids (alpha, beta, gamma) par famille
    via Grid Search exhaustif
    """
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Args:
            config_path: Chemin vers la configuration
        """
        self.config = self._load_config(config_path)
        self.optimal_weights = {}
        
    def _load_config(self, config_path: str) -> dict:
        """Charge la configuration"""
        if Path(config_path).exists():
            with open(config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return {}
    
    def optimize_family(
        self,
        df_family: pd.DataFrame,
        famille: str
    ) -> Dict:
        """
        Optimise les poids pour une famille spécifique
        
        Args:
            df_family: DataFrame filtré pour une famille (doit contenir score_type, score_risque, score_signaletique, Fondée)
            famille: Nom de la famille
        
        Returns:
            Dict avec alpha, beta, gamma, f1_score optimaux
        """
        logger.info(f"🔍 Optimisation pour famille '{famille}' ({len(df_family)} dossiers)...")
        
        # Récupérer les plages de recherche
        alpha_range = self.config.get('model', {}).get('weights', {}).get('alpha_range', [0.3, 0.4, 0.5, 0.6])
        beta_range = self.config.get('model', {}).get('weights', {}).get('beta_range', [0.2, 0.3, 0.4, 0.5])
        gamma_range = self.config.get('model', {}).get('weights', {}).get('gamma_range', [0.1, 0.2, 0.3, 0.4])
        
        best_f1 = 0
        best_weights = None
        
        # Grid Search
        total_combinations = len(alpha_range) * len(beta_range) * len(gamma_range)
        logger.info(f"   Testing {total_combinations} combinaisons...")
        
        for alpha in alpha_range:
            for beta in beta_range:
                for gamma in gamma_range:
                    # Contrainte : alpha + beta + gamma = 1 (±tolerance)
                    if abs(alpha + beta + gamma - 1.0) > 0.01:
                        continue
                    
                    # Calculer le score final avec ces poids
                    score_final = (
                        alpha * df_family['score_type'] + 
                        beta * df_family['score_risque'] + 
                        gamma * df_family['score_signaletique']
                    )
                    
                    # Prédiction binaire (seuil à 0.5 pour l'optimisation)
                    y_pred = (score_final >= 0.5).astype(int)
                    y_true = df_family['Fondée']
                    
                    # Calculer le F1-Score
                    f1 = f1_score(y_true, y_pred, zero_division=0)
                    
                    if f1 > best_f1:
                        best_f1 = f1
                        best_weights = {
                            'alpha': alpha,
                            'beta': beta,
                            'gamma': gamma,
                            'f1_score': f1
                        }
        
        if best_weights is None:
            logger.warning(f"⚠️ Aucune combinaison valide trouvée pour {famille}, utilisation des poids par défaut")
            best_weights = {
                'alpha': 0.4,
                'beta': 0.3,
                'gamma': 0.3,
                'f1_score': 0.0
            }
        
        logger.info(f"✅ Meilleurs poids : α={best_weights['alpha']}, β={best_weights['beta']}, γ={best_weights['gamma']} (F1={best_weights['f1_score']:.3f})")
        
        return best_weights
    
    def optimize_all_families(
        self,
        df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Optimise les poids pour toutes les familles
        
        Args:
            df: DataFrame complet avec scores calculés et colonne Fondée
        
        Returns:
            DataFrame avec colonnes [Famille, alpha, beta, gamma, f1_score]
        """
        logger.info("🚀 Optimisation des poids pour toutes les familles...")
        
        results = []
        
        for famille in df['Famille Produit'].unique():
            df_family = df[df['Famille Produit'] == famille]
            
            # Filtrer les familles avec trop peu de données
            min_samples = self.config.get('thresholds', {}).get('min_samples_per_family', 50)
            if len(df_family) < min_samples:
                logger.warning(f"⚠️ Famille '{famille}' ignorée (seulement {len(df_family)} dossiers < {min_samples})")
                continue
            
            optimal = self.optimize_family(df_family, famille)
            optimal['Famille'] = famille
            results.append(optimal)
        
        df_results = pd.DataFrame(results)
        
        logger.info(f"✅ Optimisation terminée pour {len(df_results)} familles")
        logger.info(f"   F1-Score moyen: {df_results['f1_score'].mean():.3f}")
        
        self.optimal_weights = df_results.set_index('Famille').to_dict('index')
        
        return df_results
    
    def get_weights_for_family(self, famille: str) -> Tuple[float, float, float]:
        """
        Récupère les poids optimaux pour une famille
        
        Args:
            famille: Nom de la famille
        
        Returns:
            (alpha, beta, gamma)
        """
        if famille in self.optimal_weights:
            w = self.optimal_weights[famille]
            return w['alpha'], w['beta'], w['gamma']
        else:
            # Poids par défaut si famille inconnue
            logger.warning(f"⚠️ Famille '{famille}' non trouvée, utilisation des poids par défaut")
            return 0.4, 0.3, 0.3
    
    def evaluate_weights(
        self,
        df: pd.DataFrame,
        weights_df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Évalue les performances des poids optimaux
        
        Args:
            df: DataFrame avec scores calculés
            weights_df: DataFrame des poids optimaux
        
        Returns:
            DataFrame avec métriques par famille
        """
        logger.info("📊 Évaluation des poids optimaux...")
        
        metrics_list = []
        
        for _, row in weights_df.iterrows():
            famille = row['Famille']
            alpha, beta, gamma = row['alpha'], row['beta'], row['gamma']
            
            df_family = df[df['Famille Produit'] == famille]
            
            # Calculer le score final avec les poids optimaux
            score_final = (
                alpha * df_family['score_type'] + 
                beta * df_family['score_risque'] + 
                gamma * df_family['score_signaletique']
            )
            
            y_pred = (score_final >= 0.5).astype(int)
            y_true = df_family['Fondée']
            
            metrics = {
                'Famille': famille,
                'n_samples': len(df_family),
                'f1_score': f1_score(y_true, y_pred, zero_division=0),
                'precision': precision_score(y_true, y_pred, zero_division=0),
                'recall': recall_score(y_true, y_pred, zero_division=0),
                'taux_fondees': y_true.mean(),
                'score_moyen': score_final.mean()
            }
            
            metrics_list.append(metrics)
        
        df_metrics = pd.DataFrame(metrics_list)
        
        logger.info(f"✅ Évaluation terminée")
        logger.info(f"   F1 moyen: {df_metrics['f1_score'].mean():.3f}")
        logger.info(f"   Precision moyenne: {df_metrics['precision'].mean():.3f}")
        logger.info(f"   Recall moyen: {df_metrics['recall'].mean():.3f}")
        
        return df_metrics
