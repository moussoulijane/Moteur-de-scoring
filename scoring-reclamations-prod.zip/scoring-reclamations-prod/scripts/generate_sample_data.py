"""
Génère un dataset exemple pour tester le moteur de scoring
"""
import pandas as pd
import numpy as np
from pathlib import Path

def generate_sample_data(n_samples=1000, output_path="data/raw/sample_reclamations.csv"):
    """
    Génère un dataset exemple de réclamations
    
    Args:
        n_samples: Nombre de réclamations à générer
        output_path: Chemin de sauvegarde
    """
    np.random.seed(42)
    
    # Définir les métadonnées
    familles = {
        'Monétique': ['GAB', 'Carte', 'TPE'],
        'Crédit': ['Personnel', 'Immobilier', 'Consommation'],
        'Frais': ['Tenue de compte', 'Commission', 'Agios'],
        'Epargne': ['Placement', 'Assurance Vie', 'Compte épargne']
    }
    
    sous_categories = {
        'GAB': ['Débit non effectué', 'Carte avalée', 'Code erroné'],
        'Carte': ['Paiement refusé', 'Opposition tardive', 'Débit frauduleux'],
        'TPE': ['Transaction non aboutie', 'Double débit', 'Montant incorrect'],
        'Personnel': ['Taux incorrect', 'Échéance non prélevée', 'Remboursement anticipé'],
        'Immobilier': ['Assurance non prise en compte', 'Frais de dossier', 'Garantie'],
        'Consommation': ['Taux erroné', 'Mensualité incorrecte', 'Report échéance'],
        'Tenue de compte': ['Prélèvement indû', 'Frais non justifiés', 'Facturation double'],
        'Commission': ['Commission non prévue', 'Taux abusif', 'Facturation erronée'],
        'Agios': ['Calcul incorrect', 'Date valeur erronée', 'Taux non respecté'],
        'Placement': ['Rendement non conforme', 'Frais cachés', 'Information erronée'],
        'Assurance Vie': ['Rachat retardé', 'Arbitrage non effectué', 'Frais de gestion'],
        'Compte épargne': ['Rémunération incorrecte', 'Plafond dépassé', 'Blocage indû']
    }
    
    # Probabilités de succès par catégorie (pour réalisme)
    success_rates = {
        'GAB': 0.75,
        'Carte': 0.65,
        'TPE': 0.70,
        'Personnel': 0.55,
        'Immobilier': 0.45,
        'Consommation': 0.60,
        'Tenue de compte': 0.40,
        'Commission': 0.35,
        'Agios': 0.50,
        'Placement': 0.30,
        'Assurance Vie': 0.40,
        'Compte épargne': 0.45
    }
    
    data = []
    
    for i in range(n_samples):
        # Sélectionner famille et catégorie
        famille = np.random.choice(list(familles.keys()))
        categorie = np.random.choice(familles[famille])
        sous_cat = np.random.choice(sous_categories[categorie])
        
        # Déterminer si fondée (basé sur probabilités réalistes)
        success_prob = success_rates.get(categorie, 0.5)
        fondee = 1 if np.random.random() < success_prob else 0
        
        # Montant (distribution réaliste)
        if famille == 'Monétique':
            montant = np.random.lognormal(5.5, 1.2)  # Médiane ~250€
        elif famille == 'Crédit':
            montant = np.random.lognormal(7.5, 1.5)  # Médiane ~2000€
        elif famille == 'Frais':
            montant = np.random.lognormal(3.5, 0.8)  # Médiane ~35€
        else:  # Epargne
            montant = np.random.lognormal(6.5, 1.8)  # Médiane ~700€
        
        # PNB (corrélé au montant mais avec variance)
        pnb_base = montant * np.random.uniform(5, 50)
        pnb = max(0, pnb_base + np.random.normal(0, pnb_base * 0.3))
        
        # Client
        client_id = f"CLI_{np.random.randint(1000, 9999)}"
        anciennete = np.random.exponential(3.5)  # Moyenne 3.5 ans
        banque_privee = 'OUI' if np.random.random() < 0.15 else 'NON'
        
        # Segment
        if pnb > 30000:
            segment = 'Premium'
        elif pnb > 10000:
            segment = 'Particuliers'
        else:
            segment = 'Grand Public'
        
        data.append({
            'No Demande': f'REC_2026_{i+1:05d}',
            'Famille Produit': famille,
            'Catégorie': categorie,
            'Sous-catégorie': sous_cat,
            'Montant demandé': round(montant, 2),
            'PNB analytique (vision commerciale) cumulé': round(pnb, 2),
            'idtfcl': client_id,
            'anciennete_annees': round(anciennete, 1),
            'Banque Privé': banque_privee,
            'Segment': segment,
            'Fondée': fondee
        })
    
    # Créer le DataFrame
    df = pd.DataFrame(data)
    
    # Sauvegarder
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(output_path, index=False)
    
    print(f"✅ {n_samples} réclamations générées : {output_path}")
    print(f"\n📊 Statistiques:")
    print(f"   Familles: {df['Famille Produit'].nunique()}")
    print(f"   Taux fondées: {df['Fondée'].mean():.1%}")
    print(f"   Montant moyen: {df['Montant demandé'].mean():.2f}€")
    print(f"   Montant médian: {df['Montant demandé'].median():.2f}€")
    
    print(f"\n📋 Répartition par famille:")
    print(df['Famille Produit'].value_counts())
    
    return df


if __name__ == "__main__":
    # Générer dataset d'entraînement
    print("Génération du dataset d'entraînement (5000 réclamations)...\n")
    df_train = generate_sample_data(
        n_samples=5000,
        output_path="data/raw/sample_reclamations_train.csv"
    )
    
    # Générer dataset de test
    print("\n" + "="*60)
    print("\nGénération du dataset de test (1000 réclamations)...\n")
    df_test = generate_sample_data(
        n_samples=1000,
        output_path="data/raw/sample_reclamations_test.csv"
    )
    
    print("\n" + "="*60)
    print("✅ Données exemple générées avec succès !")
    print("\n🚀 Vous pouvez maintenant :")
    print("   1. Entraîner le modèle :")
    print("      python scripts/train_model.py --data data/raw/sample_reclamations_train.csv")
    print("\n   2. Tester l'inférence :")
    print("      python scripts/run_inference.py --input data/raw/sample_reclamations_test.csv")
