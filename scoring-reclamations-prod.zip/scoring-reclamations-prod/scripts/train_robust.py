#!/usr/bin/env python3
"""
Script d'entraînement ROBUSTE avec validation complète
CORRIGE les failles d'overfitting du modèle original
"""
import argparse
import sys
from pathlib import Path
import pandas as pd
import logging

# Ajouter le répertoire parent au path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.data_loader import DataLoader
from src.models.scoring_engine import ScoringEngine
from src.models.optimizer import WeightOptimizer
from src.validation.robust_validator import RobustValidator
from src.validation.calibration import run_all_quality_tests
from src.monitoring.drift_detector import DriftDetector
from src.inference.metrics_extractor import integrate_with_training
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


def compute_thresholds_on_validation(
    df_val: pd.DataFrame,
    weights_df: pd.DataFrame,
    scoring_engine: ScoringEngine,
    conservative: bool = True
) -> pd.DataFrame:
    """
    CORRECTION CRITIQUE: Calcule seuils sur VALIDATION SET (pas train)
    
    Args:
        df_val: DataFrame de validation (JAMAIS vu pendant l'entraînement)
        weights_df: Poids optimaux
        scoring_engine: Moteur entraîné
        conservative: Mode conservateur (seuils plus stricts)
    
    Returns:
        DataFrame avec seuils par famille
    """
    logger.info("🎯 Calcul des seuils sur VALIDATION SET...")
    
    # Calculer scores sur validation
    df_val_scored = scoring_engine.compute_all_scores(df_val)
    
    # Appliquer poids optimaux
    for _, row in weights_df.iterrows():
        famille = row['Famille']
        mask = df_val_scored['Famille Produit'] == famille
        
        df_val_scored.loc[mask, 'score_final'] = (
            row['alpha'] * df_val_scored.loc[mask, 'score_type'] +
            row['beta'] * df_val_scored.loc[mask, 'score_risque'] +
            row['gamma'] * df_val_scored.loc[mask, 'score_signaletique']
        )
    
    # Calculer seuils par famille
    results = []
    
    for famille in weights_df['Famille'].unique():
        df_fam = df_val_scored[df_val_scored['Famille Produit'] == famille].copy()
        
        if len(df_fam) < 20:
            logger.warning(f"⚠️ Famille {famille}: trop peu d'échantillons ({len(df_fam)}), skip")
            continue
        
        # Séparer fondées et non fondées
        df_fondees = df_fam[df_fam['Fondée'] == 1]
        df_non_fondees = df_fam[df_fam['Fondée'] == 0]
        
        if len(df_fondees) == 0 or len(df_non_fondees) == 0:
            logger.warning(f"⚠️ Famille {famille}: classe manquante, utilisation seuils par défaut")
            seuil_bas = 0.35
            seuil_haut = 0.65
        else:
            # Seuil BAS: percentile des non-fondées (plus conservateur)
            if conservative:
                seuil_bas = df_non_fondees['score_final'].quantile(0.95)  # 95e percentile
            else:
                seuil_bas = df_non_fondees['score_final'].max()
            
            # Seuil HAUT: percentile des fondées
            if conservative:
                seuil_haut = df_fondees['score_final'].quantile(0.05)  # 5e percentile
            else:
                seuil_haut = df_fondees['score_final'].min()
            
            # Vérifier cohérence
            if seuil_bas >= seuil_haut:
                logger.warning(f"⚠️ Famille {famille}: chevauchement, ajustement")
                gap = 0.10
                mid = (seuil_bas + seuil_haut) / 2
                seuil_bas = mid - gap / 2
                seuil_haut = mid + gap / 2
        
        results.append({
            'Famille': famille,
            'seuil_bas': round(seuil_bas, 4),
            'seuil_haut': round(seuil_haut, 4),
            'n_samples_val': len(df_fam),
            'n_fondees': len(df_fondees),
            'n_non_fondees': len(df_non_fondees)
        })
        
        logger.info(f"   {famille}: [{seuil_bas:.3f}, {seuil_haut:.3f}] (n={len(df_fam)})")
    
    df_thresholds = pd.DataFrame(results)
    logger.info(f"✅ Seuils calculés pour {len(df_thresholds)} familles")
    
    return df_thresholds


def train_robust_model(
    data_path: str,
    output_dir: str = "artifacts",
    validation_mode: str = "strict",
    cv_folds: int = 5,
    run_calibration_test: bool = True,
    run_fairness_test: bool = True
):
    """
    Pipeline d'entraînement ROBUSTE avec toutes les améliorations
    
    Args:
        data_path: Chemin vers données
        output_dir: Répertoire de sortie
        validation_mode: "strict" (temporal split) ou "random"
        cv_folds: Nombre de folds pour CV
        run_calibration_test: Lancer test de calibration
        run_fairness_test: Lancer test de fairness
    """
    logger.info("=" * 70)
    logger.info("🚀 ENTRAÎNEMENT ROBUSTE - PRODUCTION-READY")
    logger.info("=" * 70)
    
    # ========== ÉTAPE 1: Chargement ==========
    logger.info("\n📥 ÉTAPE 1/8 : Chargement des données")
    loader = DataLoader()
    df = loader.load_data(data_path)
    df = loader.create_motif_column(df)
    df = loader.handle_missing_values(df)
    
    summary = loader.get_summary(df)
    logger.info(f"\n📊 Dataset: {summary['n_rows']:,} réclamations")
    logger.info(f"   Taux fondées: {summary.get('taux_fondees', 0):.1%}")
    
    # ========== ÉTAPE 2: Split Train/Val/Test ==========
    logger.info("\n🔀 ÉTAPE 2/8 : Split Train/Val/Test")
    validator = RobustValidator(
        train_ratio=0.70,
        val_ratio=0.15,
        test_ratio=0.15,
        cv_folds=cv_folds
    )
    
    if validation_mode == "strict":
        df_train, df_val, df_test = validator.temporal_split(df)
    else:
        # Split aléatoire (moins robuste)
        from sklearn.model_selection import train_test_split
        df_train, df_temp = train_test_split(df, test_size=0.30, random_state=42)
        df_val, df_test = train_test_split(df_temp, test_size=0.50, random_state=42)
    
    # ========== ÉTAPE 3: Entraînement ==========
    logger.info("\n🔧 ÉTAPE 3/8 : Entraînement du moteur")
    scoring_engine = ScoringEngine()
    scoring_engine.fit(df_train)
    
    # ========== ÉTAPE 4: Validation Croisée ==========
    logger.info("\n📊 ÉTAPE 4/8 : Validation Croisée")
    optimizer = WeightOptimizer()
    
    cv_results = validator.cross_validate(
        df_train,
        scoring_engine,
        optimizer
    )
    
    # Vérifier stabilité
    if cv_results['f1']['std'] > 0.05:
        logger.warning("⚠️ ALERTE: Modèle instable (F1 std > 0.05)")
    
    # ========== ÉTAPE 5: Optimisation Poids ==========
    logger.info("\n⚖️ ÉTAPE 5/8 : Optimisation des poids")
    df_train_scored = scoring_engine.compute_all_scores(df_train)
    weights_df = optimizer.optimize_all_families(df_train_scored)
    
    # ========== ÉTAPE 6: Calcul Seuils sur Validation ==========
    logger.info("\n🎯 ÉTAPE 6/8 : Calcul seuils sur VALIDATION SET")
    thresholds_df = compute_thresholds_on_validation(
        df_val,
        weights_df,
        scoring_engine,
        conservative=True
    )
    
    # ========== ÉTAPE 7: Tests de Qualité ==========
    logger.info("\n🧪 ÉTAPE 7/8 : Tests de Qualité")
    
    # Scorer le test set
    df_test_scored = scoring_engine.compute_all_scores(df_test)
    
    for _, row in weights_df.iterrows():
        famille = row['Famille']
        mask = df_test_scored['Famille Produit'] == famille
        
        df_test_scored.loc[mask, 'score_final'] = (
            row['alpha'] * df_test_scored.loc[mask, 'score_type'] +
            row['beta'] * df_test_scored.loc[mask, 'score_risque'] +
            row['gamma'] * df_test_scored.loc[mask, 'score_signaletique']
        )
    
    # Tests de calibration et fairness
    if run_calibration_test or run_fairness_test:
        quality_results = run_all_quality_tests(df_test_scored)
        
        if not quality_results['all_passed']:
            logger.warning("⚠️ ATTENTION: Certains tests de qualité ont échoué")
    
    # Métriques finales sur test set
    from sklearn.metrics import classification_report
    y_true = df_test_scored['Fondée']
    y_pred = (df_test_scored['score_final'] >= 0.5).astype(int)
    
    logger.info("\n📊 MÉTRIQUES FINALES (Test Set Holdout):")
    logger.info("\n" + classification_report(y_true, y_pred, digits=3))
    
    # ========== ÉTAPE 8: Sauvegarde ==========
    logger.info("\n💾 ÉTAPE 8/8 : Sauvegarde des artefacts")
    
    # Ré-entraîner sur train+val pour production
    logger.info("   Ré-entraînement sur train+val...")
    df_trainval = pd.concat([df_train, df_val])
    scoring_engine_final = ScoringEngine()
    scoring_engine_final.fit(df_trainval)
    
    # Sauvegarder
    integrate_with_training(
        scoring_engine=scoring_engine_final,
        weights_df=weights_df,
        thresholds_df=thresholds_df,
        df_train=df_trainval,
        output_dir=output_dir
    )
    
    # Sauvegarder métriques de test (pour monitoring)
    test_metrics = {
        'precision': float(y_pred[y_pred == 1].sum() / len(y_pred[y_pred == 1])) if (y_pred == 1).sum() > 0 else 0,
        'recall': float((y_pred & y_true).sum() / y_true.sum()) if y_true.sum() > 0 else 0,
        'f1': cv_results['f1']['mean']
    }
    
    import json
    with open(f"{output_dir}/test_metrics_baseline.json", 'w') as f:
        json.dump(test_metrics, f, indent=2)
    
    logger.info("\n" + "=" * 70)
    logger.info("✅ ENTRAÎNEMENT TERMINÉ AVEC SUCCÈS")
    logger.info("=" * 70)
    logger.info(f"\n✅ Modèle production-ready dans: {output_dir}/")
    logger.info("🎯 Prochaines étapes:")
    logger.info("   1. Tester l'inférence: python scripts/run_inference.py")
    logger.info("   2. Lancer monitoring: python scripts/monitoring_dashboard.py")
    logger.info("   3. Déployer en production")


def main():
    parser = argparse.ArgumentParser(
        description="Entraînement ROBUSTE avec validation complète"
    )
    parser.add_argument('--data', type=str, required=True, help="Chemin vers données")
    parser.add_argument('--output', type=str, default='artifacts', help="Répertoire de sortie")
    parser.add_argument('--validation-mode', type=str, default='strict', choices=['strict', 'random'])
    parser.add_argument('--cv-folds', type=int, default=5, help="Nombre de folds pour CV")
    parser.add_argument('--run-calibration-test', action='store_true', help="Lancer test de calibration")
    parser.add_argument('--run-fairness-test', action='store_true', help="Lancer test de fairness")
    
    args = parser.parse_args()
    
    try:
        train_robust_model(
            data_path=args.data,
            output_dir=args.output,
            validation_mode=args.validation_mode,
            cv_folds=args.cv_folds,
            run_calibration_test=args.run_calibration_test,
            run_fairness_test=args.run_fairness_test
        )
    except Exception as e:
        logger.error(f"❌ Erreur: {e}")
        raise


if __name__ == "__main__":
    main()
