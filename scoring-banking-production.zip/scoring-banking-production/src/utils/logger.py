"""
Module de logging pour le moteur de scoring
"""
import logging
import sys
from pathlib import Path
from typing import Optional
import yaml


def setup_logger(
    name: str = "scoring_engine",
    config_path: Optional[str] = None,
    log_level: str = "INFO"
) -> logging.Logger:
    """
    Configure et retourne un logger pour l'application
    
    Args:
        name: Nom du logger
        config_path: Chemin vers config.yaml (optionnel)
        log_level: Niveau de log (DEBUG, INFO, WARNING, ERROR)
    
    Returns:
        Logger configuré
    """
    # Charger la config si disponible
    if config_path and Path(config_path).exists():
        with open(config_path, 'r', encoding='utf-8') as f:
            config = yaml.safe_load(f)
            log_config = config.get('logging', {})
            log_level = log_config.get('level', log_level)
            log_format = log_config.get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
            log_file = log_config.get('file', 'logs/scoring_engine.log')
    else:
        log_format = '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        log_file = 'logs/scoring_engine.log'
    
    # Créer le répertoire de logs
    log_dir = Path(log_file).parent
    log_dir.mkdir(parents=True, exist_ok=True)
    
    # Créer le logger
    logger = logging.getLogger(name)
    logger.setLevel(getattr(logging, log_level.upper()))
    
    # Éviter les doublons de handlers
    if logger.handlers:
        return logger
    
    # Handler pour console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setLevel(logging.INFO)
    console_formatter = logging.Formatter(log_format)
    console_handler.setFormatter(console_formatter)
    
    # Handler pour fichier
    file_handler = logging.FileHandler(log_file, encoding='utf-8')
    file_handler.setLevel(logging.DEBUG)
    file_formatter = logging.Formatter(log_format)
    file_handler.setFormatter(file_formatter)
    
    # Ajouter les handlers
    logger.addHandler(console_handler)
    logger.addHandler(file_handler)
    
    return logger


def log_metrics(logger: logging.Logger, metrics: dict, prefix: str = ""):
    """
    Log des métriques de façon formatée
    
    Args:
        logger: Logger instance
        metrics: Dictionnaire de métriques
        prefix: Préfixe optionnel
    """
    logger.info(f"{prefix} Métriques:")
    for key, value in metrics.items():
        if isinstance(value, float):
            logger.info(f"  {key}: {value:.4f}")
        else:
            logger.info(f"  {key}: {value}")


def log_dataframe_info(logger: logging.Logger, df, name: str = "DataFrame"):
    """
    Log des informations sur un DataFrame
    
    Args:
        logger: Logger instance
        df: pandas DataFrame
        name: Nom du DataFrame
    """
    logger.info(f"{name} - Shape: {df.shape}")
    logger.info(f"{name} - Colonnes: {list(df.columns)}")
    logger.info(f"{name} - Valeurs manquantes: {df.isnull().sum().sum()}")
    logger.debug(f"{name} - Info:\n{df.info()}")
