"""
Extracteur de métriques pour l'inférence
Sauvegarde tous les artefacts nécessaires pour scorer de nouvelles réclamations
"""
import pandas as pd
import numpy as np
import pickle
import json
from pathlib import Path
from typing import Dict
from datetime import datetime
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class MetricsExtractor:
    """
    Extrait et sauvegarde toutes les métriques calculées pendant l'entraînement
    """
    
    def __init__(self, output_dir: str = "artifacts"):
        """
        Args:
            output_dir: Répertoire de sauvegarde des artefacts
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.metrics = {
            'bayesian_priors': {},
            'financial_stats': {},
            'client_stats': {},
            'optimal_weights': {},
            'decision_thresholds': {},
            'metadata': {}
        }
    
    def extract_from_scoring_engine(self, scoring_engine):
        """
        Extrait les métriques depuis un ScoringEngine entraîné
        
        Args:
            scoring_engine: Instance de ScoringEngine après fit()
        """
        logger.info("📊 Extraction des métriques du moteur de scoring...")
        
        self.metrics['bayesian_priors'] = scoring_engine.bayesian_priors
        self.metrics['financial_stats'] = scoring_engine.financial_stats
        self.metrics['client_stats'] = scoring_engine.client_stats
        
        logger.info("✅ Métriques extraites du moteur")
    
    def extract_optimal_weights(self, weights_df: pd.DataFrame):
        """
        Extrait les poids optimaux depuis le DataFrame d'optimisation
        
        Args:
            weights_df: DataFrame avec colonnes [Famille, alpha, beta, gamma, f1_score]
        """
        logger.info("⚖️ Extraction des poids optimaux...")
        
        optimal_weights = {}
        for _, row in weights_df.iterrows():
            optimal_weights[row['Famille']] = {
                'alpha': float(row['alpha']),
                'beta': float(row['beta']),
                'gamma': float(row['gamma']),
                'f1_score': float(row['f1_score'])
            }
        
        self.metrics['optimal_weights'] = optimal_weights
        logger.info(f"✅ Poids extraits pour {len(optimal_weights)} familles")
    
    def extract_decision_thresholds(self, thresholds_df: pd.DataFrame):
        """
        Extrait les seuils de décision depuis le DataFrame de seuils
        
        Args:
            thresholds_df: DataFrame avec colonnes [Famille, seuil_bas, seuil_haut]
        """
        logger.info("🎯 Extraction des seuils de décision...")
        
        thresholds = {}
        for _, row in thresholds_df.iterrows():
            thresholds[row['Famille']] = {
                'seuil_rejet_auto': float(row['seuil_bas']),
                'seuil_validation_auto': float(row['seuil_haut']),
                'n_samples': int(row.get('n_samples', 0)) if 'n_samples' in row else 0
            }
        
        self.metrics['decision_thresholds'] = thresholds
        logger.info(f"✅ Seuils extraits pour {len(thresholds)} familles")
    
    def add_metadata(self, df_train: pd.DataFrame):
        """
        Ajoute des métadonnées sur le dataset d'entraînement
        
        Args:
            df_train: DataFrame d'entraînement
        """
        logger.info("📝 Ajout des métadonnées...")
        
        self.metrics['metadata'] = {
            'training_size': len(df_train),
            'training_date': datetime.now().isoformat(),
            'families': list(df_train['Famille Produit'].unique()),
            'n_families': int(df_train['Famille Produit'].nunique()),
            'success_rate': float(df_train['Fondée'].mean()),
            'n_motifs': int(df_train.apply(
                lambda r: f"{r['Famille Produit']}|{r['Catégorie']}|{r['Sous-catégorie']}",
                axis=1
            ).nunique()),
            'version': '1.0.0',
            'columns_used': list(df_train.columns)
        }
        
        logger.info("✅ Métadonnées ajoutées")
    
    def save_all(self):
        """
        Sauvegarde tous les artefacts dans différents formats
        """
        logger.info("\n💾 Sauvegarde des artefacts...")
        
        # 1. Pickle (pour inférence Python)
        pickle_path = self.output_dir / 'metrics.pkl'
        with open(pickle_path, 'wb') as f:
            pickle.dump(self.metrics, f)
        logger.info(f"✅ Pickle sauvegardé : {pickle_path}")
        
        # 2. JSON (pour lisibilité et interopérabilité)
        json_path = self.output_dir / 'metrics.json'
        with open(json_path, 'w', encoding='utf-8') as f:
            json.dump(self.metrics, f, indent=2, ensure_ascii=False)
        logger.info(f"✅ JSON sauvegardé : {json_path}")
        
        # 3. Poids optimaux en CSV
        if self.metrics['optimal_weights']:
            weights_df = pd.DataFrame.from_dict(
                self.metrics['optimal_weights'], 
                orient='index'
            ).reset_index()
            weights_df.columns = ['Famille', 'alpha', 'beta', 'gamma', 'f1_score']
            weights_path = self.output_dir / 'optimal_weights.csv'
            weights_df.to_csv(weights_path, index=False)
            logger.info(f"✅ Poids sauvegardés : {weights_path}")
        
        # 4. Seuils de décision en CSV
        if self.metrics['decision_thresholds']:
            thresholds_df = pd.DataFrame.from_dict(
                self.metrics['decision_thresholds'], 
                orient='index'
            ).reset_index()
            thresholds_df.columns = ['Famille', 'seuil_rejet_auto', 'seuil_validation_auto', 'n_samples']
            thresholds_path = self.output_dir / 'decision_thresholds.csv'
            thresholds_df.to_csv(thresholds_path, index=False)
            logger.info(f"✅ Seuils sauvegardés : {thresholds_path}")
        
        # 5. Résumé en texte
        summary_path = self.output_dir / 'training_summary.txt'
        with open(summary_path, 'w', encoding='utf-8') as f:
            f.write("=" * 60 + "\n")
            f.write("RÉSUMÉ DE L'ENTRAÎNEMENT\n")
            f.write("=" * 60 + "\n\n")
            
            metadata = self.metrics.get('metadata', {})
            f.write(f"Date: {metadata.get('training_date', 'N/A')}\n")
            f.write(f"Taille dataset: {metadata.get('training_size', 0):,} réclamations\n")
            f.write(f"Nombre de familles: {metadata.get('n_families', 0)}\n")
            f.write(f"Nombre de motifs: {metadata.get('n_motifs', 0)}\n")
            f.write(f"Taux de succès global: {metadata.get('success_rate', 0):.2%}\n\n")
            
            f.write("Familles configurées:\n")
            for famille in metadata.get('families', []):
                f.write(f"  - {famille}\n")
            
            f.write("\n" + "=" * 60 + "\n")
        
        logger.info(f"✅ Résumé sauvegardé : {summary_path}")
        
        logger.info(f"\n🎉 Tous les artefacts sauvegardés dans {self.output_dir}/")
    
    def get_summary(self) -> Dict:
        """
        Retourne un résumé des métriques extraites
        
        Returns:
            Dictionnaire de statistiques
        """
        return {
            'n_motifs': len(self.metrics.get('bayesian_priors', {}).get('motif_probs', {})),
            'n_families': len(self.metrics.get('financial_stats', {})),
            'n_clients': len(self.metrics.get('client_stats', {}).get('client_success_rates', {})),
            'n_weight_configs': len(self.metrics.get('optimal_weights', {})),
            'n_threshold_configs': len(self.metrics.get('decision_thresholds', {})),
        }


def integrate_with_training(
    scoring_engine,
    weights_df: pd.DataFrame,
    thresholds_df: pd.DataFrame,
    df_train: pd.DataFrame,
    output_dir: str = "artifacts"
):
    """
    Fonction d'intégration facile pour le pipeline d'entraînement
    
    Args:
        scoring_engine: ScoringEngine entraîné
        weights_df: DataFrame des poids optimaux
        thresholds_df: DataFrame des seuils de décision
        df_train: DataFrame d'entraînement
        output_dir: Répertoire de sortie
    
    Returns:
        MetricsExtractor instance
    """
    extractor = MetricsExtractor(output_dir=output_dir)
    
    extractor.extract_from_scoring_engine(scoring_engine)
    extractor.extract_optimal_weights(weights_df)
    extractor.extract_decision_thresholds(thresholds_df)
    extractor.add_metadata(df_train)
    
    extractor.save_all()
    
    logger.info("\n📈 Résumé de l'extraction:")
    summary = extractor.get_summary()
    for key, value in summary.items():
        logger.info(f"  {key}: {value}")
    
    return extractor
