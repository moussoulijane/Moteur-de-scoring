"""
Tests de Calibration et Fairness pour validation du modèle
"""
import pandas as pd
import numpy as np
from typing import Dict, Tuple
from sklearn.metrics import precision_score, recall_score
import logging

logger = logging.getLogger(__name__)


class CalibrationTester:
    """
    Teste la calibration du modèle
    Un modèle bien calibré: si score=0.7, alors ~70% des réclamations sont fondées
    """
    
    def test_calibration(
        self,
        y_true: np.ndarray,
        y_pred_proba: np.ndarray,
        n_bins: int = 10
    ) -> Tuple[float, pd.DataFrame]:
        """
        Calcule l'Expected Calibration Error (ECE)
        
        Args:
            y_true: Vraies valeurs (0/1)
            y_pred_proba: Probabilités prédites [0, 1]
            n_bins: Nombre de bins
        
        Returns:
            (ece, calibration_curve_df)
        """
        logger.info(f"\n📊 Test de calibration ({n_bins} bins)...")
        
        bins = np.linspace(0, 1, n_bins + 1)
        bin_centers = (bins[:-1] + bins[1:]) / 2
        
        calibration_data = []
        total_ece = 0
        total_samples = len(y_true)
        
        for i in range(n_bins):
            bin_min, bin_max = bins[i], bins[i + 1]
            
            # Indices dans ce bin
            in_bin = (y_pred_proba >= bin_min) & (y_pred_proba < bin_max)
            
            if i == n_bins - 1:  # Dernier bin inclut la borne supérieure
                in_bin = (y_pred_proba >= bin_min) & (y_pred_proba <= bin_max)
            
            n_samples_bin = in_bin.sum()
            
            if n_samples_bin > 0:
                observed_rate = y_true[in_bin].mean()
                predicted_rate = y_pred_proba[in_bin].mean()
                error = abs(predicted_rate - observed_rate)
                
                # Contribution à ECE (pondérée par taille du bin)
                bin_weight = n_samples_bin / total_samples
                total_ece += bin_weight * error
                
                calibration_data.append({
                    'bin_center': bin_centers[i],
                    'bin_range': f"[{bin_min:.2f}, {bin_max:.2f}]",
                    'n_samples': n_samples_bin,
                    'predicted_prob': predicted_rate,
                    'observed_freq': observed_rate,
                    'error': error
                })
        
        df_calib = pd.DataFrame(calibration_data)
        
        logger.info(f"\n📈 Expected Calibration Error (ECE): {total_ece:.4f}")
        
        if total_ece < 0.05:
            logger.info("✅ Excellente calibration (ECE < 0.05)")
        elif total_ece < 0.10:
            logger.info("✅ Bonne calibration (ECE < 0.10)")
        elif total_ece < 0.15:
            logger.warning("⚠️ Calibration acceptable (ECE < 0.15)")
        else:
            logger.error(f"❌ Mauvaise calibration (ECE = {total_ece:.4f})")
        
        logger.info("\n📊 Détail par bin:")
        for _, row in df_calib.iterrows():
            logger.info(
                f"   {row['bin_range']}: "
                f"prédit={row['predicted_prob']:.3f}, "
                f"observé={row['observed_freq']:.3f}, "
                f"erreur={row['error']:.3f} "
                f"(n={row['n_samples']})"
            )
        
        return total_ece, df_calib


class FairnessTester:
    """
    Teste l'équité du modèle entre différents segments
    """
    
    def test_fairness(
        self,
        df: pd.DataFrame,
        segment_col: str = 'Segment',
        target_col: str = 'Fondée',
        decision_col: str = 'decision'
    ) -> Dict:
        """
        Teste l'équité entre segments
        
        Métriques:
        - Disparate Impact Ratio (DIR): ratio min/max des taux d'approbation
        - Statistical Parity Difference: différence des taux d'approbation
        
        Args:
            df: DataFrame avec prédictions
            segment_col: Colonne de segmentation
            target_col: Colonne cible
            decision_col: Colonne de décision
        
        Returns:
            Dict avec métriques de fairness
        """
        logger.info(f"\n⚖️ Test de fairness sur {segment_col}...")
        
        if segment_col not in df.columns:
            logger.warning(f"⚠️ Colonne {segment_col} absente, skip test")
            return {}
        
        segments = df[segment_col].unique()
        fairness_metrics = []
        
        for segment in segments:
            df_seg = df[df[segment_col] == segment]
            
            if len(df_seg) == 0:
                continue
            
            # Taux d'approbation (VALIDATION_AUTO)
            if decision_col in df_seg.columns:
                approval_rate = (df_seg[decision_col] == 'VALIDATION_AUTO').mean()
            else:
                # Fallback sur score >= seuil
                approval_rate = (df_seg.get('score_final', 0) >= 0.7).mean()
            
            # Taux de rejet
            if decision_col in df_seg.columns:
                rejection_rate = (df_seg[decision_col] == 'REJET_AUTO').mean()
            else:
                rejection_rate = (df_seg.get('score_final', 0) <= 0.3).mean()
            
            # Métriques de performance
            if target_col in df_seg.columns and 'score_final' in df_seg.columns:
                y_true = df_seg[target_col]
                y_pred = (df_seg['score_final'] >= 0.5).astype(int)
                
                precision = precision_score(y_true, y_pred, zero_division=0)
                recall = recall_score(y_true, y_pred, zero_division=0)
            else:
                precision, recall = 0, 0
            
            fairness_metrics.append({
                'segment': segment,
                'n': len(df_seg),
                'approval_rate': approval_rate,
                'rejection_rate': rejection_rate,
                'precision': precision,
                'recall': recall,
                'score_mean': df_seg.get('score_final', pd.Series([0])).mean()
            })
        
        df_fairness = pd.DataFrame(fairness_metrics)
        
        # Calculer Disparate Impact Ratio
        if len(df_fairness) > 1:
            max_approval = df_fairness['approval_rate'].max()
            min_approval = df_fairness['approval_rate'].min()
            
            if max_approval > 0:
                dir_ratio = min_approval / max_approval
            else:
                dir_ratio = 1.0
            
            # Statistical Parity Difference
            spd = max_approval - min_approval
        else:
            dir_ratio = 1.0
            spd = 0.0
        
        logger.info("\n📊 Métriques par segment:")
        logger.info(df_fairness.to_string(index=False))
        
        logger.info(f"\n📈 Métriques globales de fairness:")
        logger.info(f"   Disparate Impact Ratio (DIR): {dir_ratio:.3f}")
        logger.info(f"   Statistical Parity Difference: {spd:.3f}")
        
        # Évaluation
        if dir_ratio >= 0.80:
            logger.info("✅ Pas de biais significatif détecté (DIR >= 0.80)")
        elif dir_ratio >= 0.70:
            logger.warning("⚠️ Biais potentiel (DIR < 0.80)")
        else:
            logger.error(f"❌ Biais significatif détecté (DIR = {dir_ratio:.3f} < 0.70)")
        
        return {
            'disparate_impact_ratio': dir_ratio,
            'statistical_parity_difference': spd,
            'segment_metrics': df_fairness.to_dict('records'),
            'fair': dir_ratio >= 0.80
        }


def run_all_quality_tests(
    df_test: pd.DataFrame,
    target_col: str = 'Fondée',
    score_col: str = 'score_final'
) -> Dict:
    """
    Lance tous les tests de qualité
    
    Args:
        df_test: DataFrame de test avec scores et vérité terrain
        target_col: Colonne cible
        score_col: Colonne de score
    
    Returns:
        Dict avec tous les résultats
    """
    logger.info("=" * 60)
    logger.info("SUITE COMPLÈTE DE TESTS DE QUALITÉ")
    logger.info("=" * 60)
    
    results = {}
    
    # 1. Test de calibration
    calib_tester = CalibrationTester()
    ece, calib_curve = calib_tester.test_calibration(
        y_true=df_test[target_col].values,
        y_pred_proba=df_test[score_col].values
    )
    
    results['calibration'] = {
        'ece': ece,
        'calibration_curve': calib_curve.to_dict('records'),
        'passed': ece < 0.10
    }
    
    # 2. Test de fairness
    fairness_tester = FairnessTester()
    fairness_results = fairness_tester.test_fairness(df_test)
    
    results['fairness'] = fairness_results
    
    # 3. Résumé global
    all_tests_passed = (
        results['calibration']['passed'] and
        results['fairness'].get('fair', False)
    )
    
    logger.info("\n" + "=" * 60)
    logger.info("RÉSUMÉ DES TESTS")
    logger.info("=" * 60)
    logger.info(f"Calibration: {'✅ PASS' if results['calibration']['passed'] else '❌ FAIL'}")
    logger.info(f"Fairness: {'✅ PASS' if results['fairness'].get('fair', False) else '❌ FAIL'}")
    logger.info(f"\nÉvaluation globale: {'✅ TOUS LES TESTS PASSÉS' if all_tests_passed else '⚠️ CERTAINS TESTS ONT ÉCHOUÉ'}")
    logger.info("=" * 60)
    
    results['all_passed'] = all_tests_passed
    
    return results
