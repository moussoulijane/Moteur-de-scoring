"""
Module de chargement et validation des données
"""
import pandas as pd
import numpy as np
from pathlib import Path
from typing import List, Optional, Tuple
import yaml
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


class DataLoader:
    """Charge et valide les données de réclamations"""
    
    def __init__(self, config_path: str = "config/config.yaml"):
        """
        Args:
            config_path: Chemin vers le fichier de configuration
        """
        self.config_path = config_path
        self.config = self._load_config()
        
    def _load_config(self) -> dict:
        """Charge la configuration"""
        if Path(self.config_path).exists():
            with open(self.config_path, 'r', encoding='utf-8') as f:
                return yaml.safe_load(f)
        return {}
    
    def load_data(
        self, 
        filepath: str,
        validate: bool = True
    ) -> pd.DataFrame:
        """
        Charge les données depuis un fichier CSV ou Excel
        
        Args:
            filepath: Chemin vers le fichier
            validate: Si True, valide les colonnes requises
        
        Returns:
            DataFrame chargé
        """
        logger.info(f"📥 Chargement des données depuis {filepath}")
        
        file_path = Path(filepath)
        
        if not file_path.exists():
            raise FileNotFoundError(f"Fichier introuvable : {filepath}")
        
        # Charger selon l'extension
        if file_path.suffix == '.csv':
            df = pd.read_csv(filepath, encoding='utf-8')
        elif file_path.suffix in ['.xlsx', '.xls']:
            df = pd.read_excel(filepath)
        else:
            raise ValueError(f"Format non supporté : {file_path.suffix}")
        
        logger.info(f"✅ {len(df)} lignes chargées")
        
        if validate:
            self._validate_data(df)
        
        return df
    
    def _validate_data(self, df: pd.DataFrame):
        """
        Valide la présence des colonnes requises
        
        Args:
            df: DataFrame à valider
        """
        required_cols = self.config.get('data', {}).get('required_columns', [])
        
        if not required_cols:
            logger.warning("⚠️ Aucune colonne requise définie dans la config")
            return
        
        missing_cols = [col for col in required_cols if col not in df.columns]
        
        if missing_cols:
            raise ValueError(
                f"❌ Colonnes manquantes : {missing_cols}\n"
                f"Colonnes disponibles : {list(df.columns)}"
            )
        
        logger.info(f"✅ Validation réussie : toutes les colonnes requises présentes")
    
    def prepare_training_data(
        self, 
        df: pd.DataFrame,
        test_size: float = 0.2,
        random_state: int = 42
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """
        Prépare les données pour l'entraînement
        
        Args:
            df: DataFrame complet
            test_size: Proportion pour le test set
            random_state: Seed pour reproductibilité
        
        Returns:
            (df_train, df_test)
        """
        from sklearn.model_selection import train_test_split
        
        logger.info(f"🔀 Séparation train/test ({1-test_size:.0%}/{test_size:.0%})")
        
        # Vérifier la présence de la colonne cible
        if 'Fondée' not in df.columns:
            raise ValueError("Colonne 'Fondée' absente - impossible de créer train/test")
        
        # Stratification par famille et par résultat
        stratify_col = None
        if 'Famille Produit' in df.columns:
            df['_stratify'] = df['Famille Produit'].astype(str) + '_' + df['Fondée'].astype(str)
            stratify_col = df['_stratify']
        
        df_train, df_test = train_test_split(
            df,
            test_size=test_size,
            random_state=random_state,
            stratify=stratify_col
        )
        
        # Nettoyer la colonne temporaire
        if '_stratify' in df_train.columns:
            df_train = df_train.drop('_stratify', axis=1)
            df_test = df_test.drop('_stratify', axis=1)
        
        logger.info(f"✅ Train: {len(df_train)} | Test: {len(df_test)}")
        
        return df_train, df_test
    
    def create_motif_column(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Crée la colonne motif_complet (Famille|Catégorie|Sous-catégorie)
        
        Args:
            df: DataFrame
        
        Returns:
            DataFrame avec colonne motif_complet
        """
        if all(col in df.columns for col in ['Famille Produit', 'Catégorie', 'Sous-catégorie']):
            df['motif_complet'] = (
                df['Famille Produit'].astype(str) + '|' +
                df['Catégorie'].astype(str) + '|' +
                df['Sous-catégorie'].astype(str)
            )
            logger.debug(f"✅ Colonne motif_complet créée ({df['motif_complet'].nunique()} motifs uniques)")
        else:
            logger.warning("⚠️ Impossible de créer motif_complet - colonnes manquantes")
        
        return df
    
    def handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Gère les valeurs manquantes selon la configuration
        
        Args:
            df: DataFrame
        
        Returns:
            DataFrame nettoyé
        """
        missing_config = self.config.get('data', {}).get('missing_values', {})
        
        # Montant demandé
        if 'Montant demandé' in df.columns:
            default_montant = missing_config.get('montant_default', 0)
            n_missing = df['Montant demandé'].isnull().sum()
            if n_missing > 0:
                logger.warning(f"⚠️ {n_missing} montants manquants remplis avec {default_montant}")
                df['Montant demandé'] = df['Montant demandé'].fillna(default_montant)
        
        # PNB
        if 'PNB analytique (vision commerciale) cumulé' in df.columns:
            default_pnb = missing_config.get('pnb_default', 0)
            n_missing = df['PNB analytique (vision commerciale) cumulé'].isnull().sum()
            if n_missing > 0:
                logger.warning(f"⚠️ {n_missing} PNB manquants remplis avec {default_pnb}")
                df['PNB analytique (vision commerciale) cumulé'] = df['PNB analytique (vision commerciale) cumulé'].fillna(default_pnb)
        
        # Ancienneté
        if 'anciennete_annees' in df.columns:
            default_anciennete = missing_config.get('anciennete_default', 0)
            n_missing = df['anciennete_annees'].isnull().sum()
            if n_missing > 0:
                logger.warning(f"⚠️ {n_missing} anciennetés manquantes remplies avec {default_anciennete}")
                df['anciennete_annees'] = df['anciennete_annees'].fillna(default_anciennete)
        
        return df
    
    def get_summary(self, df: pd.DataFrame) -> dict:
        """
        Génère un résumé statistique du dataset
        
        Args:
            df: DataFrame
        
        Returns:
            Dictionnaire de statistiques
        """
        summary = {
            'n_rows': len(df),
            'n_columns': len(df.columns),
            'memory_usage_mb': df.memory_usage(deep=True).sum() / 1024**2,
        }
        
        if 'Famille Produit' in df.columns:
            summary['n_familles'] = df['Famille Produit'].nunique()
            summary['familles'] = df['Famille Produit'].value_counts().to_dict()
        
        if 'Fondée' in df.columns:
            summary['taux_fondees'] = df['Fondée'].mean()
            summary['n_fondees'] = df['Fondée'].sum()
            summary['n_non_fondees'] = len(df) - df['Fondée'].sum()
        
        if 'Montant demandé' in df.columns:
            summary['montant_moyen'] = df['Montant demandé'].mean()
            summary['montant_median'] = df['Montant demandé'].median()
            summary['montant_max'] = df['Montant demandé'].max()
        
        return summary
