"""
Détecteur de Data Drift pour monitoring production
Détecte les changements de distribution qui nécessitent un réentraînement
"""
import pandas as pd
import numpy as np
from typing import Dict, List
from scipy.stats import ks_2samp, chi2_contingency
import logging
import json
from datetime import datetime

logger = logging.getLogger(__name__)


class DriftDetector:
    """
    Détecte les changements de distribution entre données de référence et nouvelles données
    
    Méthodes:
    - KS test pour features numériques
    - Chi2 test pour features catégorielles
    - Alertes automatiques
    """
    
    def __init__(
        self,
        reference_data: pd.DataFrame,
        alpha: float = 0.05,
        alert_threshold: float = 0.10
    ):
        """
        Args:
            reference_data: Données de référence (train set)
            alpha: Seuil de significativité pour tests statistiques
            alert_threshold: Seuil pour déclencher alertes (% features avec drift)
        """
        self.reference_data = reference_data
        self.alpha = alpha
        self.alert_threshold = alert_threshold
        
        # Calculer statistiques de référence
        self._compute_reference_statistics()
        
        logger.info(f"✅ DriftDetector initialisé avec {len(reference_data)} échantillons de référence")
    
    def _compute_reference_statistics(self):
        """Calcule statistiques sur données de référence"""
        self.reference_stats = {}
        
        numeric_cols = self.reference_data.select_dtypes(include=[np.number]).columns
        
        for col in numeric_cols:
            self.reference_stats[col] = {
                'mean': self.reference_data[col].mean(),
                'std': self.reference_data[col].std(),
                'median': self.reference_data[col].median(),
                'q25': self.reference_data[col].quantile(0.25),
                'q75': self.reference_data[col].quantile(0.75)
            }
    
    def check_drift(
        self,
        new_data: pd.DataFrame,
        features_to_check: List[str] = None
    ) -> Dict:
        """
        Vérifie le drift entre référence et nouvelles données
        
        Args:
            new_data: Nouvelles données à vérifier
            features_to_check: Liste de features à vérifier (None = toutes)
        
        Returns:
            Dict avec résultats des tests de drift
        """
        logger.info(f"\n🔍 Détection de drift sur {len(new_data)} nouveaux échantillons...")
        
        if features_to_check is None:
            features_to_check = [
                'Montant demandé',
                'PNB analytique (vision commerciale) cumulé',
                'anciennete_annees'
            ]
        
        drift_results = {}
        n_drift_detected = 0
        
        for feature in features_to_check:
            if feature not in self.reference_data.columns or feature not in new_data.columns:
                logger.warning(f"⚠️ Feature {feature} absente, skip")
                continue
            
            # KS test pour features numériques
            if pd.api.types.is_numeric_dtype(self.reference_data[feature]):
                drift_info = self._ks_test(feature, new_data)
            else:
                drift_info = self._chi2_test(feature, new_data)
            
            drift_results[feature] = drift_info
            
            if drift_info['drift_detected']:
                n_drift_detected += 1
                logger.warning(
                    f"⚠️ DRIFT détecté sur {feature}: "
                    f"p={drift_info['p_value']:.4f} < {self.alpha}"
                )
        
        # Résumé global
        drift_ratio = n_drift_detected / len(features_to_check) if features_to_check else 0
        
        summary = {
            'timestamp': datetime.now().isoformat(),
            'n_features_checked': len(features_to_check),
            'n_drift_detected': n_drift_detected,
            'drift_ratio': drift_ratio,
            'alert_triggered': drift_ratio > self.alert_threshold,
            'features': drift_results
        }
        
        logger.info(f"\n📊 Résumé drift:")
        logger.info(f"   Features vérifiées: {len(features_to_check)}")
        logger.info(f"   Drift détecté: {n_drift_detected} ({drift_ratio:.1%})")
        
        if summary['alert_triggered']:
            logger.error(
                f"🚨 ALERTE DRIFT: {drift_ratio:.1%} des features ont drifté "
                f"(seuil: {self.alert_threshold:.1%})"
            )
            self._send_alert(summary)
        
        return summary
    
    def _ks_test(self, feature: str, new_data: pd.DataFrame) -> Dict:
        """
        Kolmogorov-Smirnov test pour features numériques
        
        H0: Les deux distributions sont identiques
        Si p < alpha, on rejette H0 (drift détecté)
        """
        ref_values = self.reference_data[feature].dropna()
        new_values = new_data[feature].dropna()
        
        statistic, p_value = ks_2samp(ref_values, new_values)
        
        # Calculer shift des statistiques
        ref_mean = ref_values.mean()
        new_mean = new_values.mean()
        mean_shift = (new_mean - ref_mean) / ref_mean if ref_mean != 0 else 0
        
        return {
            'test': 'ks_test',
            'statistic': float(statistic),
            'p_value': float(p_value),
            'drift_detected': p_value < self.alpha,
            'reference_mean': float(ref_mean),
            'new_mean': float(new_mean),
            'mean_shift_pct': float(mean_shift * 100),
            'reference_median': float(ref_values.median()),
            'new_median': float(new_values.median())
        }
    
    def _chi2_test(self, feature: str, new_data: pd.DataFrame) -> Dict:
        """
        Chi-carré test pour features catégorielles
        """
        ref_counts = self.reference_data[feature].value_counts()
        new_counts = new_data[feature].value_counts()
        
        # Aligner les catégories
        all_categories = set(ref_counts.index) | set(new_counts.index)
        
        ref_freq = [ref_counts.get(cat, 0) for cat in all_categories]
        new_freq = [new_counts.get(cat, 0) for cat in all_categories]
        
        # Contingency table
        contingency_table = np.array([ref_freq, new_freq])
        
        try:
            statistic, p_value, dof, expected = chi2_contingency(contingency_table)
        except:
            statistic, p_value = 0, 1.0
        
        return {
            'test': 'chi2_test',
            'statistic': float(statistic),
            'p_value': float(p_value),
            'drift_detected': p_value < self.alpha,
            'reference_categories': len(ref_counts),
            'new_categories': len(new_counts)
        }
    
    def _send_alert(self, drift_summary: Dict):
        """Envoie une alerte (email, Slack, etc.)"""
        # Sauvegarder l'alerte
        alert_file = f"logs/drift_alert_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        try:
            with open(alert_file, 'w') as f:
                json.dump(drift_summary, f, indent=2)
            logger.info(f"✅ Alerte sauvegardée: {alert_file}")
        except Exception as e:
            logger.error(f"❌ Erreur sauvegarde alerte: {e}")
    
    def get_drift_report(self, drift_summary: Dict) -> str:
        """Génère un rapport textuel du drift"""
        report = []
        report.append("=" * 60)
        report.append("RAPPORT DE DÉTECTION DE DRIFT")
        report.append("=" * 60)
        report.append(f"\nDate: {drift_summary['timestamp']}")
        report.append(f"Features vérifiées: {drift_summary['n_features_checked']}")
        report.append(f"Drift détecté: {drift_summary['n_drift_detected']} ({drift_summary['drift_ratio']:.1%})")
        
        if drift_summary['alert_triggered']:
            report.append("\n🚨 ALERTE: Réentraînement recommandé")
        
        report.append("\n" + "-" * 60)
        report.append("DÉTAILS PAR FEATURE:")
        report.append("-" * 60)
        
        for feature, info in drift_summary['features'].items():
            report.append(f"\n{feature}:")
            report.append(f"  Test: {info['test']}")
            report.append(f"  p-value: {info['p_value']:.4f}")
            report.append(f"  Drift: {'OUI' if info['drift_detected'] else 'NON'}")
            
            if 'mean_shift_pct' in info:
                report.append(f"  Shift moyen: {info['mean_shift_pct']:+.1f}%")
        
        report.append("\n" + "=" * 60)
        
        return "\n".join(report)


class PerformanceMonitor:
    """
    Monitore la performance du modèle en production
    Détecte les dégradations de métriques
    """
    
    def __init__(self, baseline_metrics: Dict):
        """
        Args:
            baseline_metrics: Métriques de référence (test set)
        """
        self.baseline = baseline_metrics
        self.history = []
        
        logger.info("✅ PerformanceMonitor initialisé")
    
    def check_performance(
        self,
        df_recent: pd.DataFrame,
        degradation_threshold: float = 0.05
    ) -> Dict:
        """
        Vérifie si performance se dégrade
        
        Args:
            df_recent: Données récentes avec prédictions et vérité terrain
            degradation_threshold: Seuil de dégradation (5% = 0.05)
        
        Returns:
            Dict avec métriques actuelles et alertes
        """
        from sklearn.metrics import precision_score, recall_score, f1_score
        
        logger.info(f"\n📊 Vérification performance sur {len(df_recent)} réclamations...")
        
        # Calculer métriques actuelles
        y_true = df_recent['Fondée']
        y_pred = (df_recent['score_final'] >= 0.5).astype(int)
        
        current_metrics = {
            'precision': precision_score(y_true, y_pred, zero_division=0),
            'recall': recall_score(y_true, y_pred, zero_division=0),
            'f1': f1_score(y_true, y_pred, zero_division=0)
        }
        
        # Comparer au baseline
        degradations = {}
        
        for metric, value in current_metrics.items():
            baseline_value = self.baseline.get(metric, 0)
            
            if baseline_value > 0:
                degradation = (baseline_value - value) / baseline_value
                
                if degradation > degradation_threshold:
                    degradations[metric] = {
                        'baseline': baseline_value,
                        'current': value,
                        'degradation_pct': degradation * 100
                    }
        
        # Résumé
        summary = {
            'timestamp': datetime.now().isoformat(),
            'current_metrics': current_metrics,
            'baseline_metrics': self.baseline,
            'degradations': degradations,
            'alert_triggered': len(degradations) > 0
        }
        
        # Log résultats
        logger.info("\n📈 Métriques actuelles vs baseline:")
        for metric, value in current_metrics.items():
            baseline_value = self.baseline.get(metric, 0)
            change = ((value - baseline_value) / baseline_value * 100) if baseline_value > 0 else 0
            logger.info(f"   {metric}: {value:.3f} (baseline: {baseline_value:.3f}, {change:+.1f}%)")
        
        if degradations:
            logger.error("\n🚨 ALERTE PERFORMANCE:")
            for metric, info in degradations.items():
                logger.error(
                    f"   {metric}: {info['baseline']:.3f} → {info['current']:.3f} "
                    f"(-{info['degradation_pct']:.1f}%)"
                )
        
        # Historiser
        self.history.append(summary)
        
        return summary
