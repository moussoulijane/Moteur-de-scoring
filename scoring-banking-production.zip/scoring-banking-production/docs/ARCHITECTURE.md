# 🏗️ Architecture du Système

## Vue d'Ensemble

Le système de scoring est organisé en **6 modules principaux** avec une séparation claire des responsabilités.

```
┌─────────────────────────────────────────────────────────────┐
│                      SCRIPTS (Workflows)                     │
├─────────────────────────────────────────────────────────────┤
│  01_prepare → 02_train → 03_evaluate → 04_score → 05_analyze│
└─────────────────────────────────────────────────────────────┘
                           ↓ utilise ↓
┌─────────────────────────────────────────────────────────────┐
│                    MODULES SRC (Logique)                     │
├─────────────────────────────────────────────────────────────┤
│  data/ │ features/ │ models/ │ validation/ │ inference/     │
│  monitoring/ │ utils/                                        │
└─────────────────────────────────────────────────────────────┘
                           ↓ produit ↓
┌─────────────────────────────────────────────────────────────┐
│                   ARTIFACTS (Résultats)                      │
├─────────────────────────────────────────────────────────────┤
│  models/ │ metrics/ │ weights/ │ thresholds/ │ reports/    │
└─────────────────────────────────────────────────────────────┘
```

---

## Modules Détaillés

### 1. `src/data/` - Gestion des Données

**Responsabilités :**
- Chargement de fichiers Excel/CSV
- Nettoyage et validation
- Création de features de base
- Split train/val/test

**Fichiers :**
- `data_loader.py` : Chargement et première transformation
- `data_cleaner.py` : Nettoyage et validation
- `data_splitter.py` : Split temporel/stratifié

### 2. `src/models/` - Modèles de Scoring

**Responsabilités :**
- Calcul des 3 scores (Type, Risque, Signal)
- Optimisation des poids par famille
- Gestion des statistiques bayésiennes

**Fichiers :**
- `scoring_engine.py` : Moteur principal de scoring
- `optimizer.py` : Optimisation poids (Grid Search + CV)
- `bayesian_optimizer.py` : Optimisation paramètre C

### 3. `src/validation/` - Tests et Validation

**Responsabilités :**
- Validation croisée K-fold
- Tests de calibration (ECE)
- Tests de fairness (DIR)
- Calcul d'intervalles de confiance

**Fichiers :**
- `robust_validator.py` : Validation croisée et CI
- `calibration.py` : Tests ECE + fairness
- `metrics.py` : Calcul de métriques

### 4. `src/inference/` - Prédictions

**Responsabilités :**
- Scoring de nouvelles réclamations
- Export des décisions
- Extraction de métriques

**Fichiers :**
- `predictor.py` : Scoring batch
- `metrics_extractor.py` : Export artefacts

### 5. `src/monitoring/` - Monitoring Production

**Responsabilités :**
- Détection de drift (KS/Chi2 tests)
- Suivi des performances
- Génération d'alertes

**Fichiers :**
- `drift_detector.py` : Détection data drift
- `performance_monitor.py` : Suivi métriques

### 6. `src/utils/` - Utilitaires

**Responsabilités :**
- Logging structuré
- Gestion de configuration
- Helpers divers

**Fichiers :**
- `logger.py` : Configuration logging
- `config.py` : Gestion config YAML

---

## Flux de Données

### Entraînement

```
data/raw/modeling_base2.xlsx
    │
    ↓ [01_prepare_data.py]
    │
data/processed/
    ├── train.csv (70%)
    ├── validation.csv (15%)
    └── test.csv (15%)
    │
    ↓ [02_train_model.py]
    │
artifacts/
    ├── models/model_latest.pkl
    ├── weights/optimal_weights.csv
    └── thresholds/decision_thresholds.csv
```

### Inférence

```
data/raw/nouvelles_reclamations.xlsx
    │
    ↓ [04_score_predictions.py]
    │
    ├─ artifacts/models/model_latest.pkl
    │
    ↓
data/results/
    ├── predictions.csv (toutes)
    └── predictions_auto.csv (RPA)
```

---

## Algorithmes Clés

### 1. Score Bayésien (Score_Type)

```python
P(fondée | motif) = (succès_motif + C × P_global) / (total_motif + C)
```

Où :
- `C = 15` : Paramètre de lissage
- `P_global` : Taux de succès global

### 2. Optimisation des Poids

```python
for α, β, γ in grid:
    scores_cv = cross_validate(α, β, γ, folds=5)
    if mean(scores_cv) > best_score:
        best_weights = (α, β, γ)
```

### 3. Calcul des Seuils

```python
# Sur validation set (données jamais vues)
seuil_bas = quantile(scores_non_fondées, 0.95)
seuil_haut = quantile(scores_fondées, 0.05)
```

---

## Dépendances entre Modules

```
data_loader
    ↓
scoring_engine ← optimizer
    ↓            ↓
robust_validator
    ↓
predictor ← metrics_extractor
    ↓
drift_detector
```

---

## Points d'Extension

### Ajouter une Nouvelle Feature

1. Créer dans `src/features/feature_engineer.py`
2. Intégrer dans `scoring_engine.compute_score_*()`
3. Ajouter tests dans `tests/test_features.py`

### Ajouter un Nouveau Test

1. Créer dans `src/validation/`
2. Intégrer dans `03_evaluate_model.py`
3. Documenter dans `docs/`

### Modifier l'Algorithme

1. Modifier `src/models/scoring_engine.py`
2. Re-valider avec `03_evaluate_model.py`
3. Vérifier impact sur métriques

---

## Conventions de Code

- **Nommage** : snake_case pour variables/fonctions
- **Docstrings** : Google style
- **Type hints** : Obligatoire pour fonctions publiques
- **Logging** : Via logger configuré
- **Exceptions** : Spécifiques et documentées

---

## Configuration

Tous les paramètres sont dans `config/config.yaml` :

```yaml
model:
  bayesian_smoothing: 15
  
validation:
  cv_folds: 5
  
thresholds:
  conservative_mode: true
  
monitoring:
  drift_alpha: 0.05
```

---

**Version :** 2.0.0  
**Dernière mise à jour :** Janvier 2026
