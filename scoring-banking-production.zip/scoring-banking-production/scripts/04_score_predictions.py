#!/usr/bin/env python3
"""
ÉTAPE 4 : SCORING DES PRÉDICTIONS
Usage: python scripts/04_score_predictions.py --input data/raw/nouvelles_reclamations.xlsx
"""
import argparse
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.inference.predictor import ReclamationScorer
from src.data.data_loader import DataLoader
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

def score_predictions(input_path, model_path='artifacts/metrics.pkl', output_path='data/results/predictions.csv'):
    logger.info("=" * 80)
    logger.info("🔮 ÉTAPE 4 : SCORING DES PRÉDICTIONS")
    logger.info("=" * 80)
    
    # Charger modèle
    logger.info(f"\n📥 Chargement du modèle: {model_path}")
    try:
        scorer = ReclamationScorer(model_path)
        logger.info("✅ Modèle chargé")
    except FileNotFoundError:
        logger.error(f"❌ Modèle non trouvé. Lancez: python scripts/02_train_model.py")
        sys.exit(1)
    
    # Charger données
    logger.info(f"\n📂 Chargement des données: {input_path}")
    loader = DataLoader()
    df = loader.load_data(input_path)
    df = loader.create_motif_column(df)
    df = loader.handle_missing_values(df)
    logger.info(f"✅ {len(df):,} réclamations chargées")
    
    # Scorer
    logger.info(f"\n🔄 Scoring en cours...")
    results = scorer.score_batch(df)
    logger.info(f"✅ {len(results):,} réclamations scorées")
    
    # Stats
    logger.info("\n📊 Décisions:")
    for decision, count in results['decision'].value_counts().items():
        logger.info(f"   {decision}: {count:,} ({count/len(results)*100:.1f}%)")
    
    # Export
    logger.info(f"\n💾 Export...")
    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    results.to_csv(output_path, index=False)
    logger.info(f"✅ Résultats: {output_path}")
    
    # Export auto
    auto = results[results['decision'].isin(['REJET_AUTO', 'VALIDATION_AUTO'])]
    auto_path = output_path.replace('.csv', '_auto.csv')
    auto.to_csv(auto_path, index=False)
    logger.info(f"✅ Décisions auto: {auto_path} ({len(auto):,})")
    
    logger.info("\n" + "=" * 80)
    logger.info("✅ SCORING TERMINÉ")
    logger.info("=" * 80)
    logger.info("\n💡 Prochaine étape:")
    logger.info("   python scripts/05_analyze_results.py")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--input', required=True, help="Fichier à scorer")
    parser.add_argument('--model', default='artifacts/metrics.pkl')
    parser.add_argument('--output', default='data/results/predictions.csv')
    args = parser.parse_args()
    score_predictions(args.input, args.model, args.output)
