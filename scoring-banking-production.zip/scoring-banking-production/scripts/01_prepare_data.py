#!/usr/bin/env python3
"""
ÉTAPE 1 : PRÉPARATION DES DONNÉES
==================================
Charge, nettoie et split les données en train/validation/test

Usage:
    python scripts/01_prepare_data.py --input data/raw/votre_fichier.xlsx
"""
import argparse
import sys
from pathlib import Path
import pandas as pd

# Ajouter le répertoire parent au path
sys.path.insert(0, str(Path(__file__).parent.parent))

from src.data.data_loader import DataLoader
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


def prepare_data(input_path: str, output_dir: str = "data/processed"):
    """
    Prépare les données pour l'entraînement
    
    Args:
        input_path: Chemin vers fichier source (.csv ou .xlsx)
        output_dir: Répertoire de sortie
    """
    logger.info("=" * 80)
    logger.info("📊 ÉTAPE 1 : PRÉPARATION DES DONNÉES")
    logger.info("=" * 80)
    
    # 1. Charger les données
    logger.info(f"\n📂 Chargement depuis: {input_path}")
    loader = DataLoader()
    
    try:
        df = loader.load_data(input_path)
        logger.info(f"✅ {len(df):,} lignes chargées")
    except FileNotFoundError:
        logger.error(f"❌ Fichier non trouvé: {input_path}")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Erreur lors du chargement: {e}")
        sys.exit(1)
    
    # 2. Afficher les statistiques
    summary = loader.get_summary(df)
    logger.info(f"\n📊 Statistiques:")
    logger.info(f"   Nombre de lignes: {summary['n_rows']:,}")
    logger.info(f"   Nombre de colonnes: {summary['n_cols']}")
    if 'taux_fondees' in summary:
        logger.info(f"   Taux fondées: {summary['taux_fondees']:.1%}")
    if 'n_familles' in summary:
        logger.info(f"   Nombre de familles: {summary['n_familles']}")
    
    # 3. Créer colonne motif
    logger.info(f"\n🔧 Création colonne motif...")
    df = loader.create_motif_column(df)
    logger.info(f"✅ Colonne 'motif_complet' créée")
    
    # 4. Gérer valeurs manquantes
    logger.info(f"\n🧹 Gestion des valeurs manquantes...")
    df = loader.handle_missing_values(df)
    logger.info(f"✅ Valeurs manquantes traitées")
    
    # 5. Split temporel train/val/test (70/15/15)
    logger.info(f"\n🔀 Split train/validation/test...")
    
    # Trier par date si disponible
    date_col = 'Date de Qualification'
    if date_col in df.columns:
        df = df.sort_values(date_col).reset_index(drop=True)
        logger.info(f"   Tri chronologique sur '{date_col}'")
    else:
        logger.warning(f"   Colonne {date_col} absente, split aléatoire")
        df = df.sample(frac=1, random_state=42).reset_index(drop=True)
    
    # Calcul des indices
    n = len(df)
    train_end = int(n * 0.70)
    val_end = train_end + int(n * 0.15)
    
    df_train = df[:train_end].copy()
    df_val = df[train_end:val_end].copy()
    df_test = df[val_end:].copy()
    
    logger.info(f"   Train: {len(df_train):,} ({len(df_train)/n:.1%})")
    logger.info(f"   Val:   {len(df_val):,} ({len(df_val)/n:.1%})")
    logger.info(f"   Test:  {len(df_test):,} ({len(df_test)/n:.1%})")
    
    # 6. Sauvegarder
    logger.info(f"\n💾 Sauvegarde dans {output_dir}/...")
    Path(output_dir).mkdir(parents=True, exist_ok=True)
    
    train_path = f"{output_dir}/train.csv"
    val_path = f"{output_dir}/validation.csv"
    test_path = f"{output_dir}/test.csv"
    
    df_train.to_csv(train_path, index=False, encoding='utf-8')
    df_val.to_csv(val_path, index=False, encoding='utf-8')
    df_test.to_csv(test_path, index=False, encoding='utf-8')
    
    logger.info(f"✅ Fichiers créés:")
    logger.info(f"   - {train_path}")
    logger.info(f"   - {val_path}")
    logger.info(f"   - {test_path}")
    
    logger.info("\n" + "=" * 80)
    logger.info("✅ PRÉPARATION TERMINÉE")
    logger.info("=" * 80)
    logger.info("\n💡 Prochaine étape:")
    logger.info("   python scripts/02_train_model.py")


def main():
    parser = argparse.ArgumentParser(
        description="Prépare les données pour l'entraînement"
    )
    parser.add_argument(
        '--input',
        type=str,
        required=True,
        help="Chemin vers fichier source (.csv ou .xlsx)"
    )
    parser.add_argument(
        '--output',
        type=str,
        default='data/processed',
        help="Répertoire de sortie (défaut: data/processed)"
    )
    
    args = parser.parse_args()
    
    try:
        prepare_data(args.input, args.output)
    except Exception as e:
        logger.error(f"❌ Erreur: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
