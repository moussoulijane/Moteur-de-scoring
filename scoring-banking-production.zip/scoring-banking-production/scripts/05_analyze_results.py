#!/usr/bin/env python3
"""
ÉTAPE 5 : ANALYSE DES RÉSULTATS
Usage: python scripts/05_analyze_results.py
"""
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))
from src.utils.logger import setup_logger

logger = setup_logger(__name__)

def analyze_results(predictions_path='data/results/predictions.csv'):
    logger.info("=" * 80)
    logger.info("📊 ÉTAPE 5 : ANALYSE DES RÉSULTATS")
    logger.info("=" * 80)
    
    df = pd.read_csv(predictions_path)
    logger.info(f"\n✅ {len(df):,} prédictions chargées")
    
    # Taux automatisation
    n_rejet = len(df[df['decision'] == 'REJET_AUTO'])
    n_validation = len(df[df['decision'] == 'VALIDATION_AUTO'])
    n_audit = len(df[df['decision'] == 'AUDIT_HUMAIN'])
    n_auto = n_rejet + n_validation
    taux_auto = (n_auto / len(df)) * 100
    
    logger.info(f"\n📈 TAUX D'AUTOMATISATION:")
    logger.info(f"   REJET_AUTO:      {n_rejet:,} ({n_rejet/len(df)*100:.1f}%)")
    logger.info(f"   VALIDATION_AUTO: {n_validation:,} ({n_validation/len(df)*100:.1f}%)")
    logger.info(f"   AUDIT_HUMAIN:    {n_audit:,} ({n_audit/len(df)*100:.1f}%)")
    logger.info(f"\n   ✅ AUTOMATISÉ:   {n_auto:,} ({taux_auto:.1f}%)")
    
    # Faux positifs/négatifs
    if 'Fondée' in df.columns:
        fp = len(df[(df['decision'] == 'VALIDATION_AUTO') & (df['Fondée'] == 0)])
        fn = len(df[(df['decision'] == 'REJET_AUTO') & (df['Fondée'] == 1)])
        logger.info(f"\n❌ ERREURS:")
        logger.info(f"   Faux Positifs:  {fp:,} ({fp/n_validation*100:.2f}%)")
        logger.info(f"   Faux Négatifs:  {fn:,} ({fn/n_rejet*100:.2f}%)")
    
    # Par famille
    if 'Famille Produit' in df.columns:
        logger.info(f"\n📊 PAR FAMILLE:")
        famille_stats = []
        for famille in df['Famille Produit'].unique():
            df_fam = df[df['Famille Produit'] == famille]
            n_auto_fam = len(df_fam[df_fam['decision'].isin(['REJET_AUTO', 'VALIDATION_AUTO'])])
            famille_stats.append({
                'Famille': famille,
                'Total': len(df_fam),
                'Automatisé': n_auto_fam,
                'Taux_%': round(n_auto_fam / len(df_fam) * 100, 1)
            })
        
        df_familles = pd.DataFrame(famille_stats).sort_values('Automatisé', ascending=False)
        for rang, (_, row) in enumerate(df_familles.iterrows(), 1):
            emoji = "🥇" if rang == 1 else "🥈" if rang == 2 else "🥉" if rang == 3 else ""
            logger.info(f"   {emoji} {row['Famille']}: {row['Automatisé']:,} ({row['Taux_%']:.1f}%)")
        
        output = 'data/results/analyse_automatisation.csv'
        df_familles.to_csv(output, index=False)
        logger.info(f"\n✅ Analyse exportée: {output}")
    
    logger.info("\n" + "=" * 80)
    logger.info("✅ ANALYSE TERMINÉE")
    logger.info("=" * 80)

if __name__ == "__main__":
    analyze_results()
