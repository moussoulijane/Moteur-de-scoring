#!/usr/bin/env python3
"""
ÉTAPE 2 : ENTRAÎNEMENT DU MODÈLE
=================================
Entraîne le modèle avec validation croisée et optimisation des poids

Usage:
    python scripts/02_train_model.py
"""
import sys
from pathlib import Path
import pandas as pd

sys.path.insert(0, str(Path(__file__).parent.parent))

from src.models.scoring_engine import ScoringEngine
from src.models.optimizer import WeightOptimizer
from src.validation.robust_validator import RobustValidator
from src.inference.metrics_extractor import integrate_with_training
from src.utils.logger import setup_logger

logger = setup_logger(__name__)


def compute_thresholds_on_validation(df_val, weights_df, scoring_engine, conservative=True):
    """Calcule seuils sur validation set"""
    logger.info("🎯 Calcul des seuils sur VALIDATION SET...")
    
    df_val_scored = scoring_engine.compute_all_scores(df_val)
    
    # Appliquer poids optimaux
    for _, row in weights_df.iterrows():
        famille = row['Famille']
        mask = df_val_scored['Famille Produit'] == famille
        
        df_val_scored.loc[mask, 'score_final'] = (
            row['alpha'] * df_val_scored.loc[mask, 'score_type'] +
            row['beta'] * df_val_scored.loc[mask, 'score_risque'] +
            row['gamma'] * df_val_scored.loc[mask, 'score_signaletique']
        )
    
    results = []
    for famille in weights_df['Famille'].unique():
        df_fam = df_val_scored[df_val_scored['Famille Produit'] == famille].copy()
        
        if len(df_fam) < 20:
            continue
        
        df_fondees = df_fam[df_fam['Fondée'] == 1]
        df_non_fondees = df_fam[df_fam['Fondée'] == 0]
        
        if len(df_fondees) == 0 or len(df_non_fondees) == 0:
            seuil_bas = 0.35
            seuil_haut = 0.65
        else:
            if conservative:
                seuil_bas = df_non_fondees['score_final'].quantile(0.95)
                seuil_haut = df_fondees['score_final'].quantile(0.05)
            else:
                seuil_bas = df_non_fondees['score_final'].max()
                seuil_haut = df_fondees['score_final'].min()
            
            if seuil_bas >= seuil_haut:
                gap = 0.10
                mid = (seuil_bas + seuil_haut) / 2
                seuil_bas = mid - gap / 2
                seuil_haut = mid + gap / 2
        
        results.append({
            'Famille': famille,
            'seuil_bas': round(seuil_bas, 4),
            'seuil_haut': round(seuil_haut, 4),
            'n_samples_val': len(df_fam)
        })
        
        logger.info(f"   {famille}: [{seuil_bas:.3f}, {seuil_haut:.3f}]")
    
    return pd.DataFrame(results)


def train_model():
    """Entraîne le modèle complet"""
    logger.info("=" * 80)
    logger.info("🎓 ÉTAPE 2 : ENTRAÎNEMENT DU MODÈLE")
    logger.info("=" * 80)
    
    # 1. Charger données
    logger.info(f"\n📂 Chargement des données...")
    df_train = pd.read_csv('data/processed/train.csv')
    df_val = pd.read_csv('data/processed/validation.csv')
    logger.info(f"✅ Train: {len(df_train):,}, Val: {len(df_val):,}")
    
    # 2. Entraîner scoring engine
    logger.info(f"\n🔧 Entraînement du scoring engine...")
    engine = ScoringEngine()
    engine.fit(df_train)
    logger.info("✅ Moteur entraîné")
    
    # 3. Validation croisée
    logger.info(f"\n📊 Validation croisée 5-fold...")
    validator = RobustValidator(cv_folds=5)
    optimizer = WeightOptimizer()
    
    cv_results = validator.cross_validate(df_train, engine, optimizer)
    logger.info(f"✅ F1-Score CV: {cv_results['f1']['mean']:.3f} ± {cv_results['f1']['std']:.3f}")
    
    # 4. Optimiser poids
    logger.info(f"\n⚖️ Optimisation des poids...")
    df_train_scored = engine.compute_all_scores(df_train)
    weights_df = optimizer.optimize_all_families(df_train_scored)
    logger.info(f"✅ Poids optimisés pour {len(weights_df)} familles")
    
    # 5. Calculer seuils
    thresholds_df = compute_thresholds_on_validation(df_val, weights_df, engine)
    
    # 6. Sauvegarder
    logger.info(f"\n💾 Sauvegarde des artefacts...")
    integrate_with_training(engine, weights_df, thresholds_df, df_train, output_dir='artifacts')
    
    logger.info("\n" + "=" * 80)
    logger.info("✅ ENTRAÎNEMENT TERMINÉ")
    logger.info("=" * 80)
    logger.info("\n💡 Prochaine étape:")
    logger.info("   python scripts/03_evaluate_model.py")


if __name__ == "__main__":
    try:
        train_model()
    except FileNotFoundError as e:
        logger.error(f"❌ Fichier non trouvé: {e}")
        logger.info("\n💡 Lancez d'abord: python scripts/01_prepare_data.py")
        sys.exit(1)
    except Exception as e:
        logger.error(f"❌ Erreur: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
