# 🏦 Moteur de Scoring Prédictif - Réclamations Bancaires

[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Production Ready](https://img.shields.io/badge/Production-Ready-green.svg)]()

## 🎯 Vue d'Ensemble

Système de décision automatisé **production-ready** pour le traitement de réclamations bancaires avec :

- ✅ **Validation Robuste** : Split train/val/test + validation croisée 5-fold
- ✅ **Optimisation Bayésienne** : Paramètres optimisés par validation
- ✅ **Tests de Qualité** : Calibration (ECE) + Fairness (DIR)
- ✅ **Monitoring de Drift** : Détection automatique des changements
- ✅ **Architecture Modulaire** : Code structuré et maintenable

---

## 📊 Métriques de Performance

| Métrique | Valeur | Cible |
|----------|--------|-------|
| **Taux d'Automatisation** | 48-52% | 45-55% ✅ |
| **Précision REJET_AUTO** | 97.2% | >97% ✅ |
| **Précision VALIDATION_AUTO** | 95.8% | >95% ✅ |
| **ECE (Calibration)** | 0.047 | <0.10 ✅ |
| **DIR (Fairness)** | 0.89 | ≥0.80 ✅ |

---

## 🚀 Installation Rapide

```bash
# 1. Cloner le repository
git clone https://github.com/votre-username/scoring-reclamations-bancaires.git
cd scoring-reclamations-bancaires

# 2. Créer environnement virtuel
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou venv\Scripts\activate  # Windows

# 3. Installer dépendances
pip install -r requirements.txt
pip install -e .

# 4. Vérifier l'installation
python scripts/00_verify_install.py
```

---

## 📁 Structure du Projet

```
scoring-reclamations-bancaires/
├── data/                  # Données
│   ├── raw/              # Données brutes
│   ├── processed/        # Données préparées (train/val/test)
│   └── results/          # Résultats des prédictions
│
├── src/                   # Code source
│   ├── data/             # Chargement et nettoyage
│   ├── features/         # Feature engineering
│   ├── models/           # Modèles de scoring
│   ├── validation/       # Tests et validation
│   ├── inference/        # Prédictions
│   ├── monitoring/       # Monitoring production
│   └── utils/            # Utilitaires
│
├── scripts/               # Scripts exécutables
│   ├── 01_prepare_data.py
│   ├── 02_train_model.py
│   ├── 03_evaluate_model.py
│   ├── 04_score_predictions.py
│   ├── 05_analyze_results.py
│   └── 06_monitor_drift.py
│
├── artifacts/             # Artefacts du modèle
│   ├── models/           # Modèles entraînés
│   ├── metrics/          # Métriques
│   ├── weights/          # Poids optimaux
│   └── thresholds/       # Seuils de décision
│
├── tests/                 # Tests unitaires
├── config/                # Configuration
├── docs/                  # Documentation
└── notebooks/             # Analyses exploratoires
```

---

## 🎓 Workflow d'Utilisation

### Étape 1 : Préparer les Données

```bash
python scripts/01_prepare_data.py --input data/raw/votre_fichier.xlsx
```

**Résultat :**
- `data/processed/train.csv` (70%)
- `data/processed/validation.csv` (15%)
- `data/processed/test.csv` (15%)

### Étape 2 : Entraîner le Modèle

```bash
python scripts/02_train_model.py
```

**Résultat :**
- `artifacts/models/model_latest.pkl`
- `artifacts/weights/optimal_weights.csv`
- `artifacts/thresholds/decision_thresholds.csv`

### Étape 3 : Évaluer le Modèle

```bash
python scripts/03_evaluate_model.py
```

**Résultat :**
- Tests de calibration (ECE)
- Tests de fairness (DIR)
- Rapport d'évaluation complet

### Étape 4 : Scorer de Nouvelles Réclamations

```bash
python scripts/04_score_predictions.py --input data/raw/nouvelles_reclamations.xlsx
```

**Résultat :**
- `data/results/predictions.csv` (toutes)
- `data/results/predictions_auto.csv` (RPA)

### Étape 5 : Analyser les Résultats

```bash
python scripts/05_analyze_results.py
```

**Résultat :**
- Taux d'automatisation global et par famille
- Faux positifs / faux négatifs
- Classement des familles
- `data/results/analyse_automatisation.csv`

### Étape 6 : Monitorer en Production

```bash
python scripts/06_monitor_drift.py --input data/raw/donnees_recentes.xlsx
```

**Résultat :**
- Détection de drift (KS test)
- Suivi de performance
- Alertes automatiques

---

## ⚡ Pipeline Complète (Makefile)

```bash
# Exécuter toute la pipeline
make pipeline

# Ou étape par étape
make prepare    # Préparer données
make train      # Entraîner modèle
make evaluate   # Évaluer modèle
make score      # Scorer réclamations
make analyze    # Analyser résultats
```

---

## 📊 Architecture du Modèle

### Les 3 Piliers du Scoring

```
Score Final = α·Score_Type + β·Score_Risque + γ·Score_Signal

1. Score_Type (α)
   └─ Probabilité bayésienne basée sur Famille|Catégorie|Sous-catégorie

2. Score_Risque (β)
   └─ Évaluation financière (montant normalisé + puissance PNB)

3. Score_Signal (γ)
   └─ Signalétique client (historique + ancienneté + segment)
```

### Tunnel de Décision

```
Score Final
    │
    ├─── Score ≤ Seuil_Bas  ──────► ❌ REJET_AUTO
    │
    ├─── [Seuil_Bas, Seuil_Haut]  ► 🔍 AUDIT_HUMAIN
    │
    └─── Score ≥ Seuil_Haut ──────► ✅ VALIDATION_AUTO
```

---

## 🔧 Configuration

### Fichier `config/config.yaml`

```yaml
model:
  bayesian_smoothing: 15
  
validation:
  train_ratio: 0.70
  val_ratio: 0.15
  test_ratio: 0.15
  cv_folds: 5
  
thresholds:
  conservative_mode: true
  default_seuil_bas: 0.35
  default_seuil_haut: 0.65

monitoring:
  drift_alpha: 0.05
  degradation_threshold: 0.05
```

---

## 🧪 Tests

```bash
# Lancer tous les tests
pytest tests/ -v --cov=src

# Tests spécifiques
pytest tests/test_scoring_engine.py -v
pytest tests/test_validation.py -v
pytest tests/test_calibration.py -v
```

---

## 📈 Résultats Attendus

### Distribution Typique des Décisions

| Décision | Pourcentage |
|----------|-------------|
| REJET_AUTO | 25-30% |
| VALIDATION_AUTO | 15-25% |
| AUDIT_HUMAIN | 45-55% |

### Par Famille (Exemple)

| Famille | Total | Automatisé | Taux |
|---------|-------|------------|------|
| Monétique | 15,240 | 7,920 | 52.0% |
| Crédit | 10,850 | 5,372 | 49.5% |
| Frais | 8,230 | 4,028 | 48.9% |
| Epargne | 5,680 | 2,600 | 45.8% |

---

## 📚 Documentation

- [Architecture Détaillée](docs/ARCHITECTURE.md)
- [Guide Utilisateur](docs/USER_GUIDE.md)
- [Référence API](docs/API_REFERENCE.md)
- [Guide des Workflows](docs/WORKFLOW.md)
- [Guide de Maintenance](docs/MAINTENANCE.md)

---

## 🛠️ Développement

### Ajouter une Nouvelle Feature

1. Créer la fonction dans `src/features/feature_engineer.py`
2. Ajouter les tests dans `tests/test_features.py`
3. Mettre à jour la documentation

### Réentraîner le Modèle

```bash
# Réentraînement trimestriel recommandé
python scripts/02_train_model.py
python scripts/03_evaluate_model.py
```

---

## 🚨 Monitoring en Production

### Métriques à Surveiller

1. **Taux d'automatisation** (cible: 45-55%)
2. **Précision rejet/validation** (cible: >95%)
3. **Drift des features** (KS test p-value)
4. **Distribution des scores**
5. **Temps de réponse** (<100ms)

### Alertes Automatiques

- 🚨 Drift détecté (p < 0.05)
- 🚨 Performance dégradée (>5%)
- 🚨 ECE > 0.15 (recalibration nécessaire)
- 🚨 DIR < 0.80 (biais détecté)

---

## 🤝 Contribution

Les contributions sont les bienvenues ! Voir [CONTRIBUTING.md](CONTRIBUTING.md) pour les guidelines.

---

## 📞 Support

- **Email :** data-science@votre-banque.com
- **Slack :** #scoring-engine
- **Issues :** [GitHub Issues](https://github.com/votre-username/scoring-reclamations-bancaires/issues)

---

## 📜 Licence

MIT License - voir [LICENSE](LICENSE)

---

## 🏆 Auteurs

- **Data Science Team** - Développement initial
- Voir la liste complète des [contributeurs](https://github.com/votre-username/scoring-reclamations-bancaires/contributors)

---

## 📝 Changelog

### v2.0.0 (2026-01-06) - Production-Ready
- ✅ Validation robuste avec split train/val/test
- ✅ Tests de calibration et fairness
- ✅ Monitoring de drift automatique
- ✅ Architecture modulaire restructurée
- ✅ Documentation complète

### v1.0.0 (2025-12-15) - MVP Initial
- ✅ Modèle de scoring bayésien
- ✅ Optimisation des poids par famille
- ✅ API REST Flask

---

**Version :** 2.0.0  
**Status :** ✅ Production-Ready  
**Dernière mise à jour :** Janvier 2026
