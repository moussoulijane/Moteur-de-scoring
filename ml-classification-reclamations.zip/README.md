# 🏦 Classification des Réclamations Bancaires

[![Python 3.9+](https://img.shields.io/badge/python-3.9+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)

> Système de Machine Learning production-ready pour la classification automatique des réclamations bancaires (Fondée / Non Fondée).

## 📋 Description

Ce projet implémente un pipeline complet de ML pour automatiser le traitement des réclamations bancaires. Le système prédit si une réclamation doit être **fondée** (acceptée) ou **non fondée** (rejetée), avec un système de décision tri-classes permettant un taux d'automatisation contrôlé.

### Objectifs Business

| Métrique | Objectif | Description |
|----------|----------|-------------|
| Précision Rejet | ≥97% | Minimiser les faux rejets (insatisfaction client) |
| Précision Validation | ≥95% | Minimiser les fausses validations (coût financier) |
| Taux Automatisation | 45-55% | Équilibre entre automatisation et audit humain |
| Temps Inférence | <100ms | Performance temps réel |

## 🚀 Installation

```bash
# Cloner le repository
git clone https://github.com/votre-repo/ml-classification-reclamations.git
cd ml-classification-reclamations

# Créer un environnement virtuel
python -m venv venv
source venv/bin/activate  # Linux/Mac
# ou: venv\Scripts\activate  # Windows

# Installer les dépendances
pip install -r requirements.txt
```

## 📊 Structure du Projet

```
ml-classification-reclamations/
├── configs/
│   └── config.yaml              # Configuration générale
├── data/
│   ├── raw/                     # Données brutes
│   ├── processed/               # Données préparées
│   └── features/                # Feature store
├── src/
│   ├── data/
│   │   ├── loader.py           # Chargement des données
│   │   └── preprocessor.py     # Pipeline de preprocessing
│   ├── models/
│   │   ├── trainer.py          # Entraînement des modèles
│   │   └── calibrator.py       # Calibration & seuils
│   ├── evaluation/
│   │   └── metrics.py          # Métriques de performance
│   └── utils/
│       └── report_generator.py  # Génération des rapports
├── notebooks/                    # Notebooks d'analyse
├── outputs/                      # Résultats et rapports
├── tests/                        # Tests unitaires
├── run_pipeline.py              # Script principal
└── requirements.txt
```

## 🎯 Usage

### Entraînement Complet

```bash
# Exécuter le pipeline complet
python run_pipeline.py --data data/raw/reclamations.xlsx --output outputs/

# Avec optimisation des hyperparamètres
python run_pipeline.py --data data/raw/reclamations.xlsx --optimize

# Spécifier les modèles à entraîner
python run_pipeline.py --data data/raw/reclamations.xlsx --models lightgbm xgboost
```

### Usage Programmatique

```python
from run_pipeline import MLPipeline

# Initialiser le pipeline
pipeline = MLPipeline(config_path="configs/config.yaml")

# Exécuter
results = pipeline.run(
    data_path="data/raw/reclamations.xlsx",
    output_dir="outputs/",
    models=['lightgbm', 'xgboost'],
    optimize=True
)

# Accéder aux résultats
print(f"Meilleur modèle: {pipeline.best_model_name}")
print(f"F1-Score: {pipeline.performance_report.classification.f1_weighted:.4f}")
```

## 📈 Livrables

Le pipeline génère automatiquement 3 livrables:

### 1. Résumé de Performance (`performance_summary.xlsx`)
- Métriques principales (Accuracy, F1, Précision, Recall, AUC)
- Métriques business (taux d'automatisation, seuils)
- Comparaison des modèles
- Matrice de confusion

### 2. Performance par Catégorie (`performance_by_category.xlsx`)
- Performance par Famille Produit
- Performance par Catégorie
- Visualisations associées

### 3. Analyse des Erreurs (`errors_analysis.xlsx`)
- Liste des Faux Positifs (fausses validations)
- Liste des Faux Négatifs (faux rejets)
- Statistiques d'erreurs par catégorie

## 🔧 Configuration

Le fichier `configs/config.yaml` permet de personnaliser:

```yaml
# Colonnes de données
data:
  target_column: "Fondée"
  categorical_features:
    high_cardinality: ["motif_complet", "Sous-catégorie"]
    low_cardinality: ["Famille Produit", "Segment Client"]

# Seuils de décision
thresholds:
  constraints:
    min_precision_rejection: 0.97
    min_precision_validation: 0.95
    target_automation_rate: [0.45, 0.55]

# Modèle
models:
  primary_model: "lightgbm"
```

## 📊 Features Supportées

### Features Catégorielles
- **Hiérarchie Produit**: Famille, Catégorie, Sous-catégorie, motif_complet
- **Client**: Segment, Type Relation, Ancienneté

### Features Numériques
- Montant demandé
- PNB (Produit Net Bancaire)
- Ancienneté client
- Historique réclamations

### Features Dérivées (automatiques)
- Target encoding des motifs
- Ratios financiers (montant/PNB)
- Features temporelles (mois, trimestre)
- Flags de montants élevés

## 🧪 Tests

```bash
# Exécuter tous les tests
pytest tests/ -v

# Avec couverture
pytest tests/ --cov=src --cov-report=html
```

## 📝 Workflow ML

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐
│   Données   │───▶│ Preprocessing │───▶│  Training   │
│   Brutes    │    │   Pipeline    │    │   Modèles   │
└─────────────┘    └──────────────┘    └─────────────┘
                                              │
                   ┌──────────────┐            │
                   │  Calibration │◀───────────┘
                   │  + Seuils    │
                   └──────────────┘
                          │
        ┌─────────────────┼─────────────────┐
        ▼                 ▼                 ▼
  ┌───────────┐    ┌───────────┐    ┌───────────┐
  │ REJET_AUTO│    │   AUDIT   │    │VALID_AUTO │
  │  (proba   │    │  (proba   │    │  (proba   │
  │  <seuil)  │    │  entre)   │    │  >seuil)  │
  └───────────┘    └───────────┘    └───────────┘
```

## 🔐 Modèles Disponibles

| Modèle | Description | Recommandé |
|--------|-------------|------------|
| LightGBM | Rapide, gère les catégorielles | ✅ Production |
| XGBoost | Très robuste | ✅ Alternative |
| Random Forest | Baseline interprétable | 🔄 Comparaison |
| Logistic Regression | Baseline simple | 🔄 Comparaison |

## 📈 Métriques Calculées

### Classification
- Accuracy, Precision, Recall, F1-Score
- AUC-ROC, AUC-PR
- Matthews Correlation Coefficient

### Calibration
- Expected Calibration Error (ECE)
- Brier Score

### Business
- Taux d'automatisation
- Précision des décisions automatiques
- Coût total des erreurs

### Fairness
- Disparate Impact Ratio (DIR)
- Equal Opportunity Difference

## 🚀 Déploiement (Production)

```bash
# Construire l'image Docker
docker build -t ml-reclamations:v1.0 .

# Lancer l'API
docker run -p 8000:8000 ml-reclamations:v1.0
```

API Endpoints:
- `POST /predict` - Prédiction unique
- `POST /predict_batch` - Prédictions batch
- `GET /health` - Health check
- `GET /model_info` - Métadonnées du modèle

## 📚 Documentation Additionnelle

- [Guide de Preprocessing](docs/PREPROCESSING.md)
- [Guide des Modèles](docs/MODELS.md)
- [Guide de Déploiement](docs/DEPLOYMENT.md)

## 🤝 Contribution

1. Fork le projet
2. Créer une branche (`git checkout -b feature/AmazingFeature`)
3. Commit (`git commit -m 'Add AmazingFeature'`)
4. Push (`git push origin feature/AmazingFeature`)
5. Ouvrir une Pull Request

## 📄 License

Distribué sous licence MIT. Voir `LICENSE` pour plus d'informations.

## 👥 Contact

MOUSSAAB - [@votreprofil](https://github.com/votreprofil)

Lien du projet: [https://github.com/votre-repo/ml-classification-reclamations](https://github.com/votre-repo/ml-classification-reclamations)
