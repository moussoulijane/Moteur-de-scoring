#!/usr/bin/env python3
"""
Générateur de Livrables - Classification Réclamations Bancaires
================================================================
Script autonome pour générer les 3 livrables demandés:
1. Résumé de performance Excel
2. Visualisations par Famille Produit et Catégorie
3. Fichier Excel avec Faux Positifs et Faux Négatifs

Usage:
    python generate_deliverables.py --data path/to/data.xlsx --output path/to/outputs
"""

import pandas as pd
import numpy as np
import argparse
import logging
from pathlib import Path
from datetime import datetime
import sys
import warnings
warnings.filterwarnings('ignore')

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


def detect_target_column(df: pd.DataFrame) -> str:
    """Détecte automatiquement la colonne cible."""
    candidates = ['Fondée', 'Fondee', 'fondée', 'fondee', 'Target', 'target', 'Label', 'label']
    
    for col in df.columns:
        if col in candidates:
            return col
        if 'fond' in col.lower():
            return col
    
    for col in df.columns:
        unique = df[col].dropna().unique()
        if len(unique) == 2 and set(unique).issubset({0, 1, '0', '1', 'Oui', 'Non', 'oui', 'non'}):
            return col
    
    raise ValueError("Impossible de détecter la colonne cible. Vérifiez vos données.")


def detect_category_columns(df: pd.DataFrame) -> list:
    """Détecte les colonnes catégorielles pour l'analyse."""
    candidates = [
        'Famille Produit', 'Famille', 'famille_produit',
        'Catégorie', 'Categorie', 'Category',
        'Sous-catégorie', 'Sous-categorie', 'SubCategory',
        'motif_complet', 'Motif', 'motif'
    ]
    
    found = []
    for col in df.columns:
        if col in candidates:
            found.append(col)
        elif any(x in col.lower() for x in ['famille', 'categ', 'motif', 'produit']):
            if df[col].dtype == 'object' and df[col].nunique() < 100:
                found.append(col)
    
    return found[:3]


def prepare_features(df: pd.DataFrame, target_col: str) -> tuple:
    """Prépare les features pour l'entraînement."""
    from sklearn.preprocessing import LabelEncoder
    
    df_clean = df.copy()
    y = df_clean[target_col].copy()
    
    if y.dtype == 'object':
        y = y.apply(lambda x: 1 if str(x).lower() in ['oui', 'yes', '1', 'fondée', 'fondee', 'true'] else 0)
    y = y.astype(int)
    
    cols_to_drop = [target_col]
    for col in df_clean.columns:
        if 'date' in col.lower() or 'id' in col.lower():
            cols_to_drop.append(col)
    
    X = df_clean.drop(columns=[c for c in cols_to_drop if c in df_clean.columns])
    
    label_encoders = {}
    for col in X.select_dtypes(include=['object']).columns:
        le = LabelEncoder()
        X[col] = X[col].astype(str).fillna('MISSING')
        X[col] = le.fit_transform(X[col])
        label_encoders[col] = le
    
    X = X.fillna(X.median())
    
    return X, y, label_encoders


def train_model(X_train, y_train, X_val, y_val):
    """Entraîne un modèle LightGBM."""
    import lightgbm as lgb
    
    params = {
        'objective': 'binary',
        'metric': 'auc',
        'boosting_type': 'gbdt',
        'num_leaves': 31,
        'learning_rate': 0.05,
        'feature_fraction': 0.9,
        'bagging_fraction': 0.8,
        'bagging_freq': 5,
        'verbose': -1,
        'n_estimators': 300,
    }
    
    model = lgb.LGBMClassifier(**params)
    model.fit(
        X_train, y_train,
        eval_set=[(X_val, y_val)],
        callbacks=[lgb.early_stopping(50, verbose=False)]
    )
    
    return model


def calculate_metrics(y_true, y_pred, y_proba=None):
    """Calcule les métriques de performance."""
    from sklearn.metrics import (
        accuracy_score, precision_score, recall_score, f1_score,
        roc_auc_score, confusion_matrix, brier_score_loss
    )
    
    metrics = {
        'accuracy': accuracy_score(y_true, y_pred),
        'precision_class_0': precision_score(y_true, y_pred, pos_label=0, zero_division=0),
        'precision_class_1': precision_score(y_true, y_pred, pos_label=1, zero_division=0),
        'recall_class_0': recall_score(y_true, y_pred, pos_label=0, zero_division=0),
        'recall_class_1': recall_score(y_true, y_pred, pos_label=1, zero_division=0),
        'f1_class_0': f1_score(y_true, y_pred, pos_label=0, zero_division=0),
        'f1_class_1': f1_score(y_true, y_pred, pos_label=1, zero_division=0),
        'f1_weighted': f1_score(y_true, y_pred, average='weighted', zero_division=0),
        'confusion_matrix': confusion_matrix(y_true, y_pred)
    }
    
    if y_proba is not None:
        metrics['roc_auc'] = roc_auc_score(y_true, y_proba)
        metrics['brier_score'] = brier_score_loss(y_true, y_proba)
    
    return metrics


def optimize_thresholds(y_true, y_proba, min_prec_rej=0.97, min_prec_val=0.95):
    """Optimise les seuils de décision."""
    best_result = None
    best_automation = 0
    
    for t_low in np.arange(0.1, 0.5, 0.02):
        for t_high in np.arange(0.5, 0.9, 0.02):
            if t_high <= t_low:
                continue
            
            mask_rej = y_proba <= t_low
            mask_val = y_proba >= t_high
            
            n_rej = mask_rej.sum()
            n_val = mask_val.sum()
            n_total = len(y_true)
            
            prec_rej = (y_true[mask_rej] == 0).mean() if n_rej > 0 else 1.0
            prec_val = (y_true[mask_val] == 1).mean() if n_val > 0 else 1.0
            
            automation = (n_rej + n_val) / n_total
            
            if prec_rej >= min_prec_rej and prec_val >= min_prec_val:
                if automation > best_automation:
                    best_automation = automation
                    best_result = {
                        'threshold_low': t_low,
                        'threshold_high': t_high,
                        'precision_rejection': prec_rej,
                        'precision_validation': prec_val,
                        'automation_rate': automation,
                        'n_rejection': n_rej,
                        'n_validation': n_val,
                        'n_audit': n_total - n_rej - n_val
                    }
    
    if best_result is None:
        best_result = {
            'threshold_low': 0.30,
            'threshold_high': 0.70,
            'precision_rejection': 0,
            'precision_validation': 0,
            'automation_rate': 0,
            'n_rejection': 0,
            'n_validation': 0,
            'n_audit': len(y_true)
        }
    
    return best_result


def generate_performance_summary(metrics, thresholds, output_path):
    """Génère le fichier Excel de résumé de performance."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    
    HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
    SUCCESS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    WARNING_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    ERROR_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    BORDER = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Résumé Performance"
    
    # Titre
    ws['A1'] = "RAPPORT DE PERFORMANCE - CLASSIFICATION RÉCLAMATIONS BANCAIRES"
    ws['A1'].font = Font(bold=True, size=16, color="1F4E79")
    ws.merge_cells('A1:F1')
    
    ws['A2'] = f"Généré le: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    ws['A2'].font = Font(italic=True, size=10)
    
    # Section Métriques Classification
    row = 4
    ws.cell(row=row, column=1, value="MÉTRIQUES DE CLASSIFICATION")
    ws.cell(row=row, column=1).font = Font(bold=True, size=12, color="1F4E79")
    
    row += 1
    headers = ["Métrique", "Valeur", "Objectif", "Statut"]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=row, column=col, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal='center')
        cell.border = BORDER
    
    metrics_list = [
        ("Accuracy", metrics['accuracy'], "≥90%", 0.90),
        ("F1-Score Weighted", metrics['f1_weighted'], "≥95%", 0.95),
        ("Précision Rejet (classe 0)", metrics['precision_class_0'], "≥97%", 0.97),
        ("Précision Validation (classe 1)", metrics['precision_class_1'], "≥95%", 0.95),
        ("Recall Rejet", metrics['recall_class_0'], "≥90%", 0.90),
        ("Recall Validation", metrics['recall_class_1'], "≥90%", 0.90),
        ("AUC-ROC", metrics.get('roc_auc', 0), "≥98%", 0.98),
        ("Brier Score (plus bas = mieux)", metrics.get('brier_score', 1), "≤0.10", None),
    ]
    
    for name, value, obj, threshold in metrics_list:
        row += 1
        ws.cell(row=row, column=1, value=name).border = BORDER
        cell_val = ws.cell(row=row, column=2, value=value)
        cell_val.number_format = '0.0000'
        cell_val.border = BORDER
        ws.cell(row=row, column=3, value=obj).border = BORDER
        
        if threshold is not None:
            if value >= threshold:
                status = "✓ OK"
                cell_val.fill = SUCCESS_FILL
            elif value >= threshold - 0.05:
                status = "⚠ Proche"
                cell_val.fill = WARNING_FILL
            else:
                status = "✗ À améliorer"
                cell_val.fill = ERROR_FILL
        else:
            if value <= 0.10:
                status = "✓ OK"
                cell_val.fill = SUCCESS_FILL
            else:
                status = "⚠ À améliorer"
                cell_val.fill = WARNING_FILL
        
        ws.cell(row=row, column=4, value=status).border = BORDER
    
    # Section Business
    row += 3
    ws.cell(row=row, column=1, value="MÉTRIQUES BUSINESS (Seuils Optimisés)")
    ws.cell(row=row, column=1).font = Font(bold=True, size=12, color="1F4E79")
    
    row += 1
    headers = ["Métrique", "Valeur", "Objectif"]
    for col, h in enumerate(headers, 1):
        cell = ws.cell(row=row, column=col, value=h)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = Alignment(horizontal='center')
        cell.border = BORDER
    
    business_metrics = [
        ("Seuil Rejet", thresholds['threshold_low'], "-"),
        ("Seuil Validation", thresholds['threshold_high'], "-"),
        ("Taux Automatisation", thresholds['automation_rate'], "45-55%"),
        ("Précision Rejets Auto", thresholds['precision_rejection'], "≥97%"),
        ("Précision Validations Auto", thresholds['precision_validation'], "≥95%"),
        ("Nombre Rejets Auto", thresholds['n_rejection'], "-"),
        ("Nombre Validations Auto", thresholds['n_validation'], "-"),
        ("Nombre Audits Manuels", thresholds['n_audit'], "-"),
    ]
    
    for name, value, obj in business_metrics:
        row += 1
        ws.cell(row=row, column=1, value=name).border = BORDER
        cell_val = ws.cell(row=row, column=2, value=value)
        if isinstance(value, float) and value <= 1:
            cell_val.number_format = '0.00%' if 'Taux' in name or 'Précision' in name else '0.0000'
        cell_val.border = BORDER
        ws.cell(row=row, column=3, value=obj).border = BORDER
    
    # Matrice de confusion
    row += 3
    ws.cell(row=row, column=1, value="MATRICE DE CONFUSION")
    ws.cell(row=row, column=1).font = Font(bold=True, size=12, color="1F4E79")
    
    cm = metrics['confusion_matrix']
    row += 1
    ws.cell(row=row, column=2, value="Prédit: Non Fondée")
    ws.cell(row=row, column=3, value="Prédit: Fondée")
    
    row += 1
    ws.cell(row=row, column=1, value="Réel: Non Fondée")
    ws.cell(row=row, column=2, value=cm[0, 0])
    ws.cell(row=row, column=3, value=cm[0, 1])
    ws.cell(row=row, column=2).fill = SUCCESS_FILL
    ws.cell(row=row, column=3).fill = ERROR_FILL
    
    row += 1
    ws.cell(row=row, column=1, value="Réel: Fondée")
    ws.cell(row=row, column=2, value=cm[1, 0])
    ws.cell(row=row, column=3, value=cm[1, 1])
    ws.cell(row=row, column=2).fill = WARNING_FILL
    ws.cell(row=row, column=3).fill = SUCCESS_FILL
    
    # Légende
    row += 2
    ws.cell(row=row, column=1, value="Légende:")
    row += 1
    ws.cell(row=row, column=1, value=f"TN (Vrais Négatifs) = {cm[0,0]} : Rejets corrects")
    row += 1
    ws.cell(row=row, column=1, value=f"FP (Faux Positifs) = {cm[0,1]} : Fausses validations → COÛT FINANCIER")
    ws.cell(row=row, column=1).font = Font(color="C00000")
    row += 1
    ws.cell(row=row, column=1, value=f"FN (Faux Négatifs) = {cm[1,0]} : Faux rejets → INSATISFACTION CLIENT")
    ws.cell(row=row, column=1).font = Font(color="FF6600")
    row += 1
    ws.cell(row=row, column=1, value=f"TP (Vrais Positifs) = {cm[1,1]} : Validations correctes")
    
    # Ajuster largeurs
    ws.column_dimensions['A'].width = 40
    ws.column_dimensions['B'].width = 20
    ws.column_dimensions['C'].width = 20
    ws.column_dimensions['D'].width = 15
    
    wb.save(output_path)
    logger.info(f"✓ Résumé de performance sauvegardé: {output_path}")
    return output_path


def generate_performance_by_category(df, y_true, y_pred, y_proba, category_columns, output_path):
    """Génère le rapport de performance par catégorie."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
    
    HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
    SUCCESS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
    WARNING_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    ERROR_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    BORDER = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    
    wb = Workbook()
    ws = wb.active
    ws.title = "Vue d'ensemble"
    
    ws['A1'] = "PERFORMANCE PAR CATÉGORIE"
    ws['A1'].font = Font(bold=True, size=16, color="1F4E79")
    ws['A2'] = f"Généré le: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    
    for cat_col in category_columns:
        if cat_col not in df.columns:
            continue
        
        ws_cat = wb.create_sheet(cat_col[:31])
        
        ws_cat['A1'] = f"PERFORMANCE PAR {cat_col.upper()}"
        ws_cat['A1'].font = Font(bold=True, size=14, color="1F4E79")
        
        results = []
        for group in df[cat_col].unique():
            mask = df[cat_col] == group
            if mask.sum() < 5:
                continue
            
            group_y_true = y_true[mask]
            group_y_pred = y_pred[mask]
            
            row_data = {
                'Catégorie': str(group)[:50],
                'N': int(mask.sum()),
                'Taux Fondées Réel': float(group_y_true.mean()),
                'Accuracy': float(accuracy_score(group_y_true, group_y_pred)),
                'Précision': float(precision_score(group_y_true, group_y_pred, zero_division=0)),
                'Recall': float(recall_score(group_y_true, group_y_pred, zero_division=0)),
                'F1': float(f1_score(group_y_true, group_y_pred, zero_division=0))
            }
            results.append(row_data)
        
        if not results:
            continue
        
        results_df = pd.DataFrame(results).sort_values('F1', ascending=False)
        
        row = 3
        headers = list(results_df.columns)
        for col, header in enumerate(headers, 1):
            cell = ws_cat.cell(row=row, column=col, value=header)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.alignment = Alignment(horizontal='center')
            cell.border = BORDER
        
        for r_idx, (_, data_row) in enumerate(results_df.iterrows(), row + 1):
            for c_idx, (col_name, value) in enumerate(data_row.items(), 1):
                cell = ws_cat.cell(row=r_idx, column=c_idx, value=value)
                cell.border = BORDER
                cell.alignment = Alignment(horizontal='center')
                
                if col_name in ['Taux Fondées Réel', 'Accuracy', 'Précision', 'Recall', 'F1']:
                    cell.number_format = '0.00%'
                    if col_name == 'F1':
                        if value >= 0.95:
                            cell.fill = SUCCESS_FILL
                        elif value >= 0.90:
                            cell.fill = WARNING_FILL
                        else:
                            cell.fill = ERROR_FILL
        
        for col in ['A', 'B', 'C', 'D', 'E', 'F', 'G']:
            ws_cat.column_dimensions[col].width = 18
    
    wb.save(output_path)
    logger.info(f"✓ Performance par catégorie sauvegardée: {output_path}")
    return output_path


def generate_errors_analysis(df, y_true, y_pred, y_proba, output_path):
    """Génère le fichier Excel des faux positifs et faux négatifs."""
    from openpyxl import Workbook
    from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
    
    HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
    HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
    ERROR_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
    WARNING_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
    BORDER = Border(
        left=Side(style='thin'), right=Side(style='thin'),
        top=Side(style='thin'), bottom=Side(style='thin')
    )
    
    df_analysis = df.copy()
    df_analysis['_y_true'] = y_true
    df_analysis['_y_pred'] = y_pred
    if y_proba is not None:
        df_analysis['_probability'] = y_proba
    
    # Faux Positifs: prédit 1 (fondée), réel 0 (non fondée)
    mask_fp = (y_pred == 1) & (y_true == 0)
    df_fp = df_analysis[mask_fp].copy()
    df_fp['Type_Erreur'] = 'Faux Positif (Fausse Validation)'
    
    # Faux Négatifs: prédit 0 (non fondée), réel 1 (fondée)
    mask_fn = (y_pred == 0) & (y_true == 1)
    df_fn = df_analysis[mask_fn].copy()
    df_fn['Type_Erreur'] = 'Faux Négatif (Faux Rejet)'
    
    wb = Workbook()
    
    # Feuille Résumé
    ws_summary = wb.active
    ws_summary.title = "Résumé Erreurs"
    
    ws_summary['A1'] = "ANALYSE DES ERREURS DE PRÉDICTION"
    ws_summary['A1'].font = Font(bold=True, size=16, color="1F4E79")
    ws_summary['A2'] = f"Généré le: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
    
    total_errors = len(df_fp) + len(df_fn)
    
    ws_summary['A4'] = "Type d'Erreur"
    ws_summary['B4'] = "Nombre"
    ws_summary['C4'] = "Pourcentage"
    ws_summary['D4'] = "Impact Business"
    for col in ['A', 'B', 'C', 'D']:
        ws_summary[f'{col}4'].fill = HEADER_FILL
        ws_summary[f'{col}4'].font = HEADER_FONT
        ws_summary[f'{col}4'].border = BORDER
    
    ws_summary['A5'] = "Faux Positifs (Fausses Validations)"
    ws_summary['B5'] = len(df_fp)
    ws_summary['C5'] = len(df_fp) / total_errors if total_errors > 0 else 0
    ws_summary['C5'].number_format = '0.00%'
    ws_summary['D5'] = "⚠️ COÛT FINANCIER"
    ws_summary['A5'].fill = ERROR_FILL
    
    ws_summary['A6'] = "Faux Négatifs (Faux Rejets)"
    ws_summary['B6'] = len(df_fn)
    ws_summary['C6'] = len(df_fn) / total_errors if total_errors > 0 else 0
    ws_summary['C6'].number_format = '0.00%'
    ws_summary['D6'] = "⚠️ INSATISFACTION CLIENT"
    ws_summary['A6'].fill = WARNING_FILL
    
    ws_summary['A7'] = "TOTAL ERREURS"
    ws_summary['B7'] = total_errors
    ws_summary['C7'] = 1.0
    ws_summary['C7'].number_format = '0.00%'
    ws_summary['A7'].font = Font(bold=True)
    
    for row in range(5, 8):
        for col in ['A', 'B', 'C', 'D']:
            ws_summary[f'{col}{row}'].border = BORDER
    
    ws_summary.column_dimensions['A'].width = 40
    ws_summary.column_dimensions['B'].width = 12
    ws_summary.column_dimensions['C'].width = 15
    ws_summary.column_dimensions['D'].width = 25
    
    # Feuille Faux Positifs
    ws_fp = wb.create_sheet("Faux Positifs")
    ws_fp['A1'] = f"FAUX POSITIFS - {len(df_fp)} cas"
    ws_fp['A1'].font = Font(bold=True, size=14, color="C00000")
    ws_fp['A2'] = "Réclamations prédites FONDÉES mais réellement NON FONDÉES"
    ws_fp['A2'].font = Font(italic=True)
    
    if len(df_fp) > 0:
        cols = [c for c in df_fp.columns if not c.startswith('_')]
        cols.extend(['_probability'] if '_probability' in df_fp.columns else [])
        
        row = 4
        for col_idx, col in enumerate(cols, 1):
            cell = ws_fp.cell(row=row, column=col_idx, value=col)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.border = BORDER
        
        for r_idx, (_, data_row) in enumerate(df_fp[cols].head(1000).iterrows(), row + 1):
            for c_idx, value in enumerate(data_row, 1):
                cell = ws_fp.cell(row=r_idx, column=c_idx)
                if pd.isna(value):
                    cell.value = ""
                elif isinstance(value, (np.floating, float)):
                    cell.value = float(value)
                    cell.number_format = '0.0000'
                elif isinstance(value, (np.integer, int)):
                    cell.value = int(value)
                else:
                    cell.value = str(value)[:100]
                cell.border = BORDER
    
    # Feuille Faux Négatifs
    ws_fn = wb.create_sheet("Faux Négatifs")
    ws_fn['A1'] = f"FAUX NÉGATIFS - {len(df_fn)} cas"
    ws_fn['A1'].font = Font(bold=True, size=14, color="FF6600")
    ws_fn['A2'] = "Réclamations prédites NON FONDÉES mais réellement FONDÉES"
    ws_fn['A2'].font = Font(italic=True)
    
    if len(df_fn) > 0:
        cols = [c for c in df_fn.columns if not c.startswith('_')]
        cols.extend(['_probability'] if '_probability' in df_fn.columns else [])
        
        row = 4
        for col_idx, col in enumerate(cols, 1):
            cell = ws_fn.cell(row=row, column=col_idx, value=col)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.border = BORDER
        
        for r_idx, (_, data_row) in enumerate(df_fn[cols].head(1000).iterrows(), row + 1):
            for c_idx, value in enumerate(data_row, 1):
                cell = ws_fn.cell(row=r_idx, column=c_idx)
                if pd.isna(value):
                    cell.value = ""
                elif isinstance(value, (np.floating, float)):
                    cell.value = float(value)
                    cell.number_format = '0.0000'
                elif isinstance(value, (np.integer, int)):
                    cell.value = int(value)
                else:
                    cell.value = str(value)[:100]
                cell.border = BORDER
    
    wb.save(output_path)
    logger.info(f"✓ Analyse des erreurs sauvegardée: {output_path}")
    logger.info(f"  - Faux Positifs: {len(df_fp)}")
    logger.info(f"  - Faux Négatifs: {len(df_fn)}")
    return output_path


def generate_visualizations(metrics, df, y_true, y_pred, y_proba, category_columns, output_dir):
    """Génère les visualisations PNG."""
    import matplotlib.pyplot as plt
    import matplotlib
    matplotlib.use('Agg')
    import seaborn as sns
    from sklearn.metrics import roc_curve, auc, f1_score
    
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    created_files = []
    
    # 1. Matrice de confusion
    fig, ax = plt.subplots(figsize=(8, 6))
    cm = metrics['confusion_matrix']
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
               xticklabels=['Non Fondée', 'Fondée'],
               yticklabels=['Non Fondée', 'Fondée'],
               annot_kws={'size': 14})
    ax.set_xlabel('Prédiction', fontsize=12)
    ax.set_ylabel('Réalité', fontsize=12)
    ax.set_title('Matrice de Confusion', fontsize=14, fontweight='bold')
    path = output_dir / "confusion_matrix.png"
    plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
    created_files.append(str(path))
    plt.close()
    
    # 2. Courbe ROC
    if y_proba is not None:
        fpr, tpr, _ = roc_curve(y_true, y_proba)
        roc_auc = auc(fpr, tpr)
        
        fig, ax = plt.subplots(figsize=(8, 6))
        ax.plot(fpr, tpr, color='#1F4E79', lw=2, label=f'ROC (AUC = {roc_auc:.3f})')
        ax.plot([0, 1], [0, 1], color='gray', lw=1, linestyle='--')
        ax.fill_between(fpr, tpr, alpha=0.3, color='#1F4E79')
        ax.set_xlim([0.0, 1.0])
        ax.set_ylim([0.0, 1.05])
        ax.set_xlabel('Taux Faux Positifs', fontsize=12)
        ax.set_ylabel('Taux Vrais Positifs', fontsize=12)
        ax.set_title('Courbe ROC', fontsize=14, fontweight='bold')
        ax.legend(loc="lower right", fontsize=11)
        ax.grid(True, alpha=0.3)
        path = output_dir / "roc_curve.png"
        plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
        created_files.append(str(path))
        plt.close()
    
    # 3. Distribution des probabilités
    if y_proba is not None:
        fig, ax = plt.subplots(figsize=(10, 6))
        ax.hist(y_proba[y_true == 0], bins=50, alpha=0.6, label='Non Fondées', color='#C00000', edgecolor='white')
        ax.hist(y_proba[y_true == 1], bins=50, alpha=0.6, label='Fondées', color='#00B050', edgecolor='white')
        ax.set_xlabel('Probabilité Prédite', fontsize=12)
        ax.set_ylabel('Fréquence', fontsize=12)
        ax.set_title('Distribution des Probabilités par Classe', fontsize=14, fontweight='bold')
        ax.legend(fontsize=11)
        ax.grid(True, alpha=0.3)
        path = output_dir / "probability_distribution.png"
        plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
        created_files.append(str(path))
        plt.close()
    
    # 4. Performance par catégorie
    for cat_col in category_columns:
        if cat_col not in df.columns:
            continue
        
        cat_performance = []
        for cat in df[cat_col].unique():
            mask = df[cat_col] == cat
            if mask.sum() >= 10:
                f1 = f1_score(y_true[mask], y_pred[mask], zero_division=0)
                cat_performance.append({'category': str(cat)[:30], 'f1': f1, 'count': mask.sum()})
        
        if cat_performance:
            cat_df = pd.DataFrame(cat_performance).sort_values('f1', ascending=True)
            
            fig, ax = plt.subplots(figsize=(12, max(6, len(cat_df) * 0.4)))
            colors = ['#00B050' if x >= 0.95 else '#FFC000' if x >= 0.90 else '#C00000' 
                     for x in cat_df['f1']]
            bars = ax.barh(range(len(cat_df)), cat_df['f1'], color=colors, edgecolor='white')
            ax.set_yticks(range(len(cat_df)))
            ax.set_yticklabels(cat_df['category'], fontsize=10)
            ax.set_xlabel('F1-Score', fontsize=12)
            ax.set_title(f'Performance par {cat_col}', fontsize=14, fontweight='bold')
            ax.axvline(x=0.95, color='#00B050', linestyle='--', linewidth=2, label='Objectif (95%)')
            ax.axvline(x=0.90, color='#FFC000', linestyle='--', linewidth=1, label='Seuil (90%)')
            ax.legend(loc='lower right', fontsize=10)
            ax.set_xlim([0, 1])
            ax.grid(True, alpha=0.3, axis='x')
            
            for i, (_, row) in enumerate(cat_df.iterrows()):
                ax.text(row['f1'] + 0.01, i, f"{row['f1']:.1%}", va='center', fontsize=9)
            
            path = output_dir / f"performance_by_{cat_col.lower().replace(' ', '_')}.png"
            plt.savefig(path, dpi=150, bbox_inches='tight', facecolor='white')
            created_files.append(str(path))
            plt.close()
    
    logger.info(f"✓ {len(created_files)} visualisations créées dans {output_dir}")
    return created_files


def main():
    parser = argparse.ArgumentParser(description='Génère les livrables ML pour la classification des réclamations')
    parser.add_argument('--data', '-d', required=True, help='Chemin vers le fichier de données Excel')
    parser.add_argument('--output', '-o', default='outputs', help='Répertoire de sortie')
    
    args = parser.parse_args()
    
    output_dir = Path(args.output)
    output_dir.mkdir(parents=True, exist_ok=True)
    
    logger.info("=" * 60)
    logger.info("GÉNÉRATION DES LIVRABLES - CLASSIFICATION RÉCLAMATIONS")
    logger.info("=" * 60)
    
    # 1. Charger les données
    logger.info(f"\n📂 Chargement des données: {args.data}")
    df = pd.read_excel(args.data)
    logger.info(f"   {len(df)} lignes, {len(df.columns)} colonnes")
    
    # 2. Détecter les colonnes
    target_col = detect_target_column(df)
    logger.info(f"   Colonne cible détectée: {target_col}")
    
    category_columns = detect_category_columns(df)
    logger.info(f"   Colonnes catégorielles: {category_columns}")
    
    # 3. Préparer les features
    logger.info("\n🔧 Préparation des features...")
    X, y, _ = prepare_features(df, target_col)
    logger.info(f"   {X.shape[1]} features, distribution cible: {y.mean():.1%} fondées")
    
    # 4. Split train/test
    from sklearn.model_selection import train_test_split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, stratify=y, random_state=42
    )
    X_train, X_val, y_train, y_val = train_test_split(
        X_train, y_train, test_size=0.15, stratify=y_train, random_state=42
    )
    logger.info(f"   Train: {len(X_train)}, Val: {len(X_val)}, Test: {len(X_test)}")
    
    # 5. Entraîner le modèle
    logger.info("\n🚀 Entraînement du modèle LightGBM...")
    model = train_model(X_train, y_train, X_val, y_val)
    
    # 6. Prédictions sur test
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]
    
    # 7. Calculer les métriques
    logger.info("\n📊 Calcul des métriques...")
    metrics = calculate_metrics(y_test.values, y_pred, y_proba)
    thresholds = optimize_thresholds(y_test.values, y_proba)
    
    logger.info(f"   F1-Score: {metrics['f1_weighted']:.4f}")
    logger.info(f"   AUC-ROC: {metrics['roc_auc']:.4f}")
    logger.info(f"   Précision Rejet: {metrics['precision_class_0']:.4f}")
    logger.info(f"   Précision Validation: {metrics['precision_class_1']:.4f}")
    
    # 8. Générer les livrables
    logger.info("\n📝 Génération des livrables...")
    
    df_test = df.iloc[X_test.index].reset_index(drop=True)
    y_test_reset = y_test.reset_index(drop=True)
    
    # Livrable 1: Résumé de performance
    generate_performance_summary(
        metrics, thresholds,
        output_dir / "1_performance_summary.xlsx"
    )
    
    # Livrable 2: Performance par catégorie
    generate_performance_by_category(
        df_test, y_test_reset.values, y_pred, y_proba, category_columns,
        output_dir / "2_performance_by_category.xlsx"
    )
    
    # Livrable 3: Analyse des erreurs
    generate_errors_analysis(
        df_test, y_test_reset.values, y_pred, y_proba,
        output_dir / "3_errors_analysis.xlsx"
    )
    
    # Bonus: Visualisations
    viz_dir = output_dir / "visualizations"
    generate_visualizations(
        metrics, df_test, y_test_reset.values, y_pred, y_proba,
        category_columns, viz_dir
    )
    
    logger.info("\n" + "=" * 60)
    logger.info("✅ LIVRABLES GÉNÉRÉS AVEC SUCCÈS")
    logger.info("=" * 60)
    logger.info(f"\n📁 Fichiers créés dans: {output_dir}")
    logger.info("   1. 1_performance_summary.xlsx - Résumé des performances")
    logger.info("   2. 2_performance_by_category.xlsx - Performance par catégorie")
    logger.info("   3. 3_errors_analysis.xlsx - Faux positifs et faux négatifs")
    logger.info("   4. visualizations/ - Graphiques PNG")


if __name__ == "__main__":
    main()
