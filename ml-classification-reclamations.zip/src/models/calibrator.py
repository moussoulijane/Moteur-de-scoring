"""
Module de calibration des probabilités
=======================================
Calibre les probabilités prédites et optimise les seuils de décision.
"""

import pandas as pd
import numpy as np
from sklearn.calibration import CalibratedClassifierCV, calibration_curve
from sklearn.isotonic import IsotonicRegression
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import brier_score_loss
import joblib
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass
import logging
import yaml

logger = logging.getLogger(__name__)


@dataclass
class CalibrationResults:
    """Résultats de la calibration."""
    method: str
    ece_before: float
    ece_after: float
    brier_before: float
    brier_after: float
    calibration_curve_before: Tuple[np.ndarray, np.ndarray]
    calibration_curve_after: Tuple[np.ndarray, np.ndarray]


@dataclass
class ThresholdResults:
    """Résultats de l'optimisation des seuils."""
    rejection_threshold: float
    validation_threshold: float
    precision_rejection: float
    precision_validation: float
    automation_rate: float
    audit_rate: float
    rejection_count: int
    validation_count: int
    audit_count: int


class ProbabilityCalibrator:
    """Classe pour calibrer les probabilités."""
    
    def __init__(self, method: str = 'isotonic'):
        """
        Initialise le calibrateur.
        
        Args:
            method: Méthode de calibration ('isotonic', 'platt', 'beta')
        """
        self.method = method
        self.calibrator = None
        self.is_fitted = False
    
    def fit(self, y_true: np.ndarray, y_proba: np.ndarray):
        """
        Fit le calibrateur sur les données.
        
        Args:
            y_true: Labels vrais
            y_proba: Probabilités prédites
        """
        if self.method == 'isotonic':
            self.calibrator = IsotonicRegression(out_of_bounds='clip')
        elif self.method == 'platt':
            self.calibrator = LogisticRegression()
        else:
            self.calibrator = IsotonicRegression(out_of_bounds='clip')
        
        if self.method == 'platt':
            self.calibrator.fit(y_proba.reshape(-1, 1), y_true)
        else:
            self.calibrator.fit(y_proba, y_true)
        
        self.is_fitted = True
        logger.info(f"Calibrateur {self.method} fitté")
    
    def calibrate(self, y_proba: np.ndarray) -> np.ndarray:
        """
        Calibre les probabilités.
        
        Args:
            y_proba: Probabilités à calibrer
            
        Returns:
            Probabilités calibrées
        """
        if not self.is_fitted:
            raise ValueError("Calibrateur non fitté")
        
        if self.method == 'platt':
            return self.calibrator.predict_proba(y_proba.reshape(-1, 1))[:, 1]
        else:
            return self.calibrator.transform(y_proba)
    
    def fit_calibrate(
        self, 
        y_true: np.ndarray, 
        y_proba: np.ndarray
    ) -> np.ndarray:
        """Fit et calibre en une étape."""
        self.fit(y_true, y_proba)
        return self.calibrate(y_proba)
    
    @staticmethod
    def expected_calibration_error(
        y_true: np.ndarray, 
        y_proba: np.ndarray, 
        n_bins: int = 10
    ) -> float:
        """
        Calcule l'Expected Calibration Error (ECE).
        
        Args:
            y_true: Labels vrais
            y_proba: Probabilités prédites
            n_bins: Nombre de bins
            
        Returns:
            ECE score
        """
        bin_boundaries = np.linspace(0, 1, n_bins + 1)
        ece = 0.0
        
        for i in range(n_bins):
            bin_lower = bin_boundaries[i]
            bin_upper = bin_boundaries[i + 1]
            
            # Indices dans ce bin
            in_bin = (y_proba >= bin_lower) & (y_proba < bin_upper)
            prop_in_bin = in_bin.mean()
            
            if prop_in_bin > 0:
                # Précision moyenne et confiance moyenne dans le bin
                avg_confidence = y_proba[in_bin].mean()
                avg_accuracy = y_true[in_bin].mean()
                
                ece += np.abs(avg_accuracy - avg_confidence) * prop_in_bin
        
        return ece
    
    def evaluate(
        self, 
        y_true: np.ndarray, 
        y_proba_before: np.ndarray,
        y_proba_after: np.ndarray = None
    ) -> CalibrationResults:
        """
        Évalue la qualité de la calibration.
        
        Args:
            y_true: Labels vrais
            y_proba_before: Probabilités avant calibration
            y_proba_after: Probabilités après calibration
            
        Returns:
            CalibrationResults
        """
        if y_proba_after is None:
            y_proba_after = self.calibrate(y_proba_before)
        
        ece_before = self.expected_calibration_error(y_true, y_proba_before)
        ece_after = self.expected_calibration_error(y_true, y_proba_after)
        
        brier_before = brier_score_loss(y_true, y_proba_before)
        brier_after = brier_score_loss(y_true, y_proba_after)
        
        # Courbes de calibration
        prob_true_before, prob_pred_before = calibration_curve(y_true, y_proba_before, n_bins=10)
        prob_true_after, prob_pred_after = calibration_curve(y_true, y_proba_after, n_bins=10)
        
        logger.info(f"ECE: {ece_before:.4f} -> {ece_after:.4f}")
        logger.info(f"Brier: {brier_before:.4f} -> {brier_after:.4f}")
        
        return CalibrationResults(
            method=self.method,
            ece_before=ece_before,
            ece_after=ece_after,
            brier_before=brier_before,
            brier_after=brier_after,
            calibration_curve_before=(prob_true_before, prob_pred_before),
            calibration_curve_after=(prob_true_after, prob_pred_after)
        )
    
    def save(self, path: Union[str, Path]):
        """Sauvegarde le calibrateur."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)
        logger.info(f"Calibrateur sauvegardé: {path}")
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> 'ProbabilityCalibrator':
        """Charge un calibrateur sauvegardé."""
        return joblib.load(path)


class ThresholdOptimizer:
    """Optimise les seuils de décision pour le tunnel tri-classes."""
    
    def __init__(
        self,
        min_precision_rejection: float = 0.97,
        min_precision_validation: float = 0.95,
        target_automation_rate: Tuple[float, float] = (0.45, 0.55)
    ):
        """
        Initialise l'optimiseur de seuils.
        
        Args:
            min_precision_rejection: Précision minimale pour les rejets automatiques
            min_precision_validation: Précision minimale pour les validations automatiques
            target_automation_rate: Plage cible du taux d'automatisation
        """
        self.min_precision_rejection = min_precision_rejection
        self.min_precision_validation = min_precision_validation
        self.target_automation_rate = target_automation_rate
        
        self.optimal_thresholds = None
    
    def _evaluate_thresholds(
        self,
        y_true: np.ndarray,
        y_proba: np.ndarray,
        threshold_low: float,
        threshold_high: float
    ) -> Dict[str, float]:
        """Évalue une paire de seuils."""
        
        # Décisions
        decisions = np.where(
            y_proba <= threshold_low, 'REJET_AUTO',
            np.where(y_proba >= threshold_high, 'VALIDATION_AUTO', 'AUDIT')
        )
        
        # Comptes
        n_total = len(y_true)
        n_rejection = (decisions == 'REJET_AUTO').sum()
        n_validation = (decisions == 'VALIDATION_AUTO').sum()
        n_audit = (decisions == 'AUDIT').sum()
        
        # Précisions
        mask_rejection = decisions == 'REJET_AUTO'
        mask_validation = decisions == 'VALIDATION_AUTO'
        
        if mask_rejection.sum() > 0:
            # Pour les rejets: on veut que les vrais labels soient 0
            precision_rejection = (y_true[mask_rejection] == 0).mean()
        else:
            precision_rejection = 1.0
        
        if mask_validation.sum() > 0:
            # Pour les validations: on veut que les vrais labels soient 1
            precision_validation = (y_true[mask_validation] == 1).mean()
        else:
            precision_validation = 1.0
        
        automation_rate = (n_rejection + n_validation) / n_total
        
        return {
            'threshold_low': threshold_low,
            'threshold_high': threshold_high,
            'precision_rejection': precision_rejection,
            'precision_validation': precision_validation,
            'automation_rate': automation_rate,
            'n_rejection': n_rejection,
            'n_validation': n_validation,
            'n_audit': n_audit
        }
    
    def optimize(
        self,
        y_true: np.ndarray,
        y_proba: np.ndarray,
        n_steps: int = 50
    ) -> ThresholdResults:
        """
        Trouve les seuils optimaux par grid search.
        
        Args:
            y_true: Labels vrais
            y_proba: Probabilités prédites
            n_steps: Nombre de pas pour le grid search
            
        Returns:
            ThresholdResults avec les seuils optimaux
        """
        logger.info("Optimisation des seuils de décision...")
        
        best_result = None
        best_score = -1
        
        # Grid search sur les deux seuils
        threshold_values = np.linspace(0.05, 0.95, n_steps)
        
        for t_low in threshold_values:
            for t_high in threshold_values:
                if t_high <= t_low:
                    continue
                
                result = self._evaluate_thresholds(y_true, y_proba, t_low, t_high)
                
                # Vérifier les contraintes
                if result['precision_rejection'] < self.min_precision_rejection:
                    continue
                if result['precision_validation'] < self.min_precision_validation:
                    continue
                
                # Score: maximiser l'automatisation dans la plage cible
                automation = result['automation_rate']
                
                if self.target_automation_rate[0] <= automation <= self.target_automation_rate[1]:
                    score = automation
                elif automation < self.target_automation_rate[0]:
                    score = automation - (self.target_automation_rate[0] - automation) * 2
                else:
                    score = automation - (automation - self.target_automation_rate[1]) * 2
                
                if score > best_score:
                    best_score = score
                    best_result = result
        
        if best_result is None:
            # Pas de solution satisfaisant les contraintes, relâcher
            logger.warning("Contraintes non satisfaites, recherche relaxée...")
            best_score = -1
            for t_low in threshold_values:
                for t_high in threshold_values:
                    if t_high <= t_low:
                        continue
                    
                    result = self._evaluate_thresholds(y_true, y_proba, t_low, t_high)
                    
                    # Score composite incluant les précisions
                    score = (
                        result['automation_rate'] * 0.5 +
                        result['precision_rejection'] * 0.25 +
                        result['precision_validation'] * 0.25
                    )
                    
                    if score > best_score:
                        best_score = score
                        best_result = result
        
        self.optimal_thresholds = ThresholdResults(
            rejection_threshold=best_result['threshold_low'],
            validation_threshold=best_result['threshold_high'],
            precision_rejection=best_result['precision_rejection'],
            precision_validation=best_result['precision_validation'],
            automation_rate=best_result['automation_rate'],
            audit_rate=1 - best_result['automation_rate'],
            rejection_count=best_result['n_rejection'],
            validation_count=best_result['n_validation'],
            audit_count=best_result['n_audit']
        )
        
        logger.info(f"Seuils optimaux trouvés:")
        logger.info(f"  - Seuil rejet: {self.optimal_thresholds.rejection_threshold:.3f}")
        logger.info(f"  - Seuil validation: {self.optimal_thresholds.validation_threshold:.3f}")
        logger.info(f"  - Précision rejet: {self.optimal_thresholds.precision_rejection:.4f}")
        logger.info(f"  - Précision validation: {self.optimal_thresholds.precision_validation:.4f}")
        logger.info(f"  - Taux automatisation: {self.optimal_thresholds.automation_rate:.2%}")
        
        return self.optimal_thresholds
    
    def apply_thresholds(
        self,
        y_proba: np.ndarray,
        thresholds: ThresholdResults = None
    ) -> Tuple[np.ndarray, np.ndarray]:
        """
        Applique les seuils pour obtenir les décisions.
        
        Args:
            y_proba: Probabilités prédites
            thresholds: Seuils à utiliser (par défaut: optimaux)
            
        Returns:
            Tuple (décisions, confiances)
        """
        if thresholds is None:
            thresholds = self.optimal_thresholds
        
        if thresholds is None:
            raise ValueError("Seuils non définis")
        
        decisions = np.where(
            y_proba <= thresholds.rejection_threshold, 'REJET_AUTO',
            np.where(y_proba >= thresholds.validation_threshold, 'VALIDATION_AUTO', 'AUDIT')
        )
        
        # Confiance: distance au seuil le plus proche
        confidences = np.zeros_like(y_proba)
        
        mask_rejection = decisions == 'REJET_AUTO'
        mask_validation = decisions == 'VALIDATION_AUTO'
        mask_audit = decisions == 'AUDIT'
        
        # Pour les rejets: confiance = distance au seuil de rejet
        confidences[mask_rejection] = (thresholds.rejection_threshold - y_proba[mask_rejection]) / thresholds.rejection_threshold
        
        # Pour les validations: confiance = distance au seuil de validation
        confidences[mask_validation] = (y_proba[mask_validation] - thresholds.validation_threshold) / (1 - thresholds.validation_threshold)
        
        # Pour les audits: confiance faible (proche du milieu = moins confiant)
        mid = (thresholds.rejection_threshold + thresholds.validation_threshold) / 2
        confidences[mask_audit] = np.abs(y_proba[mask_audit] - mid) / (mid - thresholds.rejection_threshold)
        
        # Normaliser entre 0 et 1
        confidences = np.clip(confidences, 0, 1)
        
        return decisions, confidences
    
    def save(self, path: Union[str, Path]):
        """Sauvegarde les seuils optimaux."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self.optimal_thresholds, path)
        logger.info(f"Seuils sauvegardés: {path}")
    
    @classmethod
    def load_thresholds(cls, path: Union[str, Path]) -> ThresholdResults:
        """Charge les seuils sauvegardés."""
        return joblib.load(path)


def calibrate_and_optimize(
    y_true: np.ndarray,
    y_proba: np.ndarray,
    calibration_method: str = 'isotonic',
    config_path: str = "configs/config.yaml"
) -> Tuple[np.ndarray, ThresholdResults, ProbabilityCalibrator]:
    """
    Pipeline complet de calibration et optimisation des seuils.
    
    Args:
        y_true: Labels vrais
        y_proba: Probabilités prédites
        calibration_method: Méthode de calibration
        config_path: Chemin vers la configuration
        
    Returns:
        Tuple (probabilités calibrées, seuils optimaux, calibrateur)
    """
    with open(config_path, 'r') as f:
        config = yaml.safe_load(f)
    
    # Calibration
    calibrator = ProbabilityCalibrator(method=calibration_method)
    y_proba_calibrated = calibrator.fit_calibrate(y_true, y_proba)
    
    # Évaluation de la calibration
    calibration_results = calibrator.evaluate(y_true, y_proba, y_proba_calibrated)
    
    # Optimisation des seuils
    constraints = config['thresholds']['constraints']
    optimizer = ThresholdOptimizer(
        min_precision_rejection=constraints['min_precision_rejection'],
        min_precision_validation=constraints['min_precision_validation'],
        target_automation_rate=tuple(constraints['target_automation_rate'])
    )
    
    threshold_results = optimizer.optimize(y_true, y_proba_calibrated)
    
    return y_proba_calibrated, threshold_results, calibrator


if __name__ == "__main__":
    print("Module de calibration chargé avec succès")
