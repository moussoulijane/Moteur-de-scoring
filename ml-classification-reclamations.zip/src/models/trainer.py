"""
Module d'entraînement des modèles
==================================
Gère l'entraînement, l'optimisation et la comparaison des modèles.
"""

import pandas as pd
import numpy as np
from sklearn.model_selection import StratifiedKFold, cross_val_score, train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, brier_score_loss,
    confusion_matrix, classification_report
)
import lightgbm as lgb
import xgboost as xgb
import optuna
from optuna.samplers import TPESampler
import joblib
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any, Union
from dataclasses import dataclass
import logging
import yaml
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)


@dataclass
class ModelResults:
    """Résultats d'un modèle."""
    model_name: str
    model: Any
    train_metrics: Dict[str, float]
    val_metrics: Dict[str, float]
    test_metrics: Dict[str, float] = None
    cv_scores: Dict[str, List[float]] = None
    best_params: Dict[str, Any] = None
    feature_importance: pd.DataFrame = None
    confusion_matrix: np.ndarray = None


class ModelTrainer:
    """Classe pour entraîner et optimiser les modèles."""
    
    def __init__(self, config_path: str = "configs/config.yaml"):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.models = {}
        self.results = {}
        self.best_model = None
        self.best_model_name = None
    
    def _get_model(self, model_name: str, params: Dict = None) -> Any:
        """Retourne une instance de modèle."""
        
        default_params = self.config['models'].get(model_name, {})
        if params:
            default_params.update(params)
        
        if model_name == 'lightgbm':
            return lgb.LGBMClassifier(**default_params)
        elif model_name == 'xgboost':
            return xgb.XGBClassifier(**default_params, use_label_encoder=False)
        elif model_name == 'random_forest':
            rf_params = {
                'n_estimators': default_params.get('n_estimators', 100),
                'max_depth': default_params.get('max_depth', 10),
                'min_samples_split': default_params.get('min_samples_split', 5),
                'min_samples_leaf': default_params.get('min_samples_leaf', 2),
                'random_state': 42,
                'n_jobs': -1
            }
            return RandomForestClassifier(**rf_params)
        elif model_name == 'logistic_regression':
            return LogisticRegression(max_iter=1000, random_state=42)
        else:
            raise ValueError(f"Modèle non supporté: {model_name}")
    
    def _calculate_metrics(
        self, 
        y_true: np.ndarray, 
        y_pred: np.ndarray, 
        y_proba: np.ndarray = None
    ) -> Dict[str, float]:
        """Calcule les métriques de performance."""
        
        metrics = {
            'accuracy': accuracy_score(y_true, y_pred),
            'precision_0': precision_score(y_true, y_pred, pos_label=0, zero_division=0),
            'precision_1': precision_score(y_true, y_pred, pos_label=1, zero_division=0),
            'recall_0': recall_score(y_true, y_pred, pos_label=0, zero_division=0),
            'recall_1': recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            'f1_0': f1_score(y_true, y_pred, pos_label=0, zero_division=0),
            'f1_1': f1_score(y_true, y_pred, pos_label=1, zero_division=0),
            'f1_weighted': f1_score(y_true, y_pred, average='weighted', zero_division=0),
            'f1_macro': f1_score(y_true, y_pred, average='macro', zero_division=0)
        }
        
        if y_proba is not None:
            metrics['roc_auc'] = roc_auc_score(y_true, y_proba)
            metrics['average_precision'] = average_precision_score(y_true, y_proba)
            metrics['brier_score'] = brier_score_loss(y_true, y_proba)
        
        return metrics
    
    def _get_feature_importance(
        self, 
        model: Any, 
        feature_names: List[str]
    ) -> pd.DataFrame:
        """Extrait l'importance des features."""
        
        if hasattr(model, 'feature_importances_'):
            importance = model.feature_importances_
        elif hasattr(model, 'coef_'):
            importance = np.abs(model.coef_[0])
        else:
            return None
        
        df = pd.DataFrame({
            'feature': feature_names,
            'importance': importance
        }).sort_values('importance', ascending=False)
        
        return df
    
    def train_model(
        self,
        model_name: str,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        params: Dict = None,
        early_stopping: bool = True
    ) -> ModelResults:
        """
        Entraîne un modèle unique.
        
        Args:
            model_name: Nom du modèle
            X_train, y_train: Données d'entraînement
            X_val, y_val: Données de validation
            params: Paramètres optionnels
            early_stopping: Utiliser early stopping
            
        Returns:
            ModelResults avec métriques et modèle
        """
        logger.info(f"Entraînement du modèle: {model_name}")
        
        model = self._get_model(model_name, params)
        feature_names = X_train.columns.tolist()
        
        # Entraînement avec early stopping pour les modèles boosting
        if model_name in ['lightgbm', 'xgboost'] and early_stopping:
            if model_name == 'lightgbm':
                model.fit(
                    X_train, y_train,
                    eval_set=[(X_val, y_val)],
                    callbacks=[lgb.early_stopping(50, verbose=False)]
                )
            else:  # xgboost
                model.fit(
                    X_train, y_train,
                    eval_set=[(X_val, y_val)],
                    verbose=False
                )
        else:
            model.fit(X_train, y_train)
        
        # Prédictions
        y_train_pred = model.predict(X_train)
        y_val_pred = model.predict(X_val)
        
        y_train_proba = model.predict_proba(X_train)[:, 1] if hasattr(model, 'predict_proba') else None
        y_val_proba = model.predict_proba(X_val)[:, 1] if hasattr(model, 'predict_proba') else None
        
        # Métriques
        train_metrics = self._calculate_metrics(y_train, y_train_pred, y_train_proba)
        val_metrics = self._calculate_metrics(y_val, y_val_pred, y_val_proba)
        
        # Feature importance
        feature_importance = self._get_feature_importance(model, feature_names)
        
        # Matrice de confusion
        cm = confusion_matrix(y_val, y_val_pred)
        
        results = ModelResults(
            model_name=model_name,
            model=model,
            train_metrics=train_metrics,
            val_metrics=val_metrics,
            feature_importance=feature_importance,
            confusion_matrix=cm,
            best_params=params
        )
        
        self.models[model_name] = model
        self.results[model_name] = results
        
        logger.info(f"{model_name} - Val F1: {val_metrics['f1_weighted']:.4f}, AUC: {val_metrics.get('roc_auc', 0):.4f}")
        
        return results
    
    def cross_validate(
        self,
        model_name: str,
        X: pd.DataFrame,
        y: pd.Series,
        n_folds: int = 5,
        params: Dict = None
    ) -> Dict[str, List[float]]:
        """
        Effectue une validation croisée stratifiée.
        
        Args:
            model_name: Nom du modèle
            X, y: Données complètes
            n_folds: Nombre de folds
            params: Paramètres optionnels
            
        Returns:
            Dictionnaire avec scores par fold
        """
        logger.info(f"Cross-validation {n_folds}-fold pour {model_name}")
        
        cv = StratifiedKFold(n_splits=n_folds, shuffle=True, random_state=42)
        
        cv_results = {
            'f1_weighted': [],
            'roc_auc': [],
            'precision_0': [],
            'precision_1': [],
            'recall_0': [],
            'recall_1': []
        }
        
        for fold, (train_idx, val_idx) in enumerate(cv.split(X, y)):
            X_train, X_val = X.iloc[train_idx], X.iloc[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
            
            model = self._get_model(model_name, params)
            
            if model_name in ['lightgbm', 'xgboost']:
                if model_name == 'lightgbm':
                    model.fit(
                        X_train, y_train,
                        eval_set=[(X_val, y_val)],
                        callbacks=[lgb.early_stopping(50, verbose=False)]
                    )
                else:
                    model.fit(
                        X_train, y_train,
                        eval_set=[(X_val, y_val)],
                        verbose=False
                    )
            else:
                model.fit(X_train, y_train)
            
            y_pred = model.predict(X_val)
            y_proba = model.predict_proba(X_val)[:, 1] if hasattr(model, 'predict_proba') else None
            
            metrics = self._calculate_metrics(y_val, y_pred, y_proba)
            
            for metric_name in cv_results.keys():
                cv_results[metric_name].append(metrics.get(metric_name, 0))
        
        # Log les résultats moyens
        for metric_name, scores in cv_results.items():
            mean_score = np.mean(scores)
            std_score = np.std(scores)
            logger.info(f"  {metric_name}: {mean_score:.4f} (+/- {std_score:.4f})")
        
        return cv_results
    
    def optimize_hyperparameters(
        self,
        model_name: str,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        n_trials: int = 100,
        timeout: int = 3600
    ) -> Dict[str, Any]:
        """
        Optimise les hyperparamètres avec Optuna.
        
        Args:
            model_name: Nom du modèle
            X_train, y_train: Données d'entraînement
            X_val, y_val: Données de validation
            n_trials: Nombre d'essais
            timeout: Timeout en secondes
            
        Returns:
            Meilleurs hyperparamètres
        """
        logger.info(f"Optimisation des hyperparamètres pour {model_name}")
        
        def objective(trial):
            if model_name == 'lightgbm':
                params = {
                    'num_leaves': trial.suggest_int('num_leaves', 15, 127),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.1, log=True),
                    'max_depth': trial.suggest_int('max_depth', 5, 15),
                    'min_child_samples': trial.suggest_int('min_child_samples', 10, 100),
                    'subsample': trial.suggest_float('subsample', 0.7, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.7, 1.0),
                    'reg_alpha': trial.suggest_float('reg_alpha', 0, 1),
                    'reg_lambda': trial.suggest_float('reg_lambda', 0, 10),
                    'n_estimators': 500,
                    'objective': 'binary',
                    'metric': 'auc',
                    'verbose': -1
                }
                
                model = lgb.LGBMClassifier(**params)
                model.fit(
                    X_train, y_train,
                    eval_set=[(X_val, y_val)],
                    callbacks=[lgb.early_stopping(50, verbose=False)]
                )
            
            elif model_name == 'xgboost':
                params = {
                    'max_depth': trial.suggest_int('max_depth', 3, 10),
                    'learning_rate': trial.suggest_float('learning_rate', 0.01, 0.1, log=True),
                    'n_estimators': 500,
                    'subsample': trial.suggest_float('subsample', 0.7, 1.0),
                    'colsample_bytree': trial.suggest_float('colsample_bytree', 0.7, 1.0),
                    'min_child_weight': trial.suggest_int('min_child_weight', 1, 10),
                    'reg_alpha': trial.suggest_float('reg_alpha', 0, 1),
                    'reg_lambda': trial.suggest_float('reg_lambda', 1, 10),
                    'objective': 'binary:logistic',
                    'eval_metric': 'auc',
                    'use_label_encoder': False
                }
                
                model = xgb.XGBClassifier(**params)
                model.fit(
                    X_train, y_train,
                    eval_set=[(X_val, y_val)],
                    verbose=False
                )
            
            else:
                raise ValueError(f"Optimisation non supportée pour {model_name}")
            
            y_proba = model.predict_proba(X_val)[:, 1]
            y_pred = model.predict(X_val)
            
            # Score composite: priorité F1, puis AUC
            f1 = f1_score(y_val, y_pred, average='weighted')
            auc = roc_auc_score(y_val, y_proba)
            
            return f1 * 0.7 + auc * 0.3
        
        # Optimisation
        study = optuna.create_study(
            direction='maximize',
            sampler=TPESampler(seed=42)
        )
        
        study.optimize(
            objective,
            n_trials=n_trials,
            timeout=timeout,
            show_progress_bar=True
        )
        
        best_params = study.best_params
        best_score = study.best_value
        
        logger.info(f"Meilleur score: {best_score:.4f}")
        logger.info(f"Meilleurs paramètres: {best_params}")
        
        return best_params
    
    def train_all_models(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_val: pd.DataFrame,
        y_val: pd.Series,
        models: List[str] = None,
        optimize: bool = False
    ) -> Dict[str, ModelResults]:
        """
        Entraîne plusieurs modèles et les compare.
        
        Args:
            X_train, y_train: Données d'entraînement
            X_val, y_val: Données de validation
            models: Liste des modèles à entraîner
            optimize: Optimiser les hyperparamètres
            
        Returns:
            Dictionnaire des résultats par modèle
        """
        if models is None:
            models = ['logistic_regression', 'random_forest', 'lightgbm', 'xgboost']
        
        results = {}
        
        for model_name in models:
            try:
                params = None
                
                if optimize and model_name in ['lightgbm', 'xgboost']:
                    params = self.optimize_hyperparameters(
                        model_name, X_train, y_train, X_val, y_val,
                        n_trials=self.config['optimization']['n_trials'],
                        timeout=self.config['optimization']['timeout']
                    )
                
                result = self.train_model(
                    model_name, X_train, y_train, X_val, y_val, params
                )
                results[model_name] = result
                
            except Exception as e:
                logger.error(f"Erreur lors de l'entraînement de {model_name}: {e}")
                continue
        
        # Sélectionner le meilleur modèle
        best_score = 0
        for name, result in results.items():
            score = result.val_metrics['f1_weighted']
            if score > best_score:
                best_score = score
                self.best_model = result.model
                self.best_model_name = name
        
        logger.info(f"Meilleur modèle: {self.best_model_name} (F1: {best_score:.4f})")
        
        return results
    
    def evaluate_on_test(
        self,
        model_name: str,
        X_test: pd.DataFrame,
        y_test: pd.Series
    ) -> Dict[str, float]:
        """
        Évalue un modèle sur le test set.
        
        Args:
            model_name: Nom du modèle
            X_test, y_test: Données de test
            
        Returns:
            Dictionnaire des métriques de test
        """
        if model_name not in self.models:
            raise ValueError(f"Modèle {model_name} non trouvé")
        
        model = self.models[model_name]
        
        y_pred = model.predict(X_test)
        y_proba = model.predict_proba(X_test)[:, 1] if hasattr(model, 'predict_proba') else None
        
        metrics = self._calculate_metrics(y_test, y_pred, y_proba)
        
        # Mettre à jour les résultats
        self.results[model_name].test_metrics = metrics
        self.results[model_name].confusion_matrix = confusion_matrix(y_test, y_pred)
        
        logger.info(f"Test {model_name} - F1: {metrics['f1_weighted']:.4f}, AUC: {metrics.get('roc_auc', 0):.4f}")
        
        return metrics
    
    def save_model(
        self,
        model_name: str,
        path: Union[str, Path],
        include_results: bool = True
    ):
        """Sauvegarde un modèle et ses résultats."""
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        
        # Sauvegarder le modèle
        model_path = path / f"{model_name}_model.pkl"
        joblib.dump(self.models[model_name], model_path)
        
        # Sauvegarder les résultats si demandé
        if include_results:
            results_path = path / f"{model_name}_results.pkl"
            joblib.dump(self.results[model_name], results_path)
        
        logger.info(f"Modèle sauvegardé: {model_path}")
    
    def load_model(self, path: Union[str, Path], model_name: str):
        """Charge un modèle sauvegardé."""
        path = Path(path)
        model_path = path / f"{model_name}_model.pkl"
        self.models[model_name] = joblib.load(model_path)
        
        results_path = path / f"{model_name}_results.pkl"
        if results_path.exists():
            self.results[model_name] = joblib.load(results_path)
        
        logger.info(f"Modèle chargé: {model_path}")


def compare_models(results: Dict[str, ModelResults]) -> pd.DataFrame:
    """
    Compare les performances de plusieurs modèles.
    
    Args:
        results: Dictionnaire des résultats par modèle
        
    Returns:
        DataFrame de comparaison
    """
    comparison = []
    
    for name, result in results.items():
        row = {
            'model': name,
            'train_f1': result.train_metrics['f1_weighted'],
            'val_f1': result.val_metrics['f1_weighted'],
            'val_precision_0': result.val_metrics['precision_0'],
            'val_precision_1': result.val_metrics['precision_1'],
            'val_recall_0': result.val_metrics['recall_0'],
            'val_recall_1': result.val_metrics['recall_1'],
            'val_auc': result.val_metrics.get('roc_auc', 0),
            'overfit_gap': result.train_metrics['f1_weighted'] - result.val_metrics['f1_weighted']
        }
        
        if result.test_metrics:
            row['test_f1'] = result.test_metrics['f1_weighted']
            row['test_auc'] = result.test_metrics.get('roc_auc', 0)
        
        comparison.append(row)
    
    return pd.DataFrame(comparison).sort_values('val_f1', ascending=False)


if __name__ == "__main__":
    print("Module d'entraînement chargé avec succès")
