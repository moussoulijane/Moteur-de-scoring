"""
Générateur de Rapports Excel et Visualisations
================================================
Crée les livrables: résumé performance, visualisations, analyse erreurs.
"""

import pandas as pd
import numpy as np
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows
from openpyxl.chart import BarChart, PieChart, LineChart, Reference
from openpyxl.chart.label import DataLabelList
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use('Agg')
import seaborn as sns
from pathlib import Path
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

# Styles Excel
HEADER_FILL = PatternFill(start_color="1F4E79", end_color="1F4E79", fill_type="solid")
HEADER_FONT = Font(color="FFFFFF", bold=True, size=11)
SUCCESS_FILL = PatternFill(start_color="C6EFCE", end_color="C6EFCE", fill_type="solid")
WARNING_FILL = PatternFill(start_color="FFEB9C", end_color="FFEB9C", fill_type="solid")
ERROR_FILL = PatternFill(start_color="FFC7CE", end_color="FFC7CE", fill_type="solid")
BORDER = Border(
    left=Side(style='thin'),
    right=Side(style='thin'),
    top=Side(style='thin'),
    bottom=Side(style='thin')
)


class ReportGenerator:
    """Génère les rapports Excel et visualisations."""
    
    def __init__(self, output_dir: str = "outputs"):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
    
    def _apply_header_style(self, ws, row: int, cols: int):
        """Applique le style header aux cellules."""
        for col in range(1, cols + 1):
            cell = ws.cell(row=row, column=col)
            cell.fill = HEADER_FILL
            cell.font = HEADER_FONT
            cell.alignment = Alignment(horizontal='center', vertical='center')
            cell.border = BORDER
    
    def _apply_data_style(self, ws, start_row: int, end_row: int, cols: int):
        """Applique le style données aux cellules."""
        for row in range(start_row, end_row + 1):
            for col in range(1, cols + 1):
                cell = ws.cell(row=row, column=col)
                cell.border = BORDER
                cell.alignment = Alignment(horizontal='center', vertical='center')
    
    def _format_percentage(self, ws, col: int, start_row: int, end_row: int):
        """Formate une colonne en pourcentage."""
        for row in range(start_row, end_row + 1):
            cell = ws.cell(row=row, column=col)
            if isinstance(cell.value, (int, float)):
                cell.number_format = '0.00%'
    
    def _add_conditional_fill(self, ws, row: int, col: int, value: float, 
                              good_threshold: float = 0.95, bad_threshold: float = 0.90):
        """Ajoute une mise en forme conditionnelle."""
        cell = ws.cell(row=row, column=col)
        if value >= good_threshold:
            cell.fill = SUCCESS_FILL
        elif value >= bad_threshold:
            cell.fill = WARNING_FILL
        else:
            cell.fill = ERROR_FILL
    
    def generate_performance_summary(
        self,
        metrics: Dict[str, Any],
        model_comparison: pd.DataFrame,
        thresholds: Any,
        output_path: str = None
    ) -> str:
        """
        Génère le résumé de performance Excel.
        
        Args:
            metrics: Dictionnaire des métriques
            model_comparison: DataFrame de comparaison des modèles
            thresholds: Résultats des seuils optimaux
            output_path: Chemin de sortie (optionnel)
            
        Returns:
            Chemin du fichier créé
        """
        if output_path is None:
            output_path = self.output_dir / "performance_summary.xlsx"
        
        wb = Workbook()
        
        # ========== FEUILLE 1: RÉSUMÉ GLOBAL ==========
        ws = wb.active
        ws.title = "Résumé Global"
        
        # Titre
        ws['A1'] = "RAPPORT DE PERFORMANCE - CLASSIFICATION RÉCLAMATIONS"
        ws['A1'].font = Font(bold=True, size=16, color="1F4E79")
        ws.merge_cells('A1:F1')
        
        ws['A2'] = f"Généré le: {datetime.now().strftime('%Y-%m-%d %H:%M')}"
        ws['A2'].font = Font(italic=True, size=10)
        
        # Métriques principales
        row = 4
        ws.cell(row=row, column=1, value="MÉTRIQUES PRINCIPALES")
        ws.cell(row=row, column=1).font = Font(bold=True, size=12)
        ws.merge_cells(f'A{row}:B{row}')
        
        row += 1
        headers = ["Métrique", "Valeur", "Objectif", "Statut"]
        for col, header in enumerate(headers, 1):
            ws.cell(row=row, column=col, value=header)
        self._apply_header_style(ws, row, len(headers))
        
        # Données métriques
        metrics_data = [
            ("Accuracy", metrics.get('accuracy', 0), 0.90, "≥90%"),
            ("F1-Score Weighted", metrics.get('f1_weighted', 0), 0.95, "≥95%"),
            ("Précision Rejet (classe 0)", metrics.get('precision_class_0', 0), 0.97, "≥97%"),
            ("Précision Validation (classe 1)", metrics.get('precision_class_1', 0), 0.95, "≥95%"),
            ("Recall Rejet", metrics.get('recall_class_0', 0), 0.90, "≥90%"),
            ("Recall Validation", metrics.get('recall_class_1', 0), 0.90, "≥90%"),
            ("AUC-ROC", metrics.get('roc_auc', 0), 0.98, "≥98%"),
            ("Brier Score", metrics.get('brier_score', 1), 0.10, "≤10%"),
        ]
        
        for i, (name, value, threshold, obj) in enumerate(metrics_data):
            row += 1
            ws.cell(row=row, column=1, value=name)
            ws.cell(row=row, column=2, value=value)
            ws.cell(row=row, column=2).number_format = '0.0000'
            ws.cell(row=row, column=3, value=obj)
            
            if name == "Brier Score":
                status = "✓ OK" if value <= threshold else "✗ À améliorer"
                self._add_conditional_fill(ws, row, 2, 1 - value)
            else:
                status = "✓ OK" if value >= threshold else "✗ À améliorer"
                self._add_conditional_fill(ws, row, 2, value, threshold, threshold - 0.05)
            
            ws.cell(row=row, column=4, value=status)
        
        self._apply_data_style(ws, row - len(metrics_data) + 1, row, 4)
        
        # Métriques Business
        row += 3
        ws.cell(row=row, column=1, value="MÉTRIQUES BUSINESS")
        ws.cell(row=row, column=1).font = Font(bold=True, size=12)
        
        row += 1
        headers = ["Métrique", "Valeur", "Objectif"]
        for col, header in enumerate(headers, 1):
            ws.cell(row=row, column=col, value=header)
        self._apply_header_style(ws, row, len(headers))
        
        if thresholds:
            business_data = [
                ("Seuil Rejet", thresholds.rejection_threshold, "-"),
                ("Seuil Validation", thresholds.validation_threshold, "-"),
                ("Taux Automatisation", thresholds.automation_rate, "45-55%"),
                ("Précision Rejets Auto", thresholds.precision_rejection, "≥97%"),
                ("Précision Validations Auto", thresholds.precision_validation, "≥95%"),
                ("Nombre Rejets Auto", thresholds.rejection_count, "-"),
                ("Nombre Validations Auto", thresholds.validation_count, "-"),
                ("Nombre Audits", thresholds.audit_count, "-"),
            ]
            
            for name, value, obj in business_data:
                row += 1
                ws.cell(row=row, column=1, value=name)
                ws.cell(row=row, column=2, value=value)
                if isinstance(value, float) and value <= 1:
                    ws.cell(row=row, column=2).number_format = '0.00%' if 'Taux' in name else '0.0000'
                ws.cell(row=row, column=3, value=obj)
        
        # Ajuster largeurs de colonnes
        ws.column_dimensions['A'].width = 30
        ws.column_dimensions['B'].width = 15
        ws.column_dimensions['C'].width = 15
        ws.column_dimensions['D'].width = 15
        
        # ========== FEUILLE 2: COMPARAISON MODÈLES ==========
        ws2 = wb.create_sheet("Comparaison Modèles")
        
        ws2['A1'] = "COMPARAISON DES MODÈLES"
        ws2['A1'].font = Font(bold=True, size=14)
        
        if model_comparison is not None and len(model_comparison) > 0:
            row = 3
            for col, header in enumerate(model_comparison.columns, 1):
                ws2.cell(row=row, column=col, value=header)
            self._apply_header_style(ws2, row, len(model_comparison.columns))
            
            for r_idx, (_, data_row) in enumerate(model_comparison.iterrows(), row + 1):
                for c_idx, value in enumerate(data_row, 1):
                    cell = ws2.cell(row=r_idx, column=c_idx, value=value)
                    if isinstance(value, float):
                        cell.number_format = '0.0000'
                    cell.border = BORDER
        
        # ========== FEUILLE 3: MATRICE DE CONFUSION ==========
        ws3 = wb.create_sheet("Matrice Confusion")
        
        ws3['A1'] = "MATRICE DE CONFUSION"
        ws3['A1'].font = Font(bold=True, size=14)
        
        cm = metrics.get('confusion_matrix')
        if cm is not None:
            ws3['A3'] = "Prédiction →"
            ws3['B3'] = "Non Fondée (0)"
            ws3['C3'] = "Fondée (1)"
            
            ws3['A4'] = "Réel: Non Fondée (0)"
            ws3['B4'] = cm[0, 0]  # TN
            ws3['C4'] = cm[0, 1]  # FP
            
            ws3['A5'] = "Réel: Fondée (1)"
            ws3['B5'] = cm[1, 0]  # FN
            ws3['C5'] = cm[1, 1]  # TP
            
            # Interprétation
            ws3['A7'] = "Interprétation:"
            ws3['A8'] = f"Vrais Négatifs (TN): {cm[0, 0]} - Rejets corrects"
            ws3['A9'] = f"Faux Positifs (FP): {cm[0, 1]} - Fausses validations (COÛT)"
            ws3['A10'] = f"Faux Négatifs (FN): {cm[1, 0]} - Faux rejets (INSATISFACTION)"
            ws3['A11'] = f"Vrais Positifs (TP): {cm[1, 1]} - Validations correctes"
        
        # Sauvegarder
        wb.save(output_path)
        logger.info(f"Rapport de performance sauvegardé: {output_path}")
        
        return str(output_path)
    
    def generate_performance_by_category(
        self,
        df: pd.DataFrame,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: np.ndarray,
        category_columns: List[str],
        output_path: str = None
    ) -> str:
        """
        Génère les visualisations de performance par catégorie.
        
        Args:
            df: DataFrame avec les données
            y_true: Labels vrais
            y_pred: Prédictions
            y_proba: Probabilités
            category_columns: Colonnes de catégorie
            output_path: Chemin de sortie
            
        Returns:
            Chemin du fichier créé
        """
        if output_path is None:
            output_path = self.output_dir / "performance_by_category.xlsx"
        
        wb = Workbook()
        ws = wb.active
        ws.title = "Vue d'ensemble"
        
        ws['A1'] = "PERFORMANCE PAR CATÉGORIE"
        ws['A1'].font = Font(bold=True, size=16)
        
        from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score
        
        for cat_col in category_columns:
            if cat_col not in df.columns:
                continue
            
            # Créer une feuille par catégorie
            ws_cat = wb.create_sheet(cat_col[:31])  # Limiter à 31 caractères
            
            ws_cat['A1'] = f"PERFORMANCE PAR {cat_col.upper()}"
            ws_cat['A1'].font = Font(bold=True, size=14)
            
            # Calculer les métriques par groupe
            results = []
            for group in df[cat_col].unique():
                mask = df[cat_col] == group
                if mask.sum() < 10:
                    continue
                
                group_y_true = y_true[mask]
                group_y_pred = y_pred[mask]
                group_y_proba = y_proba[mask] if y_proba is not None else None
                
                row_data = {
                    'Catégorie': group,
                    'N': mask.sum(),
                    'Taux Fondées Réel': group_y_true.mean(),
                    'Accuracy': accuracy_score(group_y_true, group_y_pred),
                    'Précision': precision_score(group_y_true, group_y_pred, zero_division=0),
                    'Recall': recall_score(group_y_true, group_y_pred, zero_division=0),
                    'F1': f1_score(group_y_true, group_y_pred, zero_division=0)
                }
                results.append(row_data)
            
            if not results:
                continue
            
            results_df = pd.DataFrame(results).sort_values('F1', ascending=False)
            
            # Écrire les données
            row = 3
            headers = list(results_df.columns)
            for col, header in enumerate(headers, 1):
                ws_cat.cell(row=row, column=col, value=header)
            self._apply_header_style(ws_cat, row, len(headers))
            
            for r_idx, (_, data_row) in enumerate(results_df.iterrows(), row + 1):
                for c_idx, value in enumerate(data_row, 1):
                    cell = ws_cat.cell(row=r_idx, column=c_idx, value=value)
                    if isinstance(value, float):
                        cell.number_format = '0.00%' if c_idx > 2 else '0'
                    cell.border = BORDER
            
            # Ajuster colonnes
            for col in range(1, len(headers) + 1):
                ws_cat.column_dimensions[chr(64 + col)].width = 18
        
        wb.save(output_path)
        logger.info(f"Rapport par catégorie sauvegardé: {output_path}")
        
        return str(output_path)
    
    def generate_error_analysis(
        self,
        df_fp: pd.DataFrame,
        df_fn: pd.DataFrame,
        output_path: str = None
    ) -> str:
        """
        Génère le fichier d'analyse des erreurs (FP et FN).
        
        Args:
            df_fp: DataFrame des faux positifs
            df_fn: DataFrame des faux négatifs
            output_path: Chemin de sortie
            
        Returns:
            Chemin du fichier créé
        """
        if output_path is None:
            output_path = self.output_dir / "errors_analysis.xlsx"
        
        wb = Workbook()
        
        # ========== FEUILLE RÉSUMÉ ==========
        ws_summary = wb.active
        ws_summary.title = "Résumé"
        
        ws_summary['A1'] = "ANALYSE DES ERREURS DE PRÉDICTION"
        ws_summary['A1'].font = Font(bold=True, size=16)
        
        ws_summary['A3'] = "Type d'Erreur"
        ws_summary['B3'] = "Nombre"
        ws_summary['C3'] = "Pourcentage"
        ws_summary['D3'] = "Impact"
        self._apply_header_style(ws_summary, 3, 4)
        
        total_errors = len(df_fp) + len(df_fn)
        
        ws_summary['A4'] = "Faux Positifs (Fausses Validations)"
        ws_summary['B4'] = len(df_fp)
        ws_summary['C4'] = len(df_fp) / total_errors if total_errors > 0 else 0
        ws_summary['C4'].number_format = '0.00%'
        ws_summary['D4'] = "Coût Financier"
        ws_summary['A4'].fill = ERROR_FILL
        
        ws_summary['A5'] = "Faux Négatifs (Faux Rejets)"
        ws_summary['B5'] = len(df_fn)
        ws_summary['C5'] = len(df_fn) / total_errors if total_errors > 0 else 0
        ws_summary['C5'].number_format = '0.00%'
        ws_summary['D5'] = "Insatisfaction Client"
        ws_summary['A5'].fill = WARNING_FILL
        
        ws_summary['A6'] = "TOTAL"
        ws_summary['B6'] = total_errors
        ws_summary['C6'] = 1.0
        ws_summary['C6'].number_format = '0.00%'
        ws_summary['A6'].font = Font(bold=True)
        
        self._apply_data_style(ws_summary, 4, 6, 4)
        
        for col in ['A', 'B', 'C', 'D']:
            ws_summary.column_dimensions[col].width = 35
        
        # ========== FEUILLE FAUX POSITIFS ==========
        ws_fp = wb.create_sheet("Faux Positifs")
        
        ws_fp['A1'] = f"FAUX POSITIFS - {len(df_fp)} cas"
        ws_fp['A1'].font = Font(bold=True, size=14, color="C00000")
        ws_fp['A2'] = "Réclamations prédites FONDÉES mais réellement NON FONDÉES"
        ws_fp['A2'].font = Font(italic=True)
        
        if len(df_fp) > 0:
            row = 4
            cols = list(df_fp.columns)
            for col, header in enumerate(cols, 1):
                ws_fp.cell(row=row, column=col, value=header)
            self._apply_header_style(ws_fp, row, len(cols))
            
            for r_idx, (_, data_row) in enumerate(df_fp.head(1000).iterrows(), row + 1):
                for c_idx, value in enumerate(data_row, 1):
                    cell = ws_fp.cell(row=r_idx, column=c_idx)
                    if isinstance(value, (np.floating, float)):
                        cell.value = float(value)
                        cell.number_format = '0.0000'
                    elif isinstance(value, (np.integer, int)):
                        cell.value = int(value)
                    else:
                        cell.value = str(value) if pd.notna(value) else ""
                    cell.border = BORDER
        
        # ========== FEUILLE FAUX NÉGATIFS ==========
        ws_fn = wb.create_sheet("Faux Négatifs")
        
        ws_fn['A1'] = f"FAUX NÉGATIFS - {len(df_fn)} cas"
        ws_fn['A1'].font = Font(bold=True, size=14, color="FF6600")
        ws_fn['A2'] = "Réclamations prédites NON FONDÉES mais réellement FONDÉES"
        ws_fn['A2'].font = Font(italic=True)
        
        if len(df_fn) > 0:
            row = 4
            cols = list(df_fn.columns)
            for col, header in enumerate(cols, 1):
                ws_fn.cell(row=row, column=col, value=header)
            self._apply_header_style(ws_fn, row, len(cols))
            
            for r_idx, (_, data_row) in enumerate(df_fn.head(1000).iterrows(), row + 1):
                for c_idx, value in enumerate(data_row, 1):
                    cell = ws_fn.cell(row=r_idx, column=c_idx)
                    if isinstance(value, (np.floating, float)):
                        cell.value = float(value)
                        cell.number_format = '0.0000'
                    elif isinstance(value, (np.integer, int)):
                        cell.value = int(value)
                    else:
                        cell.value = str(value) if pd.notna(value) else ""
                    cell.border = BORDER
        
        wb.save(output_path)
        logger.info(f"Analyse des erreurs sauvegardée: {output_path}")
        
        return str(output_path)
    
    def generate_visualizations(
        self,
        metrics: Dict[str, Any],
        df: pd.DataFrame,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: np.ndarray,
        category_columns: List[str],
        output_dir: str = None
    ) -> List[str]:
        """
        Génère les visualisations matplotlib.
        
        Args:
            metrics: Métriques
            df: DataFrame
            y_true: Labels vrais
            y_pred: Prédictions
            y_proba: Probabilités
            category_columns: Colonnes catégorielles
            output_dir: Répertoire de sortie
            
        Returns:
            Liste des chemins des fichiers créés
        """
        if output_dir is None:
            output_dir = self.output_dir / "visualizations"
        
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        created_files = []
        
        # 1. Matrice de confusion
        fig, ax = plt.subplots(figsize=(8, 6))
        cm = metrics.get('confusion_matrix')
        if cm is not None:
            sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', ax=ax,
                       xticklabels=['Non Fondée', 'Fondée'],
                       yticklabels=['Non Fondée', 'Fondée'])
            ax.set_xlabel('Prédiction')
            ax.set_ylabel('Réalité')
            ax.set_title('Matrice de Confusion')
            path = output_dir / "confusion_matrix.png"
            plt.savefig(path, dpi=150, bbox_inches='tight')
            created_files.append(str(path))
        plt.close()
        
        # 2. Courbe ROC
        if y_proba is not None:
            from sklearn.metrics import roc_curve, auc
            fpr, tpr, _ = roc_curve(y_true, y_proba)
            roc_auc = auc(fpr, tpr)
            
            fig, ax = plt.subplots(figsize=(8, 6))
            ax.plot(fpr, tpr, color='darkorange', lw=2, label=f'ROC (AUC = {roc_auc:.3f})')
            ax.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--')
            ax.set_xlim([0.0, 1.0])
            ax.set_ylim([0.0, 1.05])
            ax.set_xlabel('Taux Faux Positifs')
            ax.set_ylabel('Taux Vrais Positifs')
            ax.set_title('Courbe ROC')
            ax.legend(loc="lower right")
            path = output_dir / "roc_curve.png"
            plt.savefig(path, dpi=150, bbox_inches='tight')
            created_files.append(str(path))
            plt.close()
        
        # 3. Distribution des probabilités
        if y_proba is not None:
            fig, ax = plt.subplots(figsize=(10, 6))
            
            ax.hist(y_proba[y_true == 0], bins=50, alpha=0.5, label='Non Fondées', color='red')
            ax.hist(y_proba[y_true == 1], bins=50, alpha=0.5, label='Fondées', color='green')
            ax.set_xlabel('Probabilité prédite')
            ax.set_ylabel('Fréquence')
            ax.set_title('Distribution des Probabilités par Classe')
            ax.legend()
            path = output_dir / "probability_distribution.png"
            plt.savefig(path, dpi=150, bbox_inches='tight')
            created_files.append(str(path))
            plt.close()
        
        # 4. Performance par catégorie
        from sklearn.metrics import f1_score
        
        for cat_col in category_columns:
            if cat_col not in df.columns:
                continue
            
            cat_performance = []
            for cat in df[cat_col].unique():
                mask = df[cat_col] == cat
                if mask.sum() >= 10:
                    f1 = f1_score(y_true[mask], y_pred[mask], zero_division=0)
                    cat_performance.append({'category': cat, 'f1': f1, 'count': mask.sum()})
            
            if cat_performance:
                cat_df = pd.DataFrame(cat_performance).sort_values('f1', ascending=True)
                
                fig, ax = plt.subplots(figsize=(12, max(6, len(cat_df) * 0.4)))
                colors = ['green' if x >= 0.95 else 'orange' if x >= 0.90 else 'red' 
                         for x in cat_df['f1']]
                ax.barh(range(len(cat_df)), cat_df['f1'], color=colors)
                ax.set_yticks(range(len(cat_df)))
                ax.set_yticklabels(cat_df['category'])
                ax.set_xlabel('F1-Score')
                ax.set_title(f'Performance par {cat_col}')
                ax.axvline(x=0.95, color='green', linestyle='--', label='Objectif (95%)')
                ax.legend()
                
                path = output_dir / f"performance_by_{cat_col.lower().replace(' ', '_')}.png"
                plt.savefig(path, dpi=150, bbox_inches='tight')
                created_files.append(str(path))
                plt.close()
        
        logger.info(f"{len(created_files)} visualisations créées dans {output_dir}")
        return created_files


if __name__ == "__main__":
    print("Module de génération de rapports chargé avec succès")
