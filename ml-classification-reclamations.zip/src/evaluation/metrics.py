"""
Module d'évaluation et métriques
=================================
Calcule toutes les métriques de performance, fairness et business.
"""

import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, brier_score_loss,
    confusion_matrix, classification_report, matthews_corrcoef,
    precision_recall_curve, roc_curve
)
from scipy import stats
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
import logging

logger = logging.getLogger(__name__)


@dataclass
class ClassificationMetrics:
    """Métriques de classification."""
    accuracy: float
    precision_class_0: float
    precision_class_1: float
    recall_class_0: float
    recall_class_1: float
    f1_class_0: float
    f1_class_1: float
    f1_weighted: float
    f1_macro: float
    roc_auc: float = None
    average_precision: float = None
    brier_score: float = None
    mcc: float = None
    confusion_matrix: np.ndarray = None


@dataclass
class FairnessMetrics:
    """Métriques de fairness."""
    disparate_impact_ratio: Dict[str, float] = field(default_factory=dict)
    equal_opportunity_diff: Dict[str, float] = field(default_factory=dict)
    statistical_parity_diff: Dict[str, float] = field(default_factory=dict)
    overall_fair: bool = True


@dataclass
class BusinessMetrics:
    """Métriques business."""
    automation_rate: float
    rejection_rate: float
    validation_rate: float
    audit_rate: float
    precision_rejection: float
    precision_validation: float
    cost_per_error: float = None
    total_cost: float = None
    savings: float = None


@dataclass
class PerformanceReport:
    """Rapport de performance complet."""
    classification: ClassificationMetrics
    fairness: FairnessMetrics = None
    business: BusinessMetrics = None
    by_category: Dict[str, ClassificationMetrics] = field(default_factory=dict)


class MetricsCalculator:
    """Calcule toutes les métriques de performance."""
    
    def __init__(self):
        pass
    
    def calculate_classification_metrics(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: np.ndarray = None
    ) -> ClassificationMetrics:
        """
        Calcule les métriques de classification.
        
        Args:
            y_true: Labels vrais
            y_pred: Prédictions
            y_proba: Probabilités (optionnel)
            
        Returns:
            ClassificationMetrics
        """
        cm = confusion_matrix(y_true, y_pred)
        
        metrics = ClassificationMetrics(
            accuracy=accuracy_score(y_true, y_pred),
            precision_class_0=precision_score(y_true, y_pred, pos_label=0, zero_division=0),
            precision_class_1=precision_score(y_true, y_pred, pos_label=1, zero_division=0),
            recall_class_0=recall_score(y_true, y_pred, pos_label=0, zero_division=0),
            recall_class_1=recall_score(y_true, y_pred, pos_label=1, zero_division=0),
            f1_class_0=f1_score(y_true, y_pred, pos_label=0, zero_division=0),
            f1_class_1=f1_score(y_true, y_pred, pos_label=1, zero_division=0),
            f1_weighted=f1_score(y_true, y_pred, average='weighted', zero_division=0),
            f1_macro=f1_score(y_true, y_pred, average='macro', zero_division=0),
            mcc=matthews_corrcoef(y_true, y_pred),
            confusion_matrix=cm
        )
        
        if y_proba is not None:
            metrics.roc_auc = roc_auc_score(y_true, y_proba)
            metrics.average_precision = average_precision_score(y_true, y_proba)
            metrics.brier_score = brier_score_loss(y_true, y_proba)
        
        return metrics
    
    def calculate_fairness_metrics(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        sensitive_feature: np.ndarray,
        feature_name: str = "group"
    ) -> FairnessMetrics:
        """
        Calcule les métriques de fairness.
        
        Args:
            y_true: Labels vrais
            y_pred: Prédictions
            sensitive_feature: Feature sensible (ex: Famille Produit)
            feature_name: Nom de la feature
            
        Returns:
            FairnessMetrics
        """
        fairness = FairnessMetrics()
        
        unique_groups = np.unique(sensitive_feature)
        
        if len(unique_groups) < 2:
            logger.warning("Moins de 2 groupes, fairness non calculable")
            return fairness
        
        # Calculer les taux par groupe
        group_stats = {}
        for group in unique_groups:
            mask = sensitive_feature == group
            if mask.sum() < 10:  # Groupe trop petit
                continue
            
            group_stats[group] = {
                'selection_rate': y_pred[mask].mean(),
                'tpr': recall_score(y_true[mask], y_pred[mask], pos_label=1, zero_division=0),
                'fpr': 1 - recall_score(y_true[mask], y_pred[mask], pos_label=0, zero_division=0)
            }
        
        if len(group_stats) < 2:
            return fairness
        
        # Groupe de référence
        reference_group = max(group_stats.keys(), key=lambda x: group_stats[x]['selection_rate'])
        ref_rate = group_stats[reference_group]['selection_rate']
        ref_tpr = group_stats[reference_group]['tpr']
        
        for group, stats_dict in group_stats.items():
            if ref_rate > 0:
                dir_value = stats_dict['selection_rate'] / ref_rate
                fairness.disparate_impact_ratio[f"{feature_name}_{group}"] = dir_value
                
                if dir_value < 0.8:
                    fairness.overall_fair = False
            
            eod_value = abs(stats_dict['tpr'] - ref_tpr)
            fairness.equal_opportunity_diff[f"{feature_name}_{group}"] = eod_value
            
            spd_value = abs(stats_dict['selection_rate'] - ref_rate)
            fairness.statistical_parity_diff[f"{feature_name}_{group}"] = spd_value
        
        return fairness
    
    def calculate_business_metrics(
        self,
        y_true: np.ndarray,
        decisions: np.ndarray,
        cost_false_positive: float = 100,
        cost_false_negative: float = 50,
        cost_per_audit: float = 10,
        savings_per_auto: float = 15
    ) -> BusinessMetrics:
        """
        Calcule les métriques business.
        
        Args:
            y_true: Labels vrais
            decisions: Décisions (REJET_AUTO, VALIDATION_AUTO, AUDIT)
            cost_false_positive: Coût d'une fausse validation
            cost_false_negative: Coût d'un faux rejet
            cost_per_audit: Coût d'un audit manuel
            savings_per_auto: Économies par décision automatique
            
        Returns:
            BusinessMetrics
        """
        n_total = len(y_true)
        
        mask_rejection = decisions == 'REJET_AUTO'
        mask_validation = decisions == 'VALIDATION_AUTO'
        mask_audit = decisions == 'AUDIT'
        
        n_rejection = mask_rejection.sum()
        n_validation = mask_validation.sum()
        n_audit = mask_audit.sum()
        
        # Précisions
        if n_rejection > 0:
            precision_rejection = (y_true[mask_rejection] == 0).mean()
        else:
            precision_rejection = 1.0
        
        if n_validation > 0:
            precision_validation = (y_true[mask_validation] == 1).mean()
        else:
            precision_validation = 1.0
        
        # Coûts
        fp_rejections = (y_true[mask_rejection] == 1).sum() if n_rejection > 0 else 0
        fn_validations = (y_true[mask_validation] == 0).sum() if n_validation > 0 else 0
        
        total_cost = (
            fp_rejections * cost_false_negative +
            fn_validations * cost_false_positive +
            n_audit * cost_per_audit
        )
        
        savings = (n_rejection + n_validation) * savings_per_auto
        
        return BusinessMetrics(
            automation_rate=(n_rejection + n_validation) / n_total,
            rejection_rate=n_rejection / n_total,
            validation_rate=n_validation / n_total,
            audit_rate=n_audit / n_total,
            precision_rejection=precision_rejection,
            precision_validation=precision_validation,
            cost_per_error=(total_cost / max(fp_rejections + fn_validations, 1)),
            total_cost=total_cost,
            savings=savings - total_cost
        )
    
    def calculate_metrics_by_category(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: np.ndarray,
        category: np.ndarray,
        category_name: str = "category"
    ) -> Dict[str, ClassificationMetrics]:
        """
        Calcule les métriques par catégorie.
        
        Args:
            y_true: Labels vrais
            y_pred: Prédictions
            y_proba: Probabilités
            category: Catégories
            category_name: Nom de la catégorie
            
        Returns:
            Dictionnaire des métriques par catégorie
        """
        metrics_by_cat = {}
        
        unique_categories = np.unique(category)
        
        for cat in unique_categories:
            mask = category == cat
            if mask.sum() < 10:
                continue
            
            cat_proba = y_proba[mask] if y_proba is not None else None
            
            try:
                metrics = self.calculate_classification_metrics(
                    y_true[mask],
                    y_pred[mask],
                    cat_proba
                )
                metrics_by_cat[f"{category_name}_{cat}"] = metrics
            except Exception as e:
                logger.warning(f"Erreur calcul métriques pour {cat}: {e}")
                continue
        
        return metrics_by_cat
    
    def generate_performance_report(
        self,
        y_true: np.ndarray,
        y_pred: np.ndarray,
        y_proba: np.ndarray = None,
        decisions: np.ndarray = None,
        categories: Dict[str, np.ndarray] = None
    ) -> PerformanceReport:
        """
        Génère un rapport de performance complet.
        
        Args:
            y_true: Labels vrais
            y_pred: Prédictions
            y_proba: Probabilités
            decisions: Décisions tri-classes
            categories: Dictionnaire de catégories pour analyse
            
        Returns:
            PerformanceReport
        """
        # Métriques de classification
        classification = self.calculate_classification_metrics(y_true, y_pred, y_proba)
        
        # Métriques business si décisions disponibles
        business = None
        if decisions is not None:
            business = self.calculate_business_metrics(y_true, decisions)
        
        # Métriques par catégorie
        by_category = {}
        if categories:
            for cat_name, cat_values in categories.items():
                cat_metrics = self.calculate_metrics_by_category(
                    y_true, y_pred, y_proba, cat_values, cat_name
                )
                by_category.update(cat_metrics)
        
        return PerformanceReport(
            classification=classification,
            business=business,
            by_category=by_category
        )


def get_false_predictions(
    df: pd.DataFrame,
    y_true: np.ndarray,
    y_pred: np.ndarray,
    y_proba: np.ndarray = None
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """
    Extrait les faux positifs et faux négatifs.
    
    Args:
        df: DataFrame original
        y_true: Labels vrais
        y_pred: Prédictions
        y_proba: Probabilités
        
    Returns:
        Tuple (DataFrame faux positifs, DataFrame faux négatifs)
    """
    df_analysis = df.copy()
    df_analysis['y_true'] = y_true
    df_analysis['y_pred'] = y_pred
    
    if y_proba is not None:
        df_analysis['probability'] = y_proba
    
    # Faux positifs: prédit 1, vrai 0
    mask_fp = (y_pred == 1) & (y_true == 0)
    df_false_positives = df_analysis[mask_fp].copy()
    df_false_positives['error_type'] = 'Faux Positif (Fausse Validation)'
    
    # Faux négatifs: prédit 0, vrai 1
    mask_fn = (y_pred == 0) & (y_true == 1)
    df_false_negatives = df_analysis[mask_fn].copy()
    df_false_negatives['error_type'] = 'Faux Négatif (Faux Rejet)'
    
    logger.info(f"Faux positifs: {len(df_false_positives)}")
    logger.info(f"Faux négatifs: {len(df_false_negatives)}")
    
    return df_false_positives, df_false_negatives


def create_error_analysis_report(
    df_fp: pd.DataFrame,
    df_fn: pd.DataFrame,
    category_columns: List[str] = None
) -> Dict[str, pd.DataFrame]:
    """
    Crée un rapport d'analyse des erreurs.
    
    Args:
        df_fp: DataFrame des faux positifs
        df_fn: DataFrame des faux négatifs
        category_columns: Colonnes pour l'analyse par catégorie
        
    Returns:
        Dictionnaire de DataFrames d'analyse
    """
    reports = {}
    
    # Résumé global
    summary = pd.DataFrame({
        'Type Erreur': ['Faux Positifs', 'Faux Négatifs', 'Total'],
        'Nombre': [len(df_fp), len(df_fn), len(df_fp) + len(df_fn)],
        'Pourcentage': [
            len(df_fp) / (len(df_fp) + len(df_fn)) * 100 if len(df_fp) + len(df_fn) > 0 else 0,
            len(df_fn) / (len(df_fp) + len(df_fn)) * 100 if len(df_fp) + len(df_fn) > 0 else 0,
            100
        ]
    })
    reports['summary'] = summary
    
    # Analyse par catégorie
    if category_columns:
        for col in category_columns:
            if col in df_fp.columns and col in df_fn.columns:
                # Distribution des FP par catégorie
                fp_dist = df_fp[col].value_counts().reset_index()
                fp_dist.columns = [col, 'FP_count']
                
                # Distribution des FN par catégorie
                fn_dist = df_fn[col].value_counts().reset_index()
                fn_dist.columns = [col, 'FN_count']
                
                # Merge
                cat_analysis = fp_dist.merge(fn_dist, on=col, how='outer').fillna(0)
                cat_analysis['Total_errors'] = cat_analysis['FP_count'] + cat_analysis['FN_count']
                cat_analysis = cat_analysis.sort_values('Total_errors', ascending=False)
                
                reports[f'errors_by_{col}'] = cat_analysis
    
    return reports


if __name__ == "__main__":
    print("Module d'évaluation chargé avec succès")
