"""
Module de prétraitement des données
====================================
Pipeline complet de preprocessing pour les réclamations bancaires.
Inclut encodage, transformation, feature engineering.
"""

import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.preprocessing import StandardScaler, RobustScaler, LabelEncoder
from sklearn.impute import SimpleImputer
from sklearn.pipeline import Pipeline
from category_encoders import TargetEncoder, WOEEncoder
import joblib
from pathlib import Path
from typing import List, Dict, Optional, Tuple, Union
import logging
import yaml
import warnings
warnings.filterwarnings('ignore')

logger = logging.getLogger(__name__)


class MissingValueHandler(BaseEstimator, TransformerMixin):
    """Gère les valeurs manquantes avec des stratégies différentes par type de colonne."""
    
    def __init__(
        self,
        numerical_strategy: str = 'median',
        categorical_strategy: str = 'mode',
        flag_missing: bool = True
    ):
        self.numerical_strategy = numerical_strategy
        self.categorical_strategy = categorical_strategy
        self.flag_missing = flag_missing
        self.numerical_imputer_ = None
        self.categorical_imputer_ = None
        self.numerical_cols_ = []
        self.categorical_cols_ = []
        self.missing_flags_ = []
    
    def fit(self, X: pd.DataFrame, y=None):
        X = X.copy()
        
        # Identifier les types de colonnes
        self.numerical_cols_ = X.select_dtypes(include=[np.number]).columns.tolist()
        self.categorical_cols_ = X.select_dtypes(exclude=[np.number]).columns.tolist()
        
        # Créer les imputers
        if self.numerical_cols_:
            self.numerical_imputer_ = SimpleImputer(strategy=self.numerical_strategy)
            self.numerical_imputer_.fit(X[self.numerical_cols_])
        
        if self.categorical_cols_:
            self.categorical_imputer_ = SimpleImputer(
                strategy='most_frequent' if self.categorical_strategy == 'mode' else 'constant',
                fill_value='MISSING' if self.categorical_strategy == 'constant' else None
            )
            self.categorical_imputer_.fit(X[self.categorical_cols_])
        
        # Identifier les colonnes avec missing pour flags
        if self.flag_missing:
            for col in X.columns:
                if X[col].isna().sum() > 0:
                    self.missing_flags_.append(col)
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()
        
        # Créer les flags de missing
        if self.flag_missing:
            for col in self.missing_flags_:
                if col in X.columns:
                    X[f'{col}_is_missing'] = X[col].isna().astype(int)
        
        # Imputer les valeurs numériques
        if self.numerical_cols_ and self.numerical_imputer_:
            cols_present = [c for c in self.numerical_cols_ if c in X.columns]
            if cols_present:
                X[cols_present] = self.numerical_imputer_.transform(X[cols_present])
        
        # Imputer les valeurs catégorielles
        if self.categorical_cols_ and self.categorical_imputer_:
            cols_present = [c for c in self.categorical_cols_ if c in X.columns]
            if cols_present:
                X[cols_present] = self.categorical_imputer_.transform(X[cols_present])
        
        return X


class CategoricalEncoder(BaseEstimator, TransformerMixin):
    """Encode les variables catégorielles avec différentes stratégies."""
    
    def __init__(
        self,
        high_cardinality_cols: List[str] = None,
        low_cardinality_cols: List[str] = None,
        high_cardinality_method: str = 'target',
        smoothing: float = 15.0,
        handle_unknown: str = 'value'
    ):
        self.high_cardinality_cols = high_cardinality_cols or []
        self.low_cardinality_cols = low_cardinality_cols or []
        self.high_cardinality_method = high_cardinality_method
        self.smoothing = smoothing
        self.handle_unknown = handle_unknown
        self.target_encoder_ = None
        self.onehot_mappings_ = {}
        self.feature_names_ = []
    
    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        X = X.copy()
        
        # Target encoding pour high cardinality
        hc_cols_present = [c for c in self.high_cardinality_cols if c in X.columns]
        if hc_cols_present and y is not None:
            self.target_encoder_ = TargetEncoder(
                cols=hc_cols_present,
                smoothing=self.smoothing,
                handle_unknown=self.handle_unknown
            )
            self.target_encoder_.fit(X[hc_cols_present], y)
        
        # One-hot encoding pour low cardinality
        lc_cols_present = [c for c in self.low_cardinality_cols if c in X.columns]
        for col in lc_cols_present:
            unique_values = X[col].dropna().unique()
            self.onehot_mappings_[col] = list(unique_values)
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()
        
        # Target encoding
        hc_cols_present = [c for c in self.high_cardinality_cols if c in X.columns]
        if hc_cols_present and self.target_encoder_:
            encoded = self.target_encoder_.transform(X[hc_cols_present])
            for col in hc_cols_present:
                X[f'{col}_encoded'] = encoded[col]
            X = X.drop(columns=hc_cols_present)
        
        # One-hot encoding
        for col, values in self.onehot_mappings_.items():
            if col in X.columns:
                for val in values:
                    col_name = f'{col}_{val}'.replace(' ', '_').replace('|', '_')
                    X[col_name] = (X[col] == val).astype(int)
                X = X.drop(columns=[col])
        
        self.feature_names_ = X.columns.tolist()
        return X


class NumericalTransformer(BaseEstimator, TransformerMixin):
    """Transforme les variables numériques (log, scaling, clipping)."""
    
    def __init__(
        self,
        log_transform_cols: List[str] = None,
        scaling_method: str = 'robust',
        clip_outliers: bool = True,
        clip_quantiles: Tuple[float, float] = (0.01, 0.99)
    ):
        self.log_transform_cols = log_transform_cols or []
        self.scaling_method = scaling_method
        self.clip_outliers = clip_outliers
        self.clip_quantiles = clip_quantiles
        self.scaler_ = None
        self.clip_bounds_ = {}
        self.numerical_cols_ = []
    
    def fit(self, X: pd.DataFrame, y=None):
        X = X.copy()
        self.numerical_cols_ = X.select_dtypes(include=[np.number]).columns.tolist()
        
        # Calculer les bornes de clipping
        if self.clip_outliers:
            for col in self.numerical_cols_:
                lower = X[col].quantile(self.clip_quantiles[0])
                upper = X[col].quantile(self.clip_quantiles[1])
                self.clip_bounds_[col] = (lower, upper)
        
        # Log transform
        X_transformed = X.copy()
        for col in self.log_transform_cols:
            if col in X_transformed.columns:
                X_transformed[col] = np.log1p(X_transformed[col].clip(lower=0))
        
        # Scaler
        if self.scaling_method == 'robust':
            self.scaler_ = RobustScaler()
        else:
            self.scaler_ = StandardScaler()
        
        if self.numerical_cols_:
            self.scaler_.fit(X_transformed[self.numerical_cols_])
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()
        
        # Clipping
        if self.clip_outliers:
            for col, (lower, upper) in self.clip_bounds_.items():
                if col in X.columns:
                    X[col] = X[col].clip(lower=lower, upper=upper)
        
        # Log transform
        for col in self.log_transform_cols:
            if col in X.columns:
                X[col] = np.log1p(X[col].clip(lower=0))
        
        # Scaling
        cols_present = [c for c in self.numerical_cols_ if c in X.columns]
        if cols_present and self.scaler_:
            X[cols_present] = self.scaler_.transform(X[cols_present])
        
        return X


class FeatureEngineer(BaseEstimator, TransformerMixin):
    """Crée des features dérivées et des agrégations."""
    
    def __init__(
        self,
        create_ratios: bool = True,
        create_temporal_features: bool = True,
        create_aggregations: bool = True,
        date_column: str = None,
        target_column: str = None
    ):
        self.create_ratios = create_ratios
        self.create_temporal_features = create_temporal_features
        self.create_aggregations = create_aggregations
        self.date_column = date_column
        self.target_column = target_column
        self.aggregation_stats_ = {}
    
    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        X = X.copy()
        
        # Calculer les agrégations par motif
        if self.create_aggregations and y is not None:
            X_with_target = X.copy()
            X_with_target['_target'] = y.values
            
            # Stats par motif_complet si présent
            if 'motif_complet' in X.columns:
                agg = X_with_target.groupby('motif_complet').agg({
                    '_target': ['mean', 'count']
                }).reset_index()
                agg.columns = ['motif_complet', 'taux_fondees_motif', 'nb_occurences_motif']
                self.aggregation_stats_['motif'] = agg.set_index('motif_complet').to_dict('index')
            
            # Stats par Famille Produit si présent
            if 'Famille Produit' in X.columns:
                agg = X_with_target.groupby('Famille Produit').agg({
                    '_target': ['mean', 'count']
                }).reset_index()
                agg.columns = ['Famille Produit', 'taux_fondees_famille', 'nb_occurences_famille']
                self.aggregation_stats_['famille'] = agg.set_index('Famille Produit').to_dict('index')
        
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        X = X.copy()
        
        # Features temporelles
        if self.create_temporal_features and self.date_column:
            if self.date_column in X.columns:
                date_col = pd.to_datetime(X[self.date_column], errors='coerce')
                X['mois'] = date_col.dt.month
                X['trimestre'] = date_col.dt.quarter
                X['jour_semaine'] = date_col.dt.dayofweek
                X['est_debut_mois'] = (date_col.dt.day <= 5).astype(int)
                X['est_fin_mois'] = (date_col.dt.day >= 25).astype(int)
                X['annee'] = date_col.dt.year
        
        # Ratios financiers
        if self.create_ratios:
            if 'Montant demandé' in X.columns and 'PNB' in X.columns:
                X['ratio_montant_pnb'] = X['Montant demandé'] / (X['PNB'].abs() + 1)
            
            if 'Montant demandé' in X.columns:
                X['montant_log'] = np.log1p(X['Montant demandé'].clip(lower=0))
                X['flag_montant_eleve'] = (X['Montant demandé'] > X['Montant demandé'].median() * 2).astype(int)
        
        # Agrégations par groupe
        if self.create_aggregations:
            if 'motif_complet' in X.columns and 'motif' in self.aggregation_stats_:
                stats = self.aggregation_stats_['motif']
                X['taux_fondees_motif'] = X['motif_complet'].map(
                    lambda x: stats.get(x, {}).get('taux_fondees_motif', 0.5)
                )
                X['nb_occurences_motif'] = X['motif_complet'].map(
                    lambda x: stats.get(x, {}).get('nb_occurences_motif', 1)
                )
            
            if 'Famille Produit' in X.columns and 'famille' in self.aggregation_stats_:
                stats = self.aggregation_stats_['famille']
                X['taux_fondees_famille'] = X['Famille Produit'].map(
                    lambda x: stats.get(x, {}).get('taux_fondees_famille', 0.5)
                )
        
        return X


class PreprocessingPipeline:
    """Pipeline complet de prétraitement."""
    
    def __init__(self, config_path: str = "configs/config.yaml"):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.missing_handler = None
        self.feature_engineer = None
        self.categorical_encoder = None
        self.numerical_transformer = None
        self.feature_names_ = []
        self.is_fitted = False
    
    def _init_components(self, X: pd.DataFrame):
        """Initialise les composants du pipeline."""
        
        # Détecter les colonnes présentes
        high_card_cols = [c for c in self.config['data']['categorical_features']['high_cardinality'] 
                         if c in X.columns]
        low_card_cols = [c for c in self.config['data']['categorical_features']['low_cardinality'] 
                        if c in X.columns]
        log_cols = [c for c in self.config['preprocessing']['numerical_transform'].get('log_transform_columns', [])
                   if c in X.columns]
        
        # Gestion valeurs manquantes
        self.missing_handler = MissingValueHandler(
            numerical_strategy=self.config['data']['missing_values']['numerical_strategy'],
            categorical_strategy=self.config['data']['missing_values']['categorical_strategy'],
            flag_missing=self.config['data']['missing_values']['flag_missing']
        )
        
        # Feature engineering
        date_col = None
        for col in self.config['data']['temporal_features']:
            if col in X.columns:
                date_col = col
                break
        
        self.feature_engineer = FeatureEngineer(
            create_ratios=self.config['preprocessing']['feature_engineering']['create_ratios'],
            create_temporal_features=self.config['preprocessing']['feature_engineering']['create_temporal_features'],
            create_aggregations=self.config['preprocessing']['feature_engineering']['create_aggregations'],
            date_column=date_col,
            target_column=self.config['data']['target_column']
        )
        
        # Encodage catégoriel
        self.categorical_encoder = CategoricalEncoder(
            high_cardinality_cols=high_card_cols,
            low_cardinality_cols=low_card_cols,
            high_cardinality_method=self.config['preprocessing']['encoding']['high_cardinality_method'],
            smoothing=self.config['preprocessing']['encoding']['target_encoding_smoothing']
        )
        
        # Transformation numérique
        self.numerical_transformer = NumericalTransformer(
            log_transform_cols=log_cols,
            scaling_method=self.config['preprocessing']['numerical_transform']['scaling_method'],
            clip_outliers=self.config['preprocessing']['numerical_transform']['clip_outliers'],
            clip_quantiles=tuple(self.config['preprocessing']['numerical_transform']['clip_quantiles'])
        )
    
    def fit(self, X: pd.DataFrame, y: pd.Series = None):
        """Fit le pipeline sur les données d'entraînement."""
        logger.info("Fitting preprocessing pipeline...")
        
        self._init_components(X)
        
        # Fit séquentiel
        X_transformed = self.missing_handler.fit_transform(X)
        X_transformed = self.feature_engineer.fit_transform(X_transformed, y)
        X_transformed = self.categorical_encoder.fit_transform(X_transformed, y)
        X_transformed = self.numerical_transformer.fit_transform(X_transformed)
        
        self.feature_names_ = X_transformed.columns.tolist()
        self.is_fitted = True
        
        logger.info(f"Pipeline fitted. {len(self.feature_names_)} features créées.")
        return self
    
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Transforme les données avec le pipeline fitté."""
        if not self.is_fitted:
            raise ValueError("Pipeline must be fitted before transform")
        
        X_transformed = self.missing_handler.transform(X)
        X_transformed = self.feature_engineer.transform(X_transformed)
        X_transformed = self.categorical_encoder.transform(X_transformed)
        X_transformed = self.numerical_transformer.transform(X_transformed)
        
        return X_transformed
    
    def fit_transform(self, X: pd.DataFrame, y: pd.Series = None) -> pd.DataFrame:
        """Fit et transforme les données."""
        self.fit(X, y)
        return self.transform(X)
    
    def save(self, path: Union[str, Path]):
        """Sauvegarde le pipeline."""
        path = Path(path)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)
        logger.info(f"Pipeline sauvegardé: {path}")
    
    @classmethod
    def load(cls, path: Union[str, Path]) -> 'PreprocessingPipeline':
        """Charge un pipeline sauvegardé."""
        return joblib.load(path)


def preprocess_data(
    X: pd.DataFrame,
    y: pd.Series = None,
    config_path: str = "configs/config.yaml",
    fit: bool = True,
    pipeline: PreprocessingPipeline = None
) -> Tuple[pd.DataFrame, PreprocessingPipeline]:
    """
    Fonction utilitaire pour prétraiter les données.
    
    Args:
        X: Features
        y: Target (optionnel, requis pour fit)
        config_path: Chemin config
        fit: Si True, fit le pipeline
        pipeline: Pipeline existant (si fit=False)
        
    Returns:
        Tuple (X transformé, pipeline)
    """
    if fit:
        pipeline = PreprocessingPipeline(config_path)
        X_transformed = pipeline.fit_transform(X, y)
    else:
        if pipeline is None:
            raise ValueError("Pipeline requis si fit=False")
        X_transformed = pipeline.transform(X)
    
    return X_transformed, pipeline


if __name__ == "__main__":
    # Test du module
    print("Module de preprocessing chargé avec succès")
