"""
Module de chargement et préparation des données
===============================================
Gère le chargement des fichiers Excel/CSV et la préparation initiale des données.
"""

import pandas as pd
import numpy as np
from pathlib import Path
from typing import Tuple, Optional, Dict, List, Union
import logging
from datetime import datetime
import yaml

logger = logging.getLogger(__name__)


class DataLoader:
    """Classe pour charger et préparer les données de réclamations bancaires."""
    
    def __init__(self, config_path: str = "configs/config.yaml"):
        """
        Initialise le DataLoader avec la configuration.
        
        Args:
            config_path: Chemin vers le fichier de configuration
        """
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.target_column = self.config['data']['target_column']
        self.categorical_features = (
            self.config['data']['categorical_features']['high_cardinality'] +
            self.config['data']['categorical_features']['low_cardinality']
        )
        self.numerical_features = self.config['data']['numerical_features']
        self.temporal_features = self.config['data']['temporal_features']
    
    def load_data(
        self, 
        file_path: Union[str, Path],
        sheet_name: Optional[str] = None
    ) -> pd.DataFrame:
        """
        Charge les données depuis un fichier Excel ou CSV.
        
        Args:
            file_path: Chemin vers le fichier de données
            sheet_name: Nom de la feuille Excel (si applicable)
            
        Returns:
            DataFrame avec les données chargées
        """
        file_path = Path(file_path)
        logger.info(f"Chargement des données depuis {file_path}")
        
        if file_path.suffix in ['.xlsx', '.xls', '.xlsm']:
            df = pd.read_excel(file_path, sheet_name=sheet_name)
        elif file_path.suffix == '.csv':
            df = pd.read_csv(file_path)
        else:
            raise ValueError(f"Format de fichier non supporté: {file_path.suffix}")
        
        logger.info(f"Données chargées: {df.shape[0]} lignes, {df.shape[1]} colonnes")
        return df
    
    def detect_columns(self, df: pd.DataFrame) -> Dict[str, List[str]]:
        """
        Détecte automatiquement les types de colonnes dans le DataFrame.
        
        Args:
            df: DataFrame à analyser
            
        Returns:
            Dictionnaire avec les colonnes par type
        """
        detected = {
            'target': None,
            'categorical': [],
            'numerical': [],
            'temporal': [],
            'text': [],
            'unknown': []
        }
        
        for col in df.columns:
            col_lower = col.lower()
            
            # Détection de la cible
            if any(x in col_lower for x in ['fondée', 'fondee', 'target', 'cible', 'label']):
                detected['target'] = col
                continue
            
            # Détection temporelle
            if df[col].dtype == 'datetime64[ns]' or 'date' in col_lower:
                detected['temporal'].append(col)
                continue
            
            # Détection numérique
            if pd.api.types.is_numeric_dtype(df[col]):
                detected['numerical'].append(col)
                continue
            
            # Détection catégorielle vs texte
            if df[col].dtype == 'object':
                unique_ratio = df[col].nunique() / len(df)
                avg_len = df[col].astype(str).str.len().mean()
                
                if avg_len > 50 or unique_ratio > 0.5:
                    detected['text'].append(col)
                else:
                    detected['categorical'].append(col)
                continue
            
            detected['unknown'].append(col)
        
        logger.info(f"Colonnes détectées: {detected}")
        return detected
    
    def validate_data(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Valide la qualité des données et retourne un rapport.
        
        Args:
            df: DataFrame à valider
            
        Returns:
            Dictionnaire avec les résultats de validation
        """
        validation_report = {
            'total_rows': len(df),
            'total_columns': len(df.columns),
            'missing_values': {},
            'duplicates': df.duplicated().sum(),
            'target_distribution': None,
            'issues': []
        }
        
        # Analyse des valeurs manquantes
        for col in df.columns:
            missing_count = df[col].isna().sum()
            if missing_count > 0:
                missing_pct = missing_count / len(df) * 100
                validation_report['missing_values'][col] = {
                    'count': int(missing_count),
                    'percentage': round(missing_pct, 2)
                }
                if missing_pct > 50:
                    validation_report['issues'].append(
                        f"Colonne '{col}' a {missing_pct:.1f}% de valeurs manquantes"
                    )
        
        # Distribution de la cible
        if self.target_column in df.columns:
            target_dist = df[self.target_column].value_counts(normalize=True).to_dict()
            validation_report['target_distribution'] = target_dist
            
            # Vérifier le déséquilibre
            if len(target_dist) == 2:
                min_class_ratio = min(target_dist.values())
                if min_class_ratio < 0.2:
                    validation_report['issues'].append(
                        f"Déséquilibre important: classe minoritaire = {min_class_ratio:.1%}"
                    )
        else:
            validation_report['issues'].append(
                f"Colonne cible '{self.target_column}' non trouvée"
            )
        
        # Vérifier les doublons
        if validation_report['duplicates'] > 0:
            dup_pct = validation_report['duplicates'] / len(df) * 100
            validation_report['issues'].append(
                f"{validation_report['duplicates']} doublons détectés ({dup_pct:.1f}%)"
            )
        
        return validation_report
    
    def prepare_data(
        self,
        df: pd.DataFrame,
        remove_duplicates: bool = True,
        parse_dates: bool = True
    ) -> pd.DataFrame:
        """
        Prépare les données pour le preprocessing.
        
        Args:
            df: DataFrame brut
            remove_duplicates: Supprimer les doublons
            parse_dates: Convertir les colonnes de dates
            
        Returns:
            DataFrame préparé
        """
        df = df.copy()
        logger.info("Préparation des données...")
        
        # Suppression des doublons
        if remove_duplicates:
            initial_rows = len(df)
            df = df.drop_duplicates()
            removed = initial_rows - len(df)
            if removed > 0:
                logger.info(f"Supprimé {removed} doublons")
        
        # Conversion des dates
        if parse_dates:
            for col in df.columns:
                if 'date' in col.lower():
                    try:
                        df[col] = pd.to_datetime(df[col], errors='coerce')
                        logger.info(f"Colonne '{col}' convertie en datetime")
                    except Exception as e:
                        logger.warning(f"Impossible de convertir '{col}' en datetime: {e}")
        
        # Nettoyage des noms de colonnes
        df.columns = df.columns.str.strip()
        
        # Conversion de la cible en binaire si nécessaire
        if self.target_column in df.columns:
            target_values = df[self.target_column].unique()
            if not set(target_values).issubset({0, 1, 0.0, 1.0}):
                # Essayer de mapper les valeurs
                if any(str(v).lower() in ['oui', 'yes', 'true', 'fondée', 'fondee'] 
                       for v in target_values):
                    df[self.target_column] = df[self.target_column].apply(
                        lambda x: 1 if str(x).lower() in ['oui', 'yes', 'true', 'fondée', 'fondee', '1'] else 0
                    )
                    logger.info("Cible convertie en binaire (0/1)")
        
        return df
    
    def create_motif_complet(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Crée la feature motif_complet si les colonnes de hiérarchie produit existent.
        
        Args:
            df: DataFrame avec les colonnes de hiérarchie produit
            
        Returns:
            DataFrame avec la feature motif_complet ajoutée
        """
        df = df.copy()
        
        hierarchy_cols = ['Famille Produit', 'Catégorie', 'Sous-catégorie']
        available_cols = [col for col in hierarchy_cols if col in df.columns]
        
        if len(available_cols) >= 2:
            df['motif_complet'] = df[available_cols].astype(str).agg('|'.join, axis=1)
            logger.info(f"Feature 'motif_complet' créée à partir de {available_cols}")
        
        return df
    
    def split_temporal(
        self,
        df: pd.DataFrame,
        date_column: str,
        train_ratio: float = 0.70,
        val_ratio: float = 0.15
    ) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        """
        Effectue un split temporel des données.
        
        Args:
            df: DataFrame avec une colonne de date
            date_column: Nom de la colonne de date
            train_ratio: Proportion pour l'entraînement
            val_ratio: Proportion pour la validation
            
        Returns:
            Tuple (train, validation, test) DataFrames
        """
        df = df.sort_values(date_column).reset_index(drop=True)
        
        n = len(df)
        train_end = int(n * train_ratio)
        val_end = int(n * (train_ratio + val_ratio))
        
        train = df.iloc[:train_end]
        val = df.iloc[train_end:val_end]
        test = df.iloc[val_end:]
        
        logger.info(f"Split temporel: Train={len(train)}, Val={len(val)}, Test={len(test)}")
        
        return train, val, test


def load_and_prepare_data(
    file_path: str,
    config_path: str = "configs/config.yaml"
) -> Tuple[pd.DataFrame, Dict]:
    """
    Fonction utilitaire pour charger et préparer les données en une seule étape.
    
    Args:
        file_path: Chemin vers le fichier de données
        config_path: Chemin vers la configuration
        
    Returns:
        Tuple (DataFrame préparé, rapport de validation)
    """
    loader = DataLoader(config_path)
    df = loader.load_data(file_path)
    df = loader.prepare_data(df)
    df = loader.create_motif_complet(df)
    validation_report = loader.validate_data(df)
    
    return df, validation_report


if __name__ == "__main__":
    # Test du module
    import sys
    if len(sys.argv) > 1:
        file_path = sys.argv[1]
        df, report = load_and_prepare_data(file_path)
        print(f"\nRapport de validation:")
        print(f"- Lignes: {report['total_rows']}")
        print(f"- Colonnes: {report['total_columns']}")
        print(f"- Doublons: {report['duplicates']}")
        if report['issues']:
            print(f"- Problèmes détectés:")
            for issue in report['issues']:
                print(f"  * {issue}")
