#!/usr/bin/env python3
"""
Pipeline Principal - Classification des Réclamations Bancaires
================================================================
Script principal qui orchestre tout le workflow de ML.

Usage:
    python run_pipeline.py --data path/to/data.xlsx --output path/to/outputs
"""

import pandas as pd
import numpy as np
import argparse
import logging
from pathlib import Path
from datetime import datetime
import yaml
import joblib
import sys
import warnings
warnings.filterwarnings('ignore')

# Ajouter le répertoire src au path
sys.path.insert(0, str(Path(__file__).parent))

from src.data.loader import DataLoader, load_and_prepare_data
from src.data.preprocessor import PreprocessingPipeline, preprocess_data
from src.models.trainer import ModelTrainer, compare_models
from src.models.calibrator import ProbabilityCalibrator, ThresholdOptimizer, calibrate_and_optimize
from src.evaluation.metrics import MetricsCalculator, get_false_predictions, create_error_analysis_report

# Configuration du logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler('logs/pipeline.log')
    ]
)
logger = logging.getLogger(__name__)


class MLPipeline:
    """Pipeline complet de ML pour la classification des réclamations."""
    
    def __init__(self, config_path: str = "configs/config.yaml"):
        with open(config_path, 'r') as f:
            self.config = yaml.safe_load(f)
        
        self.config_path = config_path
        self.loader = DataLoader(config_path)
        self.preprocessor = None
        self.trainer = ModelTrainer(config_path)
        self.calibrator = None
        self.threshold_optimizer = None
        self.metrics_calculator = MetricsCalculator()
        
        # Données
        self.df_raw = None
        self.df_train = None
        self.df_val = None
        self.df_test = None
        self.X_train = None
        self.X_val = None
        self.X_test = None
        self.y_train = None
        self.y_val = None
        self.y_test = None
        
        # Résultats
        self.results = {}
        self.best_model = None
        self.best_model_name = None
        self.performance_report = None
    
    def load_data(self, file_path: str):
        """Charge les données depuis un fichier."""
        logger.info(f"Chargement des données: {file_path}")
        
        self.df_raw = self.loader.load_data(file_path)
        self.df_raw = self.loader.prepare_data(self.df_raw)
        self.df_raw = self.loader.create_motif_complet(self.df_raw)
        
        validation_report = self.loader.validate_data(self.df_raw)
        logger.info(f"Validation: {validation_report['total_rows']} lignes chargées")
        
        if validation_report['issues']:
            for issue in validation_report['issues']:
                logger.warning(f"Issue: {issue}")
        
        return validation_report
    
    def split_data(self, temporal_split: bool = True):
        """Divise les données en train/val/test."""
        logger.info("Division des données...")
        
        target_col = self.config['data']['target_column']
        
        if target_col not in self.df_raw.columns:
            # Chercher une colonne similaire
            for col in self.df_raw.columns:
                if 'fond' in col.lower():
                    target_col = col
                    logger.info(f"Colonne cible détectée: {target_col}")
                    break
        
        # Split temporel si date disponible
        date_col = None
        for col in self.config['data']['temporal_features']:
            if col in self.df_raw.columns:
                date_col = col
                break
        
        if temporal_split and date_col:
            self.df_train, self.df_val, self.df_test = self.loader.split_temporal(
                self.df_raw, date_col,
                train_ratio=1 - self.config['validation']['test_size'] - self.config['validation']['val_size'],
                val_ratio=self.config['validation']['val_size']
            )
        else:
            # Split random stratifié
            from sklearn.model_selection import train_test_split
            
            train_val, self.df_test = train_test_split(
                self.df_raw,
                test_size=self.config['validation']['test_size'],
                stratify=self.df_raw[target_col],
                random_state=self.config['validation']['random_state']
            )
            
            val_size_adjusted = self.config['validation']['val_size'] / (1 - self.config['validation']['test_size'])
            self.df_train, self.df_val = train_test_split(
                train_val,
                test_size=val_size_adjusted,
                stratify=train_val[target_col],
                random_state=self.config['validation']['random_state']
            )
        
        logger.info(f"Train: {len(self.df_train)}, Val: {len(self.df_val)}, Test: {len(self.df_test)}")
        
        # Séparer features et target
        self.y_train = self.df_train[target_col].astype(int)
        self.y_val = self.df_val[target_col].astype(int)
        self.y_test = self.df_test[target_col].astype(int)
        
        # Supprimer la colonne cible des features
        feature_cols = [c for c in self.df_train.columns if c != target_col]
        self.X_train_raw = self.df_train[feature_cols]
        self.X_val_raw = self.df_val[feature_cols]
        self.X_test_raw = self.df_test[feature_cols]
    
    def preprocess(self):
        """Applique le preprocessing."""
        logger.info("Preprocessing des données...")
        
        self.preprocessor = PreprocessingPipeline(self.config_path)
        
        # Fit sur train, transform sur val et test
        self.X_train = self.preprocessor.fit_transform(self.X_train_raw, self.y_train)
        self.X_val = self.preprocessor.transform(self.X_val_raw)
        self.X_test = self.preprocessor.transform(self.X_test_raw)
        
        logger.info(f"Features après preprocessing: {self.X_train.shape[1]}")
    
    def train_models(self, models: list = None, optimize: bool = False):
        """Entraîne les modèles."""
        logger.info("Entraînement des modèles...")
        
        if models is None:
            models = ['logistic_regression', 'random_forest', 'lightgbm']
        
        self.results = self.trainer.train_all_models(
            self.X_train, self.y_train,
            self.X_val, self.y_val,
            models=models,
            optimize=optimize
        )
        
        self.best_model = self.trainer.best_model
        self.best_model_name = self.trainer.best_model_name
        
        # Comparaison
        comparison = compare_models(self.results)
        logger.info(f"\nComparaison des modèles:\n{comparison.to_string()}")
        
        return comparison
    
    def calibrate(self):
        """Calibre les probabilités du meilleur modèle."""
        logger.info("Calibration des probabilités...")
        
        y_proba_val = self.best_model.predict_proba(self.X_val)[:, 1]
        
        y_proba_cal, thresholds, self.calibrator = calibrate_and_optimize(
            self.y_val.values,
            y_proba_val,
            calibration_method=self.config['calibration']['method'],
            config_path=self.config_path
        )
        
        self.threshold_optimizer = ThresholdOptimizer(
            min_precision_rejection=self.config['thresholds']['constraints']['min_precision_rejection'],
            min_precision_validation=self.config['thresholds']['constraints']['min_precision_validation'],
            target_automation_rate=tuple(self.config['thresholds']['constraints']['target_automation_rate'])
        )
        self.threshold_optimizer.optimal_thresholds = thresholds
        
        return thresholds
    
    def evaluate(self):
        """Évalue le modèle sur le test set."""
        logger.info("Évaluation sur le test set...")
        
        # Prédictions
        y_proba_test = self.best_model.predict_proba(self.X_test)[:, 1]
        
        # Calibration
        if self.calibrator:
            y_proba_test_cal = self.calibrator.calibrate(y_proba_test)
        else:
            y_proba_test_cal = y_proba_test
        
        # Décisions avec seuils
        if self.threshold_optimizer and self.threshold_optimizer.optimal_thresholds:
            decisions, confidences = self.threshold_optimizer.apply_thresholds(y_proba_test_cal)
            y_pred_test = (y_proba_test_cal >= 0.5).astype(int)
        else:
            y_pred_test = (y_proba_test_cal >= 0.5).astype(int)
            decisions = np.where(y_pred_test == 1, 'VALIDATION_AUTO', 'REJET_AUTO')
        
        # Métriques
        categories = {}
        for col in ['Famille Produit', 'Catégorie']:
            if col in self.df_test.columns:
                categories[col] = self.df_test[col].values
        
        self.performance_report = self.metrics_calculator.generate_performance_report(
            self.y_test.values,
            y_pred_test,
            y_proba_test_cal,
            decisions,
            categories
        )
        
        # Afficher les résultats
        cls_metrics = self.performance_report.classification
        logger.info(f"\n=== MÉTRIQUES TEST ===")
        logger.info(f"Accuracy: {cls_metrics.accuracy:.4f}")
        logger.info(f"F1 Weighted: {cls_metrics.f1_weighted:.4f}")
        logger.info(f"Precision Rejet (classe 0): {cls_metrics.precision_class_0:.4f}")
        logger.info(f"Precision Validation (classe 1): {cls_metrics.precision_class_1:.4f}")
        logger.info(f"AUC-ROC: {cls_metrics.roc_auc:.4f}")
        
        if self.performance_report.business:
            biz_metrics = self.performance_report.business
            logger.info(f"\n=== MÉTRIQUES BUSINESS ===")
            logger.info(f"Taux Automatisation: {biz_metrics.automation_rate:.2%}")
            logger.info(f"Précision Rejets Auto: {biz_metrics.precision_rejection:.4f}")
            logger.info(f"Précision Validations Auto: {biz_metrics.precision_validation:.4f}")
        
        # Extraire faux positifs et faux négatifs
        self.df_fp, self.df_fn = get_false_predictions(
            self.df_test,
            self.y_test.values,
            y_pred_test,
            y_proba_test_cal
        )
        
        return self.performance_report
    
    def save_results(self, output_dir: str):
        """Sauvegarde tous les résultats."""
        output_dir = Path(output_dir)
        output_dir.mkdir(parents=True, exist_ok=True)
        
        logger.info(f"Sauvegarde des résultats dans {output_dir}...")
        
        # Modèle
        self.trainer.save_model(
            self.best_model_name,
            output_dir / "models"
        )
        
        # Preprocessor
        self.preprocessor.save(output_dir / "models" / "preprocessor.pkl")
        
        # Calibrateur
        if self.calibrator:
            self.calibrator.save(output_dir / "models" / "calibrator.pkl")
        
        # Seuils
        if self.threshold_optimizer and self.threshold_optimizer.optimal_thresholds:
            self.threshold_optimizer.save(output_dir / "models" / "thresholds.pkl")
        
        # Feature importance
        if self.results[self.best_model_name].feature_importance is not None:
            fi = self.results[self.best_model_name].feature_importance
            fi.to_csv(output_dir / "feature_importance.csv", index=False)
        
        # Faux positifs et négatifs
        if hasattr(self, 'df_fp') and hasattr(self, 'df_fn'):
            errors_df = pd.concat([self.df_fp, self.df_fn], ignore_index=True)
            errors_df.to_excel(output_dir / "errors_analysis.xlsx", index=False)
        
        logger.info("Résultats sauvegardés avec succès")
    
    def run(
        self,
        data_path: str,
        output_dir: str = "outputs",
        models: list = None,
        optimize: bool = False
    ):
        """Exécute le pipeline complet."""
        logger.info("=" * 60)
        logger.info("DÉMARRAGE DU PIPELINE ML")
        logger.info("=" * 60)
        
        start_time = datetime.now()
        
        # 1. Chargement
        self.load_data(data_path)
        
        # 2. Split
        self.split_data()
        
        # 3. Preprocessing
        self.preprocess()
        
        # 4. Entraînement
        comparison = self.train_models(models, optimize)
        
        # 5. Calibration
        thresholds = self.calibrate()
        
        # 6. Évaluation
        report = self.evaluate()
        
        # 7. Sauvegarde
        self.save_results(output_dir)
        
        elapsed = datetime.now() - start_time
        logger.info(f"\n{'=' * 60}")
        logger.info(f"PIPELINE TERMINÉ en {elapsed}")
        logger.info(f"Meilleur modèle: {self.best_model_name}")
        logger.info(f"{'=' * 60}")
        
        return {
            'comparison': comparison,
            'thresholds': thresholds,
            'report': report
        }


def main():
    parser = argparse.ArgumentParser(description='Pipeline ML Classification Réclamations')
    parser.add_argument('--data', '-d', required=True, help='Chemin vers le fichier de données')
    parser.add_argument('--output', '-o', default='outputs', help='Répertoire de sortie')
    parser.add_argument('--models', '-m', nargs='+', default=None, 
                       help='Modèles à entraîner (logistic_regression, random_forest, lightgbm, xgboost)')
    parser.add_argument('--optimize', action='store_true', help='Optimiser les hyperparamètres')
    parser.add_argument('--config', '-c', default='configs/config.yaml', help='Fichier de configuration')
    
    args = parser.parse_args()
    
    # Créer le répertoire de logs
    Path('logs').mkdir(exist_ok=True)
    
    # Exécuter le pipeline
    pipeline = MLPipeline(args.config)
    results = pipeline.run(
        data_path=args.data,
        output_dir=args.output,
        models=args.models,
        optimize=args.optimize
    )
    
    return results


if __name__ == "__main__":
    main()
